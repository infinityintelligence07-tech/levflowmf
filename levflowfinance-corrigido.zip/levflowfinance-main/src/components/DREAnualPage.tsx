import { useState, useMemo, useRef } from 'react';
import { useSupabaseData } from '@/hooks/useSupabaseData';
import { useEmpresa } from '@/hooks/useEmpresa';
import { aggregateData, calcularDRE, calcularSaldoHistoricoAte, applyScenarios, type DREWithDetails } from '@/lib/dre-engine';
import { formatCurrency, formatPercent } from '@/lib/formatters';
import { DRE_LINES } from '@/lib/constants';
import { DRE_TABLE, INPUT } from '@/lib/ui-styles';
import { Calendar, ChevronLeft, ChevronRight } from 'lucide-react';


const MONTHS = ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'];
const MONTH_PREFIXES = ['JAN','FEV','MAR','ABR','MAI','JUN','JUL','AGO','SET','OUT','NOV','DEZ'];

export default function DREAnualPage() {
  const { empresaAtual, isAllMode, empresas } = useEmpresa();
  const { planoContas, orcamentos, lancamentos, pendencias, acaoCfo, loading } = useSupabaseData();
  const [year, setYear] = useState(new Date().getFullYear());
  const [expandedRows, setExpandedRows] = useState<Set<string>>(new Set());
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (dir: 'left' | 'right') => {
    if (!scrollRef.current) return;
    scrollRef.current.scrollLeft += dir === 'left' ? -400 : 400;
  };

  const saldoInicial = isAllMode
    ? empresas.filter(e => e.ativo).reduce((s, e) => s + e.saldo_inicial, 0)
    : empresaAtual?.saldo_inicial || 0;

  const yearSuffix = `.${String(year).slice(2)}`;

  const monthDREs = useMemo(() => {
    return Array.from({ length: 12 }, (_, i) => {
      const start = `${year}-${String(i + 1).padStart(2, '0')}-01`;
      const lastDay = new Date(year, i + 1, 0).getDate();
      const end = `${year}-${String(i + 1).padStart(2, '0')}-${lastDay}`;
      const agg = aggregateData(orcamentos, lancamentos, pendencias, planoContas, acaoCfo, empresaAtual, start, end);
      return calcularDRE(agg);
    });
  }, [year, orcamentos, lancamentos, pendencias, planoContas, acaoCfo, empresaAtual]);

  const pctC2 = empresaAtual?.cenario_c2 ?? 30;
  const pctC3 = empresaAtual?.cenario_c3 ?? 70;

  const acumDRE = useMemo(() => {
    const agg = aggregateData(orcamentos, lancamentos, pendencias, planoContas, acaoCfo, empresaAtual, `${year}-01-01`, `${year}-12-31`);
    const baseDRE = calcularDRE(agg);
    return applyScenarios(baseDRE, pctC2, pctC3);
  }, [year, orcamentos, lancamentos, pendencias, planoContas, acaoCfo, empresaAtual, pctC2, pctC3]);

  const toggleRow = (key: string) => {
    setExpandedRows(prev => { const n = new Set(prev); if (n.has(key)) n.delete(key); else n.add(key); return n; });
  };

  if (loading) return <div className="flex items-center justify-center h-64" style={{ color: DRE_TABLE.neutralColor }}>Carregando...</div>;

  const recLiqAcum = acumDRE.receita_liquida.real;


  return (
    <div>
      <div className="flex items-center gap-3 mb-5">
        <Calendar size={15} style={{ color: DRE_TABLE.neutralColor }} />
        <label className="text-sm font-medium" style={{ color: '#64748B' }}>Ano:</label>
        <select value={year} onChange={e => setYear(Number(e.target.value))} style={{ ...INPUT, width: 'auto' }}>
          {Array.from({ length: 11 }, (_, i) => 2020 + i).map(y => <option key={y} value={y}>{y}</option>)}
        </select>
      </div>

      <div className="flex items-center gap-2 mb-2 justify-end">
        <button onClick={() => scroll('left')} className="flex items-center justify-center rounded-lg transition-colors hover:bg-muted" style={{ width: 32, height: 32, border: '1px solid var(--color-card-border, #E8EDF5)' }}>
          <ChevronLeft size={16} style={{ color: '#64748B' }} />
        </button>
        <span className="text-xs" style={{ color: DRE_TABLE.neutralColor }}>Deslizar tabela</span>
        <button onClick={() => scroll('right')} className="flex items-center justify-center rounded-lg transition-colors hover:bg-muted" style={{ width: 32, height: 32, border: '1px solid var(--color-card-border, #E8EDF5)' }}>
          <ChevronRight size={16} style={{ color: '#64748B' }} />
        </button>
      </div>

      <div ref={scrollRef} className="dre-scroll" style={{ ...DRE_TABLE.wrapper, scrollBehavior: 'smooth' }}>
        <table className="text-xs" style={{ ...DRE_TABLE.cellFont, width: 'max-content', borderCollapse: 'collapse' }}>
          <colgroup>
            <col style={{ minWidth: 240, width: 240 }} />
            {MONTHS.map((_, i) => (
              <Fr key={i}>
                <col style={{ minWidth: 100, width: 100 }} />
                <col style={{ minWidth: 100, width: 100 }} />
                <col style={{ minWidth: 100, width: 100 }} />
              </Fr>
            ))}
            <col style={{ minWidth: 100 }} />
            <col style={{ minWidth: 100 }} />
            <col style={{ minWidth: 100 }} />
            <col style={{ minWidth: 100 }} />
            <col style={{ minWidth: 85 }} />
            <col style={{ minWidth: 85 }} />
          </colgroup>
          <thead>
            <tr style={{ background: 'var(--color-primary-gradient, var(--color-primary, #1A2B6D))' }}>
              <th className="sticky left-0 z-20 text-left px-3 py-3 font-semibold text-xs tracking-wide uppercase" style={{ minWidth: 240, background: 'var(--color-primary, #1A2B6D)', color: '#fff' }}>Categoria</th>
              {MONTHS.map((m, i) => (
                <th key={i} colSpan={3} className="text-center px-1 py-3 border-l font-semibold text-xs tracking-wide" style={{ color: 'rgba(255,255,255,0.8)', borderLeftColor: 'rgba(255,255,255,0.12)' }}>{m}</th>
              ))}
              <th colSpan={4} className="text-center px-1 py-3 border-l font-semibold text-xs tracking-wide uppercase" style={{ color: '#fff', borderLeftColor: 'rgba(255,255,255,0.12)', minWidth: 340 }}>Acumulado</th>
              <th colSpan={2} className="text-center px-1 py-3 border-l font-semibold text-xs tracking-wide uppercase" style={{ color: '#fff', borderLeftColor: 'rgba(255,255,255,0.12)', minWidth: 160 }}>% (AV)</th>
            </tr>
            <tr style={{ background: DRE_TABLE.subHeaderBg }}>
              <th className="sticky left-0 z-20 border-b" style={{ background: DRE_TABLE.subHeaderBg }} />
              {MONTHS.map((_, i) => (
                <Fr key={i}>
                  <th className="px-1 py-1.5 border-b border-l text-center text-[10px] font-medium" style={{ color: '#64748B' }}>Previsto</th>
                  <th className="px-1 py-1.5 border-b text-center text-[10px] font-medium" style={{ color: '#64748B', borderLeft: '1px dashed #DAE2F0' }}>Real</th>
                  <th className="px-1 py-1.5 border-b text-center text-[10px] font-medium" style={{ color: '#64748B', borderLeft: '1px dashed #DAE2F0' }}>Variação</th>
                </Fr>
              ))}
              <th className="px-1 py-1.5 border-b border-l text-center text-[10px] font-medium whitespace-nowrap" style={{ background: DRE_TABLE.acumuladoBg, color: '#64748B', minWidth: 100 }}>Conservador</th>
              <th className="px-1 py-1.5 border-b text-center text-[10px] font-medium whitespace-nowrap" style={{ background: DRE_TABLE.acumuladoBg, color: '#64748B', minWidth: 100, borderLeft: '1px dashed #DAE2F0' }}>Moderado</th>
              <th className="px-1 py-1.5 border-b text-center text-[10px] font-medium whitespace-nowrap" style={{ background: DRE_TABLE.acumuladoBg, color: '#64748B', minWidth: 100, borderLeft: '1px dashed #DAE2F0' }}>Otimista</th>
              <th className="px-1 py-1.5 border-b text-center text-[10px] font-medium whitespace-nowrap" style={{ background: DRE_TABLE.acumuladoBg, color: '#64748B', minWidth: 100, borderLeft: '1px dashed #DAE2F0' }}>Real</th>
              <th className="px-1 py-1.5 border-b border-l text-center text-[10px] font-medium whitespace-nowrap" style={{ background: DRE_TABLE.acumuladoBg, color: '#64748B', minWidth: 85 }}>Real</th>
              <th className="px-1 py-1.5 border-b text-center text-[10px] font-medium whitespace-nowrap" style={{ background: DRE_TABLE.acumuladoBg, color: '#64748B', minWidth: 85, borderLeft: '1px dashed #DAE2F0' }}>Previsto</th>
            </tr>
          </thead>
          <tbody>
            {/* Saldo Inicial */}
            <tr style={{ background: DRE_TABLE.saldoInicialBg, borderBottom: '2px solid var(--color-card-border, #E8EDF5)' }}>
              <td className="sticky left-0 z-20 px-3 py-2 font-semibold" style={{ background: DRE_TABLE.saldoInicialBg, color: 'var(--color-primary, #6FA9FF)' }}>Saldo Inicial Acumulado (01/Jan)</td>
              {MONTHS.map((_, i) => <td key={i} colSpan={3} className="text-center border-l" style={{ color: 'var(--color-primary, #6FA9FF)', fontWeight: 500 }}>{formatCurrency(saldoInicial)}</td>)}
              <td colSpan={4} className="text-center font-semibold border-l" style={{ color: 'var(--color-primary, #6FA9FF)' }}>{formatCurrency(saldoInicial)}</td>
              <td colSpan={2} className="text-center border-l" style={{ color: DRE_TABLE.neutralColor }}>-</td>
            </tr>

            {DRE_LINES.map(line => {
              const isExpanded = expandedRows.has(line.key);
              const isResultadoLiquido = line.key === 'resultado_liquido';
              const rowBg = isResultadoLiquido ? '#E0ECFF' : line.isSubtotal ? DRE_TABLE.subtotalBg : '#fff';
              const textStyle = isResultadoLiquido
                ? { color: 'var(--color-primary, #1A2B6D)', fontWeight: 700 }
                : line.isSubtotal ? { color: DRE_TABLE.subtotalColor, fontWeight: 600 } : {};

              const hasDetails = !line.isSubtotal && !!line.categoria;
              const detailItems = hasDetails
                ? (() => {
                    const cat = line.categoria!;
                    const fromDRE = acumDRE.details[cat] || [];
                    const dreNames = new Set(fromDRE.map(d => d.nome));
                    const fromPlano = planoContas
                      .filter(pc => pc.categoria_dre === cat && !dreNames.has(pc.nome_conta))
                      .map(pc => ({ nome: pc.nome_conta, p1: 0, p2: 0, p3: 0, real: 0, _cat: cat }));
                    return [...fromDRE.map(d => ({ ...d, _cat: cat })), ...fromPlano];
                  })()
                : [];

              return (
                <Fr key={line.key}>
                  <tr style={{ background: rowBg, borderBottom: '1px solid #EDF1F7' }}>
                    <td className="sticky left-0 z-20 px-3 py-2.5 cursor-pointer whitespace-nowrap" style={{ background: rowBg, color: '#1E293B', ...textStyle }}
                      onClick={() => hasDetails && toggleRow(line.key)}>
                      {hasDetails && <span className="mr-1.5" style={{ color: 'var(--color-primary, #6FA9FF)' }}>{isExpanded ? '−' : '+'}</span>}
                      {line.label}
                    </td>
                    {monthDREs.map((md, mi) => {
                      const v = md[line.key as keyof DREWithDetails] as any;
                      if (!v?.p1 && v?.p1 !== 0) return <td key={mi} colSpan={3} className="border-l" />;
                      const diff = v.real - v.p1;
                      return (
                        <Fr key={mi}>
                          <td className="text-right px-2 py-2 border-l whitespace-nowrap" style={{ color: v.p1 === 0 ? DRE_TABLE.neutralColor : '#334155', ...textStyle, borderLeftColor: '#DAE2F0' }}>{formatCurrency(v.p1)}</td>
                          <td className="text-right px-2 py-2 whitespace-nowrap" style={{ color: v.real === 0 ? DRE_TABLE.neutralColor : '#334155', ...textStyle, borderLeft: '1px dashed #DAE2F0' }}>{formatCurrency(v.real)}</td>
                          <td className="text-right px-2 py-2 whitespace-nowrap" style={{ borderLeft: '1px dashed #DAE2F0', color: diff === 0 ? DRE_TABLE.neutralColor : diff >= 0 ? DRE_TABLE.positiveColor : DRE_TABLE.negativeColor, fontWeight: 500 }}>{formatCurrency(diff)}</td>
                        </Fr>
                      );
                    })}
                    {(() => {
                      const v = acumDRE[line.key as keyof DREWithDetails] as any;
                      if (!v?.p1 && v?.p1 !== 0) return <><td colSpan={4} className="border-l" /><td colSpan={2} className="border-l" /></>;
                      const avReal = recLiqAcum !== 0 ? (v.real / recLiqAcum) * 100 : 0;
                      const avPrev = recLiqAcum !== 0 ? (v.p1 / recLiqAcum) * 100 : 0;
                      return (
                         <>
                          <td className="text-right px-2 py-2 border-l font-semibold whitespace-nowrap" style={textStyle}>{formatCurrency(v.p1)}</td>
                          <td className="text-right px-2 py-2 font-semibold whitespace-nowrap" style={{ ...textStyle, borderLeft: '1px dashed #E2E8F0' }}>{formatCurrency(v.p2)}</td>
                          <td className="text-right px-2 py-2 font-semibold whitespace-nowrap" style={{ ...textStyle, borderLeft: '1px dashed #E2E8F0' }}>{formatCurrency(v.p3)}</td>
                          <td className="text-right px-2 py-2 font-semibold whitespace-nowrap" style={{ ...textStyle, borderLeft: '1px dashed #E2E8F0' }}>{formatCurrency(v.real)}</td>
                          <td className="text-right px-2 py-2 border-l whitespace-nowrap" style={textStyle}>{formatPercent(avReal)}</td>
                          <td className="text-right px-2 py-2 whitespace-nowrap" style={{ ...textStyle, borderLeft: '1px dashed #E2E8F0' }}>{formatPercent(avPrev)}</td>
                        </>
                      );
                    })()}
                  </tr>

                  {isExpanded && detailItems.map(detail => (
                    <tr key={detail.nome} style={{ background: '#F5F7FB', borderBottom: '1px solid #EDF1F7' }}>
                      <td className="sticky left-0 z-20 px-3 py-1.5 pl-8 whitespace-nowrap text-xs" style={{ background: '#F5F7FB', color: '#475569' }}>{detail.nome}</td>
                      {monthDREs.map((md, mi) => {
                        const monthDetail = md.details[detail._cat]?.find(d => d.nome === detail.nome);
                        const p = monthDetail?.p1 || 0;
                        const r = monthDetail?.real || 0;
                        const d = r - p;
                        return (
                          <Fr key={mi}>
                            <td className="text-right px-2 py-1.5 border-l text-xs whitespace-nowrap" style={{ color: p === 0 ? DRE_TABLE.neutralColor : '#475569', borderLeftColor: '#DAE2F0' }}>{formatCurrency(p)}</td>
                            <td className="text-right px-2 py-1.5 text-xs whitespace-nowrap" style={{ color: r === 0 ? DRE_TABLE.neutralColor : '#475569', borderLeft: '1px dashed #DAE2F0' }}>{formatCurrency(r)}</td>
                            <td className="text-right px-2 py-1.5 text-xs whitespace-nowrap" style={{ borderLeft: '1px dashed #DAE2F0', color: d === 0 ? DRE_TABLE.neutralColor : d >= 0 ? DRE_TABLE.positiveColor : DRE_TABLE.negativeColor }}>{formatCurrency(d)}</td>
                          </Fr>
                        );
                      })}
                      <td className="text-right px-2 py-1.5 border-l text-xs whitespace-nowrap" style={{ color: '#475569' }}>{formatCurrency(detail.p1)}</td>
                      <td className="text-right px-2 py-1.5 text-xs whitespace-nowrap" style={{ color: '#475569', borderLeft: '1px dashed #DAE2F0' }}>{formatCurrency(detail.p2)}</td>
                      <td className="text-right px-2 py-1.5 text-xs whitespace-nowrap" style={{ color: '#475569', borderLeft: '1px dashed #DAE2F0' }}>{formatCurrency(detail.p3)}</td>
                      <td className="text-right px-2 py-1.5 text-xs whitespace-nowrap" style={{ color: '#475569', borderLeft: '1px dashed #DAE2F0' }}>{formatCurrency(detail.real)}</td>
                      <td className="text-right px-2 py-1.5 border-l text-xs whitespace-nowrap" style={{ color: '#475569' }}>{recLiqAcum !== 0 ? formatPercent((detail.real / recLiqAcum) * 100) : '-'}</td>
                      <td className="text-right px-2 py-1.5 text-xs whitespace-nowrap" style={{ color: '#475569', borderLeft: '1px dashed #DAE2F0' }}>{recLiqAcum !== 0 ? formatPercent((detail.p1 / recLiqAcum) * 100) : '-'}</td>
                    </tr>
                  ))}
                </Fr>
              );
            })}

            {/* Saldo Acumulado */}
            {(() => {
              let acumPrev = saldoInicial;
              let acumReal = saldoInicial;
              return (
                <tr style={{ background: 'var(--color-primary-gradient, var(--color-primary, #1A2B6D))', borderTop: '3px solid var(--color-primary, #1A2B6D)' }}>
                  <td className="sticky left-0 z-20 px-3 py-3 font-bold text-sm" style={{ background: 'var(--color-primary, #1A2B6D)', color: '#fff' }}>Saldo Acumulado</td>
                  {monthDREs.map((md, i) => {
                    acumPrev += md.resultado_liquido.p1;
                    acumReal += md.resultado_liquido.real;
                    const diff = acumReal - acumPrev;
                    return (
                      <Fr key={i}>
                        <td className="text-right px-2 py-3 border-l font-bold whitespace-nowrap" style={{ color: acumPrev >= 0 ? '#93C5FD' : '#FCA5A5', borderLeftColor: 'rgba(255,255,255,0.15)' }}>{formatCurrency(acumPrev)}</td>
                        <td className="text-right px-2 py-3 font-bold whitespace-nowrap" style={{ color: acumReal >= 0 ? '#fff' : '#FCA5A5', borderLeft: '1px dashed rgba(255,255,255,0.15)' }}>{formatCurrency(acumReal)}</td>
                        <td className="text-right px-2 py-3 font-bold whitespace-nowrap" style={{ color: diff >= 0 ? '#86EFAC' : '#FCA5A5', borderLeft: '1px dashed rgba(255,255,255,0.15)' }}>{formatCurrency(diff)}</td>
                      </Fr>
                    );
                  })}
                  <td className="text-right px-2 py-3 border-l font-bold whitespace-nowrap" style={{ color: '#93C5FD', borderLeftColor: 'rgba(255,255,255,0.15)' }}>{formatCurrency(saldoInicial + acumDRE.resultado_liquido.p1)}</td>
                  <td className="text-right px-2 py-3 font-bold whitespace-nowrap" style={{ color: '#93C5FD', borderLeft: '1px dashed rgba(255,255,255,0.15)' }}>{formatCurrency(saldoInicial + acumDRE.resultado_liquido.p2)}</td>
                  <td className="text-right px-2 py-3 font-bold whitespace-nowrap" style={{ color: '#93C5FD', borderLeft: '1px dashed rgba(255,255,255,0.15)' }}>{formatCurrency(saldoInicial + acumDRE.resultado_liquido.p3)}</td>
                  <td className="text-right px-2 py-3 font-bold whitespace-nowrap" style={{ color: '#fff', borderLeft: '1px dashed rgba(255,255,255,0.15)' }}>{formatCurrency(saldoInicial + acumDRE.resultado_liquido.real)}</td>
                  <td colSpan={2} className="text-center border-l font-bold" style={{ color: 'rgba(255,255,255,0.5)', borderLeftColor: 'rgba(255,255,255,0.15)' }}>-</td>
                </tr>
              );
            })()}

            {/* ── Resumo Previsto ── */}
            {(() => {
              const getEnt = (dre: DREWithDetails) => dre.receita_bruta.p1 + dre.outras_receitas.p1;
              const getSai = (dre: DREWithDetails) => Math.abs(dre.deducoes.p1) + Math.abs(dre.custos_variaveis.p1) + Math.abs(dre.despesas_operacionais.p1) + Math.abs(dre.despesas_financeiras.p1) + Math.abs(dre.distribuicao_lucro.p1);
              const rows = [
                { label: 'Entrada Prevista', get: getEnt, color: '#046C4E' },
                { label: 'Saída Prevista', get: getSai, color: '#C53030' },
                { label: 'Saldo Previsto', get: (d: DREWithDetails) => getEnt(d) - getSai(d), color: 'dynamic' },
              ];
              return rows.map((r, ri) => {
                const isSaldo = ri === 2;
                const bg = isSaldo ? '#F0FDF9' : '#FAFBFE';
                return (
                  <tr key={r.label} style={{ background: bg, borderTop: ri === 0 ? '4px solid #DAE2F0' : isSaldo ? '1px solid #DAE2F0' : '1px solid #EDF1F7' }}>
                    <td className="sticky left-0 z-20 px-3 py-2 whitespace-nowrap text-[11px]" style={{ background: bg, color: isSaldo ? 'var(--color-primary, #1A2B6D)' : '#475569', fontWeight: isSaldo ? 700 : 600 }}>
                      {r.label}
                    </td>
                    {monthDREs.map((md, mi) => {
                      const val = r.get(md);
                      const c = r.color === 'dynamic' ? (val >= 0 ? '#046C4E' : '#C53030') : r.color;
                      return (
                        <td key={mi} colSpan={3} className="text-center px-2 py-2 border-l whitespace-nowrap text-[11px]" style={{ color: c, fontWeight: isSaldo ? 700 : 600, borderLeftColor: '#DAE2F0' }}>
                          {formatCurrency(val)}
                        </td>
                      );
                    })}
                    <td colSpan={4} className="text-center px-2 py-2 border-l whitespace-nowrap text-[11px]" style={{ color: r.color === 'dynamic' ? (r.get(acumDRE) >= 0 ? '#046C4E' : '#C53030') : r.color, fontWeight: isSaldo ? 700 : 600, borderLeftColor: '#DAE2F0' }}>
                      {formatCurrency(r.get(acumDRE))}
                    </td>
                    <td colSpan={2} className="text-center border-l" style={{ color: DRE_TABLE.neutralColor, borderLeftColor: '#DAE2F0' }}>-</td>
                  </tr>
                );
              });
            })()}

            {/* ── Resumo Realizado ── */}
            {(() => {
              const getEnt = (dre: DREWithDetails) => dre.receita_bruta.real + dre.outras_receitas.real;
              const getSai = (dre: DREWithDetails) => Math.abs(dre.deducoes.real) + Math.abs(dre.custos_variaveis.real) + Math.abs(dre.despesas_operacionais.real) + Math.abs(dre.despesas_financeiras.real) + Math.abs(dre.distribuicao_lucro.real);
              const rows = [
                { label: 'Entrada Realizada', get: getEnt, color: '#046C4E' },
                { label: 'Saída Realizada', get: getSai, color: '#C53030' },
                { label: 'Saldo Realizado', get: (d: DREWithDetails) => getEnt(d) - getSai(d), color: 'dynamic' },
              ];
              return rows.map((r, ri) => {
                const isSaldo = ri === 2;
                const bg = isSaldo ? '#EFF6FF' : '#F8FAFC';
                return (
                  <tr key={r.label} style={{ background: bg, borderTop: ri === 0 ? '4px solid #93C5FD' : isSaldo ? '1px solid #DAE2F0' : '1px solid #EDF1F7' }}>
                    <td className="sticky left-0 z-20 px-3 py-2 whitespace-nowrap text-[11px]" style={{ background: bg, color: isSaldo ? 'var(--color-primary, #1A2B6D)' : '#475569', fontWeight: isSaldo ? 700 : 600 }}>
                      {r.label}
                    </td>
                    {monthDREs.map((md, mi) => {
                      const val = r.get(md);
                      const c = r.color === 'dynamic' ? (val >= 0 ? '#046C4E' : '#C53030') : r.color;
                      return (
                        <td key={mi} colSpan={3} className="text-center px-2 py-2 border-l whitespace-nowrap text-[11px]" style={{ color: c, fontWeight: isSaldo ? 700 : 600, borderLeftColor: '#DAE2F0' }}>
                          {formatCurrency(val)}
                        </td>
                      );
                    })}
                    <td colSpan={4} className="text-center px-2 py-2 border-l whitespace-nowrap text-[11px]" style={{ color: r.color === 'dynamic' ? (r.get(acumDRE) >= 0 ? '#046C4E' : '#C53030') : r.color, fontWeight: isSaldo ? 700 : 600, borderLeftColor: '#DAE2F0' }}>
                      {formatCurrency(r.get(acumDRE))}
                    </td>
                    <td colSpan={2} className="text-center border-l" style={{ color: DRE_TABLE.neutralColor, borderLeftColor: '#DAE2F0' }}>-</td>
                  </tr>
                );
              });
            })()}

          </tbody>
        </table>
      </div>
    </div>
  );
}

function Fr({ children }: { children?: React.ReactNode }) { return <>{children}</>; }
