import { useState, useMemo } from 'react';
import { useEmpresa } from '@/hooks/useEmpresa';
import { useSupabaseData } from '@/hooks/useSupabaseData';
import { aggregateData, calcularDRE, calcularResultadoAllTime, calcularSaldoHistoricoAte } from '@/lib/dre-engine';
import { formatCurrency, formatPercent } from '@/lib/formatters';
import { DRE_LINES, CATEGORIAS_DESPESA, CATEGORIAS_RECEITA, CATEGORIAS_DRE, DONUT_COLORS } from '@/lib/constants';
import EChartsDonut from './charts/EChartsDonut';
import EChartsWaterfall from './charts/EChartsWaterfall';
import EChartsLine from './charts/EChartsLine';
import EChartsFundoCaixa from './charts/EChartsFundoCaixa';
import {
  AlertTriangle, Crosshair, Zap, TrendingDown, BarChart3,
  ArrowUpCircle, ArrowDownCircle, Calendar, Shield, Wallet,
  Building2, Radar, ChevronDown, Trophy, AlertCircle, PieChart,
  Activity, ArrowLeftCircle, ArrowRightCircle, Landmark, Target, Anchor
} from 'lucide-react';
import { startOfWeek, addDays, format, startOfYear, endOfYear, getISOWeek } from 'date-fns';

function today() { return new Date().toISOString().slice(0, 10); }
function startOfMonth() {
  const d = new Date();
  return new Date(d.getFullYear(), d.getMonth(), 1).toISOString().slice(0, 10);
}

export default function DashboardPage({ onNavigate }: { onNavigate?: (tab: string) => void }) {
  const { empresaAtual, isAllMode, empresas } = useEmpresa();
  const { planoContas, orcamentos, lancamentos, bancos, pendencias, acaoCfo, loading } = useSupabaseData();
  const [dateStart, setDateStart] = useState(startOfMonth());
  const [dateEnd, setDateEnd] = useState(today());
  const [showAuditDetail, setShowAuditDetail] = useState(false);

  const aggData = useMemo(() =>
    aggregateData(orcamentos, lancamentos, pendencias, planoContas, acaoCfo, empresaAtual, dateStart, dateEnd),
    [orcamentos, lancamentos, pendencias, planoContas, acaoCfo, empresaAtual, dateStart, dateEnd]
  );

  const dre = useMemo(() => calcularDRE(aggData), [aggData]);

  const saldoBancos = useMemo(() => bancos.reduce((s, b) => s + Number(b.saldo || 0), 0), [bancos]);
  const saldoInicial = isAllMode
    ? empresas.filter(e => e.ativo).reduce((s, e) => s + e.saldo_inicial, 0)
    : empresaAtual?.saldo_inicial || 0;
  const resultadoAllTime = useMemo(() =>
    calcularResultadoAllTime(lancamentos, pendencias, planoContas, saldoInicial),
    [lancamentos, pendencias, planoContas, saldoInicial]
  );
  const checkAuditoria = saldoBancos - resultadoAllTime;

  // Audit breakdown for detail modal
  const auditBreakdown = useMemo(() => {
    const contaToCategoria: Record<string, string> = {};
    planoContas.forEach((pc: any) => { contaToCategoria[pc.nome_conta] = pc.categoria_dre; });

    const catLabels: Record<string, string> = {};
    CATEGORIAS_DRE.forEach(c => { catLabels[c.value] = c.label; });

    // Group lancamentos by category
    const byCat: Record<string, { items: any[]; total: number; tipo: 'entrada' | 'saida' }> = {};
    lancamentos.forEach((lr: any) => {
      if (!lr.ativo) return;
      const cat = contaToCategoria[lr.conta];
      if (!cat) return;
      if (!byCat[cat]) byCat[cat] = { items: [], total: 0, tipo: CATEGORIAS_RECEITA.includes(cat) ? 'entrada' : 'saida' };
      byCat[cat].items.push(lr);
      byCat[cat].total += Number(lr.valor);
    });

    // Group pendencias
    const pendEntGroup = pendencias.filter((p: any) => p.tipo === 'entrada');
    const pendSaiGroup = pendencias.filter((p: any) => p.tipo === 'saida');

    return { byCat, catLabels, pendEntGroup, pendSaiGroup };
  }, [lancamentos, pendencias, planoContas]);

  const top5Ofensores = useMemo(() => {
    const despEntries = Object.entries(aggData.byConta)
      .filter(([, v]) => CATEGORIAS_DESPESA.includes(v.categoria) && v.real > 0)
      .sort((a, b) => b[1].real - a[1].real)
      .slice(0, 5);
    const totalDesp = despEntries.reduce((s, [, v]) => s + v.real, 0);
    return despEntries.map(([nome, v], i) => ({ nome, valor: v.real, pct: totalDesp > 0 ? (v.real / totalDesp) * 100 : 0, idx: i }));
  }, [aggData]);

  // Donut data
  const donutData = useMemo(() => {
    const cats = CATEGORIAS_DESPESA.map(cat => ({
      name: DRE_LINES.find(l => l.categoria === cat)?.label || cat,
      value: aggData.byCategoria[cat]?.real || 0,
      color: DONUT_COLORS[cat] || '#999',
    })).filter(d => d.value > 0);
    if (dre.resultado_liquido.real > 0) {
      cats.push({ name: 'Lucro Retido', value: dre.resultado_liquido.real, color: DONUT_COLORS.lucro_retido });
    }
    return cats;
  }, [aggData, dre]);

  // Faturamento donut data — by subcategory
  const faturamentoDonutData = useMemo(() => {
    const FATURAMENTO_COLORS = ['#3182CE', '#2B6CB0', '#4299E1', '#63B3ED', '#90CDF4', '#2C5282', '#2A4365', '#1A365D', '#BEE3F8', '#EBF8FF'];
    const bySubconta: Record<string, number> = {};
    lancamentos.forEach((l: any) => {
      if (!l.ativo) return;
      const cat = planoContas.find((p: any) => p.nome_conta === l.conta)?.categoria_dre;
      if (!cat || !CATEGORIAS_RECEITA.includes(cat)) return;
      if (l.data_real < dateStart || l.data_real > dateEnd) return;
      const fat = Number(l.faturado || 0);
      if (fat > 0) bySubconta[l.conta] = (bySubconta[l.conta] || 0) + fat;
    });
    return Object.entries(bySubconta)
      .sort((a, b) => b[1] - a[1])
      .map(([name, value], i) => ({ name, value, color: FATURAMENTO_COLORS[i % FATURAMENTO_COLORS.length] }));
  }, [lancamentos, planoContas, dateStart, dateEnd]);

  // Waterfall data
  const waterfallData = useMemo(() => [
    { name: 'Receita Bruta', value: dre.receita_bruta.real },
    { name: 'Deduções', value: -dre.deducoes.real },
    { name: 'Desp. Variáveis', value: -dre.custos_variaveis.real },
    { name: 'Desp. Operac.', value: -dre.despesas_operacionais.real },
    { name: 'Outras Receitas', value: dre.outras_receitas.real },
    { name: 'Desp. Financeiras', value: -dre.despesas_financeiras.real },
    { name: 'Dist. Lucro', value: -dre.distribuicao_lucro.real },
    { name: 'Resultado Líquido', value: dre.resultado_liquido.real, isTotal: true },
  ], [dre]);

  // Line chart data
  const lineData = useMemo(() => {
    const start = new Date(dateStart);
    const end = new Date(dateEnd);
    const saldoHistorico = calcularSaldoHistoricoAte(lancamentos, pendencias, planoContas, saldoInicial, dateStart);
    const points: { date: string; saldo: number }[] = [];
    let acum = saldoHistorico;
    for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
      const ds = d.toISOString().slice(0, 10);
      const dayLancs = lancamentos.filter(l => l.ativo && l.data_real === ds);
      dayLancs.forEach(l => {
        const cat = planoContas.find(p => p.nome_conta === l.conta)?.categoria_dre;
        if (['receita', 'outras_receitas'].includes(cat)) acum += Number(l.valor);
        else acum -= Number(l.valor);
      });
      points.push({ date: ds, saldo: acum });
    }
    return points;
  }, [lancamentos, pendencias, planoContas, saldoInicial, dateStart, dateEnd]);

  // Pendencias monitor
  const pendEntradas = pendencias.filter(p => p.tipo === 'entrada' && !p.conta);
  const pendSaidas = pendencias.filter(p => p.tipo === 'saida' && !p.conta);

  const getPendStatus = (items: any[]) => {
    if (isAllMode) {
      // Consolidated: use combined rules — default to quantity-based
      if (items.length === 0) return { label: 'Tudo em dia', color: '#046C4E' };
      const totalLimite = empresas.filter(e => e.ativo).reduce((s, e) => s + (e.regras_pendencia_limite || 5), 0);
      const ok = items.length <= totalLimite;
      return { label: ok ? `Tudo em dia` : `Atenção: ${items.length} itens`, color: ok ? '#046C4E' : '#C53030' };
    }
    if (!empresaAtual) return { label: '-', color: '#64748B' };
    if (items.length === 0) return { label: 'Tudo em dia', color: '#046C4E' };
    const tipo = empresaAtual.regras_pendencia_tipo;
    const limite = empresaAtual.regras_pendencia_limite;
    if (tipo === 'Quantidade') {
      const ok = items.length <= limite;
      return { label: ok ? `Tudo em dia` : `Atenção: ${items.length} itens`, color: ok ? '#046C4E' : '#C53030' };
    }
    const maxDias = items.reduce((max, p) => {
      const diff = Math.floor((Date.now() - new Date(p.data).getTime()) / 86400000);
      return diff > max ? diff : max;
    }, 0);
    const ok = maxDias <= limite;
    return { label: ok ? `Tudo em dia` : `Atrasado: ${maxDias} dias`, color: ok ? '#046C4E' : '#C53030' };
  };

  // Cenários — consolidated: weighted average of active companies
  const c2Pct = isAllMode
    ? (() => { const active = empresas.filter(e => e.ativo); return active.length > 0 ? active.reduce((s, e) => s + (e.cenario_c2 || 30), 0) / active.length : 30; })()
    : empresaAtual?.cenario_c2 || 30;
  const c3Pct = isAllMode
    ? (() => { const active = empresas.filter(e => e.ativo); return active.length > 0 ? active.reduce((s, e) => s + (e.cenario_c3 || 70), 0) / active.length : 70; })()
    : empresaAtual?.cenario_c3 || 70;

  // Eficiência
  const margemEbitda = dre.receita_liquida.real !== 0 ? (dre.ebitda.real / dre.receita_liquida.real) * 100 : 0;
  const margemLiquida = dre.receita_liquida.real !== 0 ? (dre.resultado_liquido.real / dre.receita_liquida.real) * 100 : 0;
  const pontoEquilibrio = dre.margem_contribuicao.real !== 0 && dre.receita_liquida.real !== 0
    ? dre.despesas_operacionais.real / (dre.margem_contribuicao.real / dre.receita_liquida.real)
    : 0;

  // Radar
  const radarData = useMemo(() => {
    const mapaT: Record<string, string> = {};
    planoContas.forEach(pc => { mapaT[pc.nome_conta] = pc.categoria_dre; });
    const todayDate = new Date();
    const thisMonday = startOfWeek(todayDate, { weekStartsOn: 1 });

    const pastWeeks = Array.from({ length: 5 }, (_, i) => {
      const wStart = addDays(thisMonday, -(5 - i) * 7);
      const wEnd = addDays(wStart, 6);
      return { start: wStart, end: wEnd };
    });
    const futureWeeks = Array.from({ length: 5 }, (_, i) => {
      const wStart = addDays(thisMonday, i * 7);
      const wEnd = addDays(wStart, 6);
      return { start: wStart, end: wEnd };
    });

    const todayStr2 = format(todayDate, 'yyyy-MM-dd');
    const calcWeek = (wStart: Date, wEnd: Date, isPast: boolean) => {
      const sStr = format(wStart, 'yyyy-MM-dd');
      const eStr = format(wEnd, 'yyyy-MM-dd');
      let inProj = 0, outProj = 0, inReal = 0, outReal = 0;
      orcamentos.forEach(o => {
        if (o.data_ref < sStr || o.data_ref > eStr) return;
        const cat = mapaT[o.conta];
        if (!cat) return;
        if (CATEGORIAS_RECEITA.includes(cat)) inProj += Number(o.p1 || 0);
        else outProj += Number(o.p1 || 0);
      });
      // Only count realizado if the week has started (not fully future)
      const weekHasStarted = sStr <= todayStr2;
      if (weekHasStarted) {
        lancamentos.forEach(l => {
          if (!l.ativo || l.data_real < sStr || l.data_real > eStr) return;
          const cat = mapaT[l.conta];
          if (!cat) return;
          if (CATEGORIAS_RECEITA.includes(cat)) inReal += Number(l.valor);
          else outReal += Number(l.valor);
        });
        pendencias.forEach(p => {
          if (p.data < sStr || p.data > eStr) return;
          if (p.tipo === 'entrada') inReal += Number(p.valor);
          else outReal += Number(p.valor);
        });
      }
      const saldo = isPast ? (inReal - outReal) : (inProj - outProj);
      return { label: `${format(wStart, 'dd/MM')} a ${format(wEnd, 'dd/MM')}`, inProj, outProj, inReal, outReal, saldo, isPast, weekHasStarted };
    };

    return {
      past: pastWeeks.map(w => calcWeek(w.start, w.end, true)),
      future: futureWeeks.map(w => calcWeek(w.start, w.end, false)),
    };
  }, [planoContas, orcamentos, lancamentos, pendencias]);

  // Fundo de Caixa (Risco Anual)
  const fundoCaixaData = useMemo(() => {
    const mapaT: Record<string, string> = {};
    planoContas.forEach(pc => { mapaT[pc.nome_conta] = pc.categoria_dre; });

    const year = new Date().getFullYear();
    const jan1 = new Date(year, 0, 1);
    const dec31 = new Date(year, 11, 31);
    const todayDate = new Date();
    const todayStr = format(todayDate, 'yyyy-MM-dd');

    // Generate all weeks of the year
    let weekStart = startOfWeek(jan1, { weekStartsOn: 1 });
    if (weekStart > jan1) weekStart = addDays(weekStart, -7);
    const weeks: { start: Date; end: Date; label: string }[] = [];
    while (weekStart <= dec31) {
      const wEnd = addDays(weekStart, 6);
      weeks.push({ start: weekStart, end: wEnd, label: `${format(weekStart, 'dd/MM')} a ${format(wEnd, 'dd/MM')}` });
      weekStart = addDays(weekStart, 7);
    }

    const si = isAllMode
      ? empresas.filter(e => e.ativo).reduce((s, e) => s + (e.saldo_inicial || 0), 0)
      : empresaAtual?.saldo_inicial || 0;

    // Previsto: saldo_inicial + acumulado orçamentos semana a semana (p1)
    let acumPrev = si;
    const previstoPoints: number[] = [];
    weeks.forEach(w => {
      const sStr = format(w.start, 'yyyy-MM-dd');
      const eStr = format(w.end, 'yyyy-MM-dd');
      let weekNet = 0;
      orcamentos.forEach(o => {
        if (o.data_ref < sStr || o.data_ref > eStr) return;
        const cat = mapaT[o.conta];
        if (!cat) return;

        // Apply acao_cfo multiplier
        let mult = 1.0;
        if (acaoCfo.length > 0) {
          const rules = acaoCfo.filter(r =>
            r.categoria === cat &&
            (r.conta_nome === 'todas' || r.conta_nome === o.conta) &&
            r.data_inicio <= o.data_ref
          );
          if (rules.length > 0) {
            mult = 1 + (Number(rules[rules.length - 1].pct) / 100);
          }
        }

        const val = Number(o.p1 || 0) * mult;
        if (CATEGORIAS_RECEITA.includes(cat)) weekNet += val;
        else weekNet -= val;
      });
      acumPrev += weekNet;
      previstoPoints.push(acumPrev);
    });

    // Realizado + Previsto: actual data until today, then projected future
    let acumReal = si;
    const realizadoPoints: (number | null)[] = [];
    weeks.forEach((w, idx) => {
      const sStr = format(w.start, 'yyyy-MM-dd');
      const eStr = format(w.end, 'yyyy-MM-dd');

      if (eStr <= todayStr) {
        // Past week — use actual data
        let weekNet = 0;
        lancamentos.forEach(l => {
          if (!l.ativo || l.data_real < sStr || l.data_real > eStr) return;
          const cat = mapaT[l.conta];
          if (!cat) return;
          if (CATEGORIAS_RECEITA.includes(cat)) weekNet += Number(l.valor);
          else weekNet -= Number(l.valor);
        });
        pendencias.forEach(p => {
          if (p.data < sStr || p.data > eStr) return;
          if (p.tipo === 'entrada') weekNet += Number(p.valor);
          else weekNet -= Number(p.valor);
        });
        acumReal += weekNet;
        realizadoPoints.push(acumReal);
      } else if (sStr <= todayStr && eStr > todayStr) {
        // Current week — partial actual + rest projected
        let weekNet = 0;
        lancamentos.forEach(l => {
          if (!l.ativo || l.data_real < sStr || l.data_real > todayStr) return;
          const cat = mapaT[l.conta];
          if (!cat) return;
          if (CATEGORIAS_RECEITA.includes(cat)) weekNet += Number(l.valor);
          else weekNet -= Number(l.valor);
        });
        pendencias.forEach(p => {
          if (p.data < sStr || p.data > todayStr) return;
          if (p.tipo === 'entrada') weekNet += Number(p.valor);
          else weekNet -= Number(p.valor);
        });
        // Add remaining projected days
        orcamentos.forEach(o => {
          if (o.data_ref <= todayStr || o.data_ref > eStr) return;
          const cat = mapaT[o.conta];
          if (!cat) return;
          const val = Number(o.p1 || 0);
          if (CATEGORIAS_RECEITA.includes(cat)) weekNet += val;
          else weekNet -= val;
        });
        acumReal += weekNet;
        realizadoPoints.push(acumReal);
      } else {
        // Future — use projected (same as previsto but starting from realized cumulative)
        let weekNet = 0;
        orcamentos.forEach(o => {
          if (o.data_ref < sStr || o.data_ref > eStr) return;
          const cat = mapaT[o.conta];
          if (!cat) return;
          const val = Number(o.p1 || 0);
          if (CATEGORIAS_RECEITA.includes(cat)) weekNet += val;
          else weekNet -= val;
        });
        acumReal += weekNet;
        realizadoPoints.push(acumReal);
      }
    });

    // Find minimums
    let minPrev = { label: weeks[0]?.label || '', value: previstoPoints[0] || 0 };
    previstoPoints.forEach((v, i) => { if (v < minPrev.value) minPrev = { label: weeks[i].label, value: v }; });

    let minReal = { label: weeks[0]?.label || '', value: realizadoPoints[0] || 0 };
    realizadoPoints.forEach((v, i) => { if (v !== null && v < (minReal.value ?? Infinity)) minReal = { label: weeks[i].label, value: v as number }; });

    const chartData = weeks.map((w, i) => ({
      label: w.label,
      previsto: previstoPoints[i],
      realizado: realizadoPoints[i],
    }));

    const needsCapital = minPrev.value < 0 || (minReal.value ?? 0) < 0;

    return { chartData, minPrevisto: minPrev, minRealizado: minReal, needsCapital };
  }, [planoContas, orcamentos, lancamentos, pendencias, acaoCfo, empresaAtual, isAllMode, empresas]);


  const top10Acima = useMemo(() => {
    return Object.entries(aggData.byConta)
      .filter(([, v]) => CATEGORIAS_DESPESA.includes(v.categoria) && v.real > v.p1 + 0.01)
      .sort((a, b) => (b[1].real - b[1].p1) - (a[1].real - a[1].p1))
      .slice(0, 10)
      .map(([nome, v]) => ({ nome, real: v.real, proj: v.p1, diff: v.real - v.p1 }));
  }, [aggData]);

  const top10Abaixo = useMemo(() => {
    return Object.entries(aggData.byConta)
      .filter(([, v]) => CATEGORIAS_DESPESA.includes(v.categoria) && v.real < v.p1)
      .sort((a, b) => (a[1].real - a[1].p1) - (b[1].real - b[1].p1))
      .slice(0, 10)
      .map(([nome, v]) => ({ nome, real: v.real, proj: v.p1, economia: v.p1 - v.real }));
  }, [aggData]);

  const ofensorColors = ['#E53E3E', '#DD6B20', '#ECC94B', '#A0AEC0', '#A0AEC0'];

  if (loading) return <div className="flex items-center justify-center h-64" style={{ color: '#94A3B8' }}>Carregando...</div>;

  const cardStyle: React.CSSProperties = { background: '#fff', border: '1px solid #E8EDF5', borderRadius: 24, boxShadow: '0 1px 4px rgba(111,169,255,0.04)', padding: 28, display: 'flex', flexDirection: 'column' };

  return (
    <div className="grid gap-5" style={{ gridTemplateColumns: '1fr' }}>
      {/* Período de Análise */}
      <div className="flex flex-wrap items-center gap-4 px-6 py-4" style={{ background: '#fff', border: '1px solid #E8EDF5', borderRadius: 24 }}>
        <span className="text-xs font-semibold uppercase tracking-wider" style={{ color: '#94A3B8' }}>Período de Análise</span>
        <div className="flex items-center gap-2">
          <Calendar size={14} style={{ color: '#94A3B8' }} />
          <input type="date" value={dateStart} onChange={e => setDateStart(e.target.value)}
            className="text-sm" style={{ height: 36, borderRadius: 12, border: '1px solid #E8EDF5', padding: '0 10px', background: '#FAFBFE' }} />
          <span className="text-xs" style={{ color: '#CBD5E1' }}>até</span>
          <input type="date" value={dateEnd} onChange={e => setDateEnd(e.target.value)}
            className="text-sm" style={{ height: 36, borderRadius: 12, border: '1px solid #E8EDF5', padding: '0 10px', background: '#FAFBFE' }} />
        </div>
      </div>

      {/* KPIs — principal destacado */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <div style={{
          ...cardStyle,
          background: dre.resultado_liquido.real >= 0
            ? 'linear-gradient(135deg, #F0FDF4 0%, #fff 100%)'
            : 'linear-gradient(135deg, #FFF5F5 0%, #fff 100%)',
          borderColor: dre.resultado_liquido.real >= 0 ? '#BBF7D0' : '#FECACA',
          padding: '28px 32px',
        }}>
          <div className="mb-2 flex items-center gap-2" style={{ fontSize: 12, color: '#94A3B8', fontWeight: 500 }}>
            <Wallet size={16} style={{ color: 'var(--color-primary, #6FA9FF)' }} /> Resultado Líquido
          </div>
          <div style={{ fontSize: 32, color: dre.resultado_liquido.real >= 0 ? '#046C4E' : '#C53030', fontWeight: 700, letterSpacing: '-0.03em' }}>
            {formatCurrency(dre.resultado_liquido.real)}
          </div>
          <div className="text-xs mt-2" style={{ color: '#94A3B8' }}>No período selecionado</div>
        </div>
        <KPICard label="Saldo em Bancos" value={formatCurrency(saldoBancos)} color="var(--color-primary, #6FA9FF)" icon={<Landmark size={16} />} />
        {Math.abs(checkAuditoria) < 0.01 ? (
          <div
            onClick={() => setShowAuditDetail(true)}
            className="hover:shadow-md active:scale-[0.98] animate-fade-in"
            style={{
              background: 'linear-gradient(135deg, #F0FDF4 0%, #ECFDF5 50%, #fff 100%)',
              border: '1px solid #BBF7D0',
              borderRadius: 24,
              boxShadow: '0 2px 12px rgba(4,108,78,0.08)',
              padding: '24px 28px',
              cursor: 'pointer',
              transition: 'box-shadow 0.2s, transform 0.15s',
            }}
          >
            <div className="mb-3 flex items-center gap-2" style={{ fontSize: 12, color: '#94A3B8', fontWeight: 500 }}>
              <span style={{ color: '#046C4E' }}><Shield size={16} /></span>
              Check de Conciliação
            </div>
            <div className="flex items-center gap-3">
              <span style={{ fontSize: 28 }} className="animate-scale-in">👏</span>
              <div>
                <div style={{ fontSize: 18, color: '#046C4E', fontWeight: 700, letterSpacing: '-0.02em' }}>Tudo conciliado!</div>
                <div className="text-xs mt-0.5" style={{ color: '#6EE7B7' }}>Parabéns, seu check está zerado</div>
              </div>
            </div>
            <div className="text-[10px] mt-2" style={{ color: '#CBD5E1' }}>Clique para ver detalhes</div>
          </div>
        ) : (
          <KPICard
            label="Check de Conciliação"
            value={checkAuditoria > 0 ? `+ ${formatCurrency(checkAuditoria)}` : `- ${formatCurrency(Math.abs(checkAuditoria))}`}
            color={checkAuditoria > 0 ? 'var(--color-primary, #6FA9FF)' : '#C53030'}
            borderColor={checkAuditoria > 0 ? 'var(--color-primary, #6FA9FF)' : '#C53030'}
            icon={<Shield size={16} />}
            onClick={() => setShowAuditDetail(true)}
          />
        )}
      </div>

      {/* Saldos por banco — empresa específica */}
      {!isAllMode && bancos.length > 0 && (
        <div style={cardStyle}>
          <SectionTitle icon={<Landmark size={16} />} title="Saldo por Banco" />
          <div className="flex flex-wrap gap-3">
            {bancos.map(b => (
              <div key={b.id} className="px-4 py-3" style={{ borderRadius: 16, border: '1px solid #E8EDF5', background: '#FAFBFE' }}>
                <div className="text-xs" style={{ color: '#94A3B8' }}>{b.nome}</div>
                <div className="font-bold text-sm" style={{ color: '#64748B' }}>{formatCurrency(Number(b.saldo || 0))}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Saldos consolidados — todas empresas */}
      {isAllMode && bancos.length > 0 && (
        <div style={cardStyle}>
          <SectionTitle icon={<Building2 size={16} />} title="Saldos por Empresa" />
          <div className="flex flex-wrap gap-3">
            {empresas.filter(e => e.ativo).map(emp => {
              const empBancos = bancos.filter(b => b.empresa_id === emp.id);
              const total = empBancos.reduce((s, b) => s + Number(b.saldo || 0), 0);
              return (
                <div key={emp.id} className="px-4 py-3" style={{ borderRadius: 16, border: '1px solid #E8EDF5', background: '#FAFBFE' }}>
                  <div className="text-xs" style={{ color: '#94A3B8' }}>{emp.nome}</div>
                  <div className="font-bold text-sm" style={{ color: '#64748B' }}>{formatCurrency(total)}</div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 2x2 grid — Pendências | Indicadores | Cenários | Top5 */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Pendências */}
        <div style={cardStyle}>
          <SectionTitle icon={<AlertTriangle size={16} />} title="Pendências Não Identificadas" />
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 flex-1">
            <PendCard title="Entradas Pendentes" total={pendEntradas.reduce((s, p) => s + Number(p.valor), 0)} status={getPendStatus(pendEntradas)} icon={<ArrowUpCircle size={14} />} onClick={onNavigate ? () => onNavigate('conciliacao') : undefined} />
            <PendCard title="Saídas Pendentes" total={pendSaidas.reduce((s, p) => s + Number(p.valor), 0)} status={getPendStatus(pendSaidas)} icon={<ArrowDownCircle size={14} />} onClick={onNavigate ? () => onNavigate('conciliacao') : undefined} />
          </div>
        </div>

        {/* Indicadores de Eficiência */}
        <div style={cardStyle}>
          <SectionTitle icon={<Zap size={16} />} title="Indicadores de Eficiência" />
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 flex-1">
            <EficienciaCard label="EBITDA" value={margemEbitda} threshold={15} />
            <EficienciaCard label="Margem Líquida" value={margemLiquida} threshold={10} />
            <div className="p-5" style={{ borderRadius: 24, background: '#FAFBFE', border: '1px solid #E8EDF5' }}>
              <div className="text-xs mb-3" style={{ color: '#94A3B8', fontWeight: 500 }}>Break-Even</div>
              <div className="font-bold text-2xl" style={{ letterSpacing: '-0.03em', color: '#334155' }}>{formatCurrency(pontoEquilibrio)}</div>
              <div className="text-xs mt-3" style={{ color: '#CBD5E1' }}>Valor mínimo para cobrir despesas fixas.</div>
            </div>
          </div>
        </div>

        {/* Cenários de Caixa */}
        <div style={cardStyle}>
          <SectionTitle icon={<Crosshair size={16} />} title="Cenários de Caixa" />
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 flex-1">
            <CenarioCard title="Conservador" value={dre.resultado_liquido.p1} dre={dre} tipo="p1" />
            <CenarioCard title={`Moderado (+${c2Pct}%)`} value={dre.resultado_liquido.p2} dre={dre} tipo="p2" />
            <CenarioCard title={`Otimista (+${c3Pct}%)`} value={dre.resultado_liquido.p3} dre={dre} tipo="p3" />
            <CenarioCardReal dre={dre} />
          </div>
        </div>

        {/* Top 5 Maiores Despesas */}
        <div style={cardStyle}>
          <SectionTitle icon={<TrendingDown size={16} />} title="Top 5 Maiores Despesas" />
          {top5Ofensores.length === 0 ? (
            <EmptyState text="Nenhuma despesa registrada no período. Adicione lançamentos na aba Realizado." />
          ) : (
            <div className="space-y-3 flex-1">
              {top5Ofensores.map((o, i) => (
                <div key={o.nome}>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="font-medium">{o.nome}</span>
                    <span>{formatCurrency(o.valor)} ({formatPercent(o.pct)})</span>
                  </div>
                  <div className="h-2 rounded-full overflow-hidden" style={{ background: '#F1F5F9' }}>
                    <div className="h-full rounded-full" style={{ width: `${o.pct}%`, backgroundColor: ofensorColors[i] }} />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Radar Fundo de Caixa */}
      <div style={cardStyle}>
        <SectionTitle icon={<Anchor size={16} />} title="Radar Fundo de Caixa (Risco Anual)" />
        {(() => {
          // Determine how many weeks have actual data (past + current)
          const todayStr3 = format(new Date(), 'yyyy-MM-dd');
          // Parse week labels to find which are past
          const enriched = fundoCaixaData.chartData.map((w, i) => {
            // label format: "dd/MM a dd/MM" — extract end date
            const parts = w.label.split(' a ');
            const endParts = parts[1]?.split('/');
            const year = new Date().getFullYear();
            const endDate = endParts ? `${year}-${endParts[1]}-${endParts[0]}` : '9999-99-99';
            const isPast = endDate <= todayStr3;
            return { ...w, idx: i, isPast, minSaldo: Math.min(w.previsto, isPast ? (w.realizado ?? Infinity) : Infinity) };
          });
          const sorted = [...enriched]
            .sort((a, b) => a.minSaldo - b.minSaldo)
            .slice(0, 5);
          const anyNegative = sorted.some(w => w.minSaldo < 0);
          const valColor = (v: number) => v < 0 ? '#C53030' : v <= 10000 ? '#DD6B20' : '#046C4E';
          return (
            <>
              {anyNegative && (
                <div className="flex items-center gap-2.5 mb-4 px-5 py-4" style={{ borderRadius: 16, border: '1px solid #FECACA', background: 'linear-gradient(135deg, #FFF5F5 0%, #FEF2F2 100%)' }}>
                  <AlertTriangle size={18} style={{ color: '#C53030', flexShrink: 0 }} />
                  <div>
                    <div className="text-sm font-bold" style={{ color: '#C53030' }}>Atenção: Necessidade de Capital de Giro</div>
                    <div className="text-xs mt-0.5" style={{ color: '#94A3B8' }}>Existem semanas com saldo negativo projetado. Considere antecipar receitas ou buscar linhas de crédito.</div>
                  </div>
                </div>
              )}
              <div className="space-y-3">
                {sorted.map((w) => {
                  const isDanger = w.minSaldo < 0;
                  const isWarning = w.minSaldo >= 0 && w.minSaldo <= 10000;
                  const bg = isDanger ? '#FFF5F5' : isWarning ? '#FFFBEB' : '#F0FDF4';
                  const border = isDanger ? '#FECACA' : isWarning ? '#FDE68A' : '#BBF7D0';
                  return (
                    <div key={w.idx} className="flex items-center justify-between px-6 py-4" style={{
                      borderRadius: 16, border: `1px solid ${border}`, background: bg,
                    }}>
                      <div className="font-bold text-sm uppercase" style={{ color: '#334155', minWidth: 180 }}>
                        SEMANA {w.label}
                      </div>
                      <div className="text-sm" style={{ color: '#94A3B8' }}>
                        PROJETADO: <span className="font-bold" style={{ color: valColor(w.previsto) }}>{formatCurrency(w.previsto)}</span>
                      </div>
                      <div className="text-sm" style={{ color: '#94A3B8' }}>
                        REALIZADO: <span className="font-bold" style={{ color: w.isPast ? valColor(w.realizado ?? 0) : '#94A3B8' }}>
                          {w.isPast ? formatCurrency(w.realizado ?? 0) : 'R$ 0,00'}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </>
          );
        })()}
      </div>

      {/* Distribuição de Despesas + Faturamento */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <div style={cardStyle}>
          <SectionTitle icon={<PieChart size={16} />} title="Distribuição de Despesas" />
          {donutData.length > 0 ? (
            <EChartsDonut data={donutData} />
          ) : (
            <EmptyState text="Sem dados suficientes. Registre lançamentos para ver a distribuição." height={264} />
          )}
        </div>
        <div style={cardStyle}>
          <SectionTitle icon={<PieChart size={16} />} title="Faturamento por Subcategoria" />
          {faturamentoDonutData.length > 0 ? (
            <EChartsDonut data={faturamentoDonutData} />
          ) : (
            <EmptyState text="Sem dados de faturamento no período. Registre receitas com valor faturado." height={264} />
          )}
        </div>
      </div>

      {/* Semana Passada + Próximas Semanas */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <div style={cardStyle}>
          <SectionTitle icon={<ArrowLeftCircle size={16} />} title="Semana Passada" />
          <div className="space-y-3 mt-4">
            {radarData.past.length > 0 ? radarData.past.map((w, i) => (
              <RadarWeekCard key={i} week={w} isPast={true} />
            )) : <EmptyState text="Sem dados da semana passada" height={120} />}
          </div>
        </div>
        <div style={cardStyle}>
          <SectionTitle icon={<ArrowRightCircle size={16} />} title="Próximas Semanas" />
          <div className="space-y-3 mt-4">
            {radarData.future.length > 0 ? radarData.future.map((w, i) => (
              <RadarWeekCard key={i} week={w} isPast={false} />
            )) : <EmptyState text="Sem previsões para as próximas semanas" height={120} />}
          </div>
        </div>
      </div>

      {/* Gráficos */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <div style={cardStyle}>
          <SectionTitle icon={<BarChart3 size={16} />} title="Cascata do Resultado" />
          <EChartsWaterfall data={waterfallData} />
        </div>
        <div style={cardStyle}>
          <SectionTitle icon={<Activity size={16} />} title="Evolução do Saldo" />
          <EChartsLine data={lineData} />
        </div>
      </div>

      {/* Top 10 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <div style={cardStyle}>
          <SectionTitle icon={<Trophy size={16} />} title="Top 10 Contas com Maior Economia" />
          {top10Abaixo.length === 0 ? (
            <EmptyState text="Sem dados suficientes para análise de economia." />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead><tr style={{ background: '#FAFBFE' }}>
                  <th className="px-3 py-2.5 text-left" style={{ color: '#94A3B8' }}>Conta</th>
                  <th className="px-3 py-2.5 text-right" style={{ color: '#94A3B8' }}>Previsto</th>
                  <th className="px-3 py-2.5 text-right" style={{ color: '#94A3B8' }}>Realizado</th>
                  <th className="px-3 py-2.5 text-right" style={{ color: '#94A3B8' }}>Economia</th>
                </tr></thead>
                <tbody>{top10Abaixo.map(t => (
                  <tr key={t.nome} className="border-b" style={{ borderColor: '#E8EDF5' }}>
                    <td className="px-3 py-2.5 font-medium">{t.nome}</td>
                    <td className="px-3 py-2.5 text-right">{formatCurrency(t.proj)}</td>
                    <td className="px-3 py-2.5 text-right">{formatCurrency(t.real)}</td>
                    <td className="px-3 py-2.5 text-right font-semibold" style={{ color: '#046C4E' }}>{formatCurrency(t.economia)}</td>
                  </tr>
                ))}</tbody>
              </table>
            </div>
          )}
        </div>
        <div style={cardStyle}>
          <SectionTitle icon={<AlertCircle size={16} />} title="Top 10 Contas com Maior Excesso" />
          {top10Acima.length === 0 ? (
            <EmptyState text="Sem dados suficientes para análise de excesso." />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead><tr style={{ background: '#FAFBFE' }}>
                  <th className="px-3 py-2.5 text-left" style={{ color: '#94A3B8' }}>Conta</th>
                  <th className="px-3 py-2.5 text-right" style={{ color: '#94A3B8' }}>Previsto</th>
                  <th className="px-3 py-2.5 text-right" style={{ color: '#94A3B8' }}>Realizado</th>
                  <th className="px-3 py-2.5 text-right" style={{ color: '#94A3B8' }}>Excesso</th>
                </tr></thead>
                <tbody>{top10Acima.map(t => (
                  <tr key={t.nome} className="border-b" style={{ borderColor: '#E8EDF5' }}>
                    <td className="px-3 py-2.5 font-medium">{t.nome}</td>
                    <td className="px-3 py-2.5 text-right">{formatCurrency(t.proj)}</td>
                    <td className="px-3 py-2.5 text-right">{formatCurrency(t.real)}</td>
                    <td className="px-3 py-2.5 text-right font-semibold" style={{ color: '#C53030' }}>{formatCurrency(Math.abs(t.diff))}</td>
                  </tr>
                ))}</tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Audit Detail Modal */}
      {showAuditDetail && (
        <div className="fixed inset-0 z-50 flex items-center justify-center" style={{ background: 'rgba(0,0,0,0.4)' }} onClick={() => setShowAuditDetail(false)}>
          <div className="bg-white rounded-3xl shadow-xl w-full max-w-2xl max-h-[80vh] overflow-auto p-6 m-4" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-5">
              <h2 className="font-bold text-lg flex items-center gap-2" style={{ color: 'var(--color-text, #334155)' }}>
                <Shield size={18} style={{ color: 'var(--color-primary, #6FA9FF)' }} /> Detalhamento do Check de Conciliação
              </h2>
              <button onClick={() => setShowAuditDetail(false)} className="text-2xl leading-none" style={{ color: '#94A3B8' }}>&times;</button>
            </div>

            {/* Summary */}
            <div className="grid grid-cols-3 gap-3 mb-5">
              <div className="p-3 rounded-2xl" style={{ background: '#F0FDF4', border: '1px solid #BBF7D0' }}>
                <div className="text-[10px] font-medium mb-1" style={{ color: '#94A3B8' }}>Saldo em Bancos</div>
                <div className="font-bold text-sm" style={{ color: '#046C4E' }}>{formatCurrency(saldoBancos)}</div>
              </div>
              <div className="p-3 rounded-2xl" style={{ background: '#EFF6FF', border: '1px solid #BFDBFE' }}>
                <div className="text-[10px] font-medium mb-1" style={{ color: '#94A3B8' }}>Resultado Acumulado</div>
                <div className="font-bold text-sm" style={{ color: '#1A2B6D' }}>{formatCurrency(resultadoAllTime)}</div>
              </div>
              <div className="p-3 rounded-2xl" style={{ background: Math.abs(checkAuditoria) < 0.01 ? '#F0FDF4' : '#FFF5F5', border: `1px solid ${Math.abs(checkAuditoria) < 0.01 ? '#BBF7D0' : '#FECACA'}` }}>
                <div className="text-[10px] font-medium mb-1" style={{ color: '#94A3B8' }}>Diferença</div>
                <div className="font-bold text-sm" style={{ color: Math.abs(checkAuditoria) < 0.01 ? '#046C4E' : '#C53030' }}>
                  {Math.abs(checkAuditoria) < 0.01 ? 'R$ 0,00' : formatCurrency(checkAuditoria)}
                </div>
              </div>
            </div>

            {/* Formula */}
            <div className="text-xs mb-4 p-3 rounded-xl" style={{ background: '#FAFBFE', border: '1px solid #E8EDF5', color: '#64748B' }}>
              <strong>Fórmula:</strong> Saldo em Bancos − (Saldo Inicial + Entradas − Saídas + Pendências Entrada − Pendências Saída) = Diferença
            </div>

            {/* Saldo Inicial */}
            <div className="flex items-center justify-between py-2 px-3 mb-2 rounded-xl" style={{ background: '#EFF6FF' }}>
              <span className="text-xs font-semibold" style={{ color: '#1A2B6D' }}>Saldo Inicial</span>
              <span className="text-sm font-bold" style={{ color: '#1A2B6D' }}>{formatCurrency(saldoInicial)}</span>
            </div>

            {/* Lancamentos by category */}
            {CATEGORIAS_DRE.map(cat => {
              const data = auditBreakdown.byCat[cat.value];
              if (!data || data.items.length === 0) return null;
              const isReceita = data.tipo === 'entrada';
              return (
                <div key={cat.value} className="mb-3">
                  <div className="flex items-center justify-between py-2 px-3 rounded-xl" style={{ background: isReceita ? '#F0FDF4' : '#FFF5F5' }}>
                    <span className="text-xs font-semibold" style={{ color: isReceita ? '#046C4E' : '#C53030' }}>{isReceita ? '(+)' : '(-)'} {cat.label}</span>
                    <span className="text-sm font-bold" style={{ color: isReceita ? '#046C4E' : '#C53030' }}>{formatCurrency(data.total)}</span>
                  </div>
                  <div className="ml-4 mt-1 space-y-0.5">
                    {data.items.slice(0, 20).map((item: any, i: number) => (
                      <div key={item.id || i} className="flex items-center justify-between text-[11px] py-1 px-2" style={{ color: '#64748B' }}>
                        <span className="truncate flex-1">{item.conta} {item.descricao ? `– ${item.descricao}` : ''}</span>
                        <span className="ml-2 font-medium tabular-nums">{item.data_real}</span>
                        <span className="ml-3 font-semibold tabular-nums" style={{ color: isReceita ? '#046C4E' : '#C53030', minWidth: 80, textAlign: 'right' }}>{formatCurrency(Number(item.valor))}</span>
                      </div>
                    ))}
                    {data.items.length > 20 && <div className="text-[10px] px-2 py-1" style={{ color: '#94A3B8' }}>... e mais {data.items.length - 20} lançamentos</div>}
                  </div>
                </div>
              );
            })}

            {/* Pendencias */}
            {auditBreakdown.pendEntGroup.length > 0 && (
              <div className="mb-3">
                <div className="flex items-center justify-between py-2 px-3 rounded-xl" style={{ background: '#F0FDF4' }}>
                  <span className="text-xs font-semibold" style={{ color: '#046C4E' }}>(+) Pendências de Entrada</span>
                  <span className="text-sm font-bold" style={{ color: '#046C4E' }}>{formatCurrency(auditBreakdown.pendEntGroup.reduce((s: number, p: any) => s + Number(p.valor), 0))}</span>
                </div>
                <div className="ml-4 mt-1 space-y-0.5">
                  {auditBreakdown.pendEntGroup.map((p: any) => (
                    <div key={p.id} className="flex items-center justify-between text-[11px] py-1 px-2" style={{ color: '#64748B' }}>
                      <span className="truncate flex-1">{p.descricao || p.observacao || 'Pendência'}</span>
                      <span className="ml-2 font-medium tabular-nums">{p.data}</span>
                      <span className="ml-3 font-semibold tabular-nums" style={{ color: '#046C4E', minWidth: 80, textAlign: 'right' }}>{formatCurrency(Number(p.valor))}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {auditBreakdown.pendSaiGroup.length > 0 && (
              <div className="mb-3">
                <div className="flex items-center justify-between py-2 px-3 rounded-xl" style={{ background: '#FFF5F5' }}>
                  <span className="text-xs font-semibold" style={{ color: '#C53030' }}>(-) Pendências de Saída</span>
                  <span className="text-sm font-bold" style={{ color: '#C53030' }}>{formatCurrency(auditBreakdown.pendSaiGroup.reduce((s: number, p: any) => s + Number(p.valor), 0))}</span>
                </div>
                <div className="ml-4 mt-1 space-y-0.5">
                  {auditBreakdown.pendSaiGroup.map((p: any) => (
                    <div key={p.id} className="flex items-center justify-between text-[11px] py-1 px-2" style={{ color: '#64748B' }}>
                      <span className="truncate flex-1">{p.descricao || p.observacao || 'Pendência'}</span>
                      <span className="ml-2 font-medium tabular-nums">{p.data}</span>
                      <span className="ml-3 font-semibold tabular-nums" style={{ color: '#C53030', minWidth: 80, textAlign: 'right' }}>{formatCurrency(Number(p.valor))}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Saldo Bancos breakdown */}
            {bancos.length > 0 && (
              <div className="mb-3">
                <div className="flex items-center justify-between py-2 px-3 rounded-xl" style={{ background: '#EFF6FF' }}>
                  <span className="text-xs font-semibold" style={{ color: '#1A2B6D' }}>Saldo em Bancos</span>
                  <span className="text-sm font-bold" style={{ color: '#1A2B6D' }}>{formatCurrency(saldoBancos)}</span>
                </div>
                <div className="ml-4 mt-1 space-y-0.5">
                  {bancos.map((b: any) => (
                    <div key={b.id} className="flex items-center justify-between text-[11px] py-1 px-2" style={{ color: '#64748B' }}>
                      <span className="truncate flex-1">{b.nome}</span>
                      <span className="font-semibold tabular-nums" style={{ color: '#1A2B6D', minWidth: 80, textAlign: 'right' }}>{formatCurrency(Number(b.saldo || 0))}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="flex justify-end mt-4">
              <button onClick={() => { setShowAuditDetail(false); onNavigate?.('conciliacao'); }} className="text-xs font-semibold px-5 py-2 rounded-xl text-white" style={{ background: 'var(--color-button-gradient, var(--color-button, var(--color-primary)))' }}>
                Ir para Conciliação
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ── Sub-components ──

function SectionTitle({ icon, title }: { icon: React.ReactNode; title: string }) {
  return (
    <h3 className="mb-5 flex items-center gap-2.5" style={{ color: 'var(--color-text, #334155)', fontWeight: 700, fontSize: 15, letterSpacing: '-0.02em' }}>
      <span style={{ color: 'var(--color-primary, #6FA9FF)' }}>{icon}</span>
      {title}
    </h3>
  );
}

function EmptyState({ text, height, icon }: { text: string; height?: number; icon?: React.ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 py-6" style={{ height, color: '#CBD5E1' }}>
      {icon && <span style={{ color: '#94A3B8' }}>{icon}</span>}
      <div className="text-sm text-center" style={{ maxWidth: 280 }}>{text}</div>
    </div>
  );
}

function KPICard({ label, value, color, borderColor, icon, onClick }: { label: string; value: string; color: string; borderColor?: string; icon?: React.ReactNode; onClick?: () => void }) {
  return (
    <div
      onClick={onClick}
      style={{
        background: '#fff',
        border: `1px solid ${borderColor ? borderColor + '30' : '#E8EDF5'}`,
        borderRadius: 24,
        boxShadow: '0 1px 4px rgba(111,169,255,0.04)',
        padding: '24px 28px',
        cursor: onClick ? 'pointer' : 'default',
        transition: 'box-shadow 0.2s, transform 0.15s',
      }}
      className={onClick ? 'hover:shadow-md active:scale-[0.98]' : ''}
    >
      <div className="mb-3 flex items-center gap-2" style={{ fontSize: 12, color: '#94A3B8', fontWeight: 500 }}>
        <span style={{ color: 'var(--color-primary, #6FA9FF)' }}>{icon}</span>
        {label}
      </div>
      <div style={{ fontSize: 28, color, fontWeight: 700, letterSpacing: '-0.03em' }}>{value}</div>
      {onClick && <div className="text-[10px] mt-2" style={{ color: '#CBD5E1' }}>Clique para conciliar</div>}
    </div>
  );
}

function PendCard({ title, total, status, icon, onClick }: { title: string; total: number; status: { label: string; color: string }; icon: React.ReactNode; onClick?: () => void }) {
  return (
    <div
      onClick={onClick}
      className={`p-5 relative ${onClick ? 'hover:shadow-md active:scale-[0.98]' : ''}`}
      style={{ border: `1px solid #E8EDF5`, borderRadius: 24, background: '#fff', cursor: onClick ? 'pointer' : 'default', transition: 'box-shadow 0.2s, transform 0.15s' }}
    >
      <div className="text-xs font-medium mb-3 flex items-center gap-1.5" style={{ color: '#94A3B8' }}>{icon} {title}</div>
      <div className="font-bold text-xl" style={{ color: '#334155', letterSpacing: '-0.02em' }}>{formatCurrency(total)}</div>
      <span className="absolute top-4 right-4 text-xs px-3 py-1 rounded-full font-medium" style={{ background: status.color + '10', color: status.color }}>{status.label}</span>
      {onClick && <div className="text-[10px] mt-2" style={{ color: '#CBD5E1' }}>Clique para conciliar</div>}
    </div>
  );
}

function CenarioCard({ title, value, dre, tipo }: { title: string; value: number; dre: any; tipo: string }) {
  const entProj = (dre.receita_bruta[tipo] || 0) + (dre.outras_receitas[tipo] || 0);
  const saiProj = (dre.deducoes[tipo] || 0) + (dre.custos_variaveis[tipo] || 0) + (dre.despesas_operacionais[tipo] || 0) + (dre.despesas_financeiras?.[tipo] || 0) + (dre.distribuicao_lucro[tipo] || 0);
  return (
    <details className="p-5 rounded-2xl cursor-pointer transition-all hover:shadow-sm" style={{ border: '1px solid #E8EDF5', background: '#fff' }}>
      <summary className="font-medium text-xs flex justify-between items-center list-none [&::-webkit-details-marker]:hidden">
        <span style={{ color: '#94A3B8' }}>{title}</span>
        <div className="text-right">
          <span className="font-bold text-lg" style={{ color: value >= 0 ? '#046C4E' : '#C53030', letterSpacing: '-0.02em' }}>{formatCurrency(value)}</span>
          <div className="flex items-center gap-1 mt-1 text-[11px] justify-end" style={{ color: '#94A3B8' }}>
            <ChevronDown size={12} /> ver mais detalhes
          </div>
        </div>
      </summary>
      <div className="mt-4 text-xs space-y-2 pt-3" style={{ borderTop: '1px solid #E8EDF5' }}>
        <div className="flex justify-between">
          <span style={{ color: '#94A3B8' }}>Entrada Prevista</span>
          <span style={{ color: '#334155', fontWeight: 500 }}>{formatCurrency(entProj)}</span>
        </div>
        <div className="flex justify-between">
          <span style={{ color: '#94A3B8' }}>Saída Prevista</span>
          <span style={{ color: '#334155', fontWeight: 500 }}>{formatCurrency(saiProj)}</span>
        </div>
      </div>
    </details>
  );
}

function CenarioCardReal({ dre }: { dre: any }) {
  const real = dre.resultado_liquido.real;
  const p1 = dre.resultado_liquido.p1;
  const p2 = dre.resultado_liquido.p2;
  const p3 = dre.resultado_liquido.p3;
  let badge = { label: 'Abaixo do previsto', color: '#C53030' };
  if (real >= p3 && p3 > 0) badge = { label: 'Superou o cenário otimista', color: '#046C4E' };
  else if (real >= p2 && p2 > 0) badge = { label: 'Superou o cenário moderado', color: '#046C4E' };
  else if (real >= p1 && p1 > 0) badge = { label: 'Atingiu o cenário conservador', color: '#046C4E' };
  else if (p1 === 0 && p2 === 0 && p3 === 0) badge = { label: 'Aguardando dados', color: '#94A3B8' };

  const entReal = (dre.receita_bruta.real || 0) + (dre.outras_receitas.real || 0);
  const saiReal = (dre.deducoes.real || 0) + (dre.custos_variaveis.real || 0) + (dre.despesas_operacionais.real || 0) + (dre.despesas_financeiras?.real || 0) + (dre.distribuicao_lucro.real || 0);
  const entProj = (dre.receita_bruta.p1 || 0) + (dre.outras_receitas.p1 || 0);
  const saiProj = (dre.deducoes.p1 || 0) + (dre.custos_variaveis.p1 || 0) + (dre.despesas_operacionais.p1 || 0) + (dre.despesas_financeiras?.p1 || 0) + (dre.distribuicao_lucro.p1 || 0);
  const gapEntrada = entReal - entProj;
  const gapSaida = saiReal - saiProj;

  return (
    <details className="p-5 rounded-2xl cursor-pointer transition-all hover:shadow-sm" style={{ border: '1px solid #E8EDF5', background: '#fff' }}>
      <summary className="font-medium text-xs flex justify-between items-center list-none [&::-webkit-details-marker]:hidden">
        <div>
          <span style={{ color: '#94A3B8' }}>Realizado</span>
          <div className="mt-3">
            <span className="text-xs px-3 py-1 rounded-full font-medium" style={{ background: badge.color + '10', color: badge.color }}>{badge.label}</span>
          </div>
        </div>
        <div className="text-right">
          <span className="font-bold text-lg" style={{ color: real >= 0 ? '#046C4E' : '#C53030', letterSpacing: '-0.02em' }}>{formatCurrency(real)}</span>
          <div className="flex items-center gap-1 mt-2 text-[11px]" style={{ color: '#94A3B8' }}>
            <ChevronDown size={12} /> ver mais detalhes
          </div>
        </div>
      </summary>
      <div className="mt-4 text-xs space-y-2 pt-3" style={{ borderTop: '1px solid #E8EDF5' }}>
        <div className="flex justify-between">
          <span style={{ color: '#94A3B8' }}>Entrada Realizada</span>
          <span style={{ color: '#334155', fontWeight: 500 }}>{formatCurrency(entReal)}</span>
        </div>
        <div className="flex justify-between">
          <span style={{ color: '#94A3B8' }}>Saída Realizada</span>
          <span style={{ color: '#334155', fontWeight: 500 }}>{formatCurrency(saiReal)}</span>
        </div>
        <div className="h-px my-2" style={{ background: '#E8EDF5' }} />
        <div className="flex justify-between">
          <span style={{ color: '#94A3B8' }}>Gap Entrada</span>
          <span className="font-semibold" style={{ color: gapEntrada >= 0 ? '#046C4E' : '#C53030' }}>
            {gapEntrada >= 0 ? '+' : ''}{formatCurrency(gapEntrada)}
          </span>
        </div>
        <div className="flex justify-between">
          <span style={{ color: '#94A3B8' }}>Gap Saída</span>
          <span className="font-semibold" style={{ color: gapSaida <= 0 ? '#046C4E' : '#C53030' }}>
            {gapSaida > 0 ? '+' : ''}{formatCurrency(gapSaida)}
          </span>
        </div>
      </div>
    </details>
  );
}

function EficienciaCard({ label, value, threshold }: { label: string; value: number; threshold: number }) {
  const color = value >= threshold ? '#046C4E' : value > 0 ? '#DD6B20' : '#C53030';
  return (
    <div className="p-5" style={{ borderRadius: 24, background: '#fff', border: '1px solid #E8EDF5' }}>
      <div className="text-xs mb-3" style={{ color: '#94A3B8', fontWeight: 500 }}>{label}</div>
      <div className="font-bold text-2xl" style={{ color, letterSpacing: '-0.03em' }}>{formatPercent(value)}</div>
    </div>
  );
}

function RadarWeekCard({ week, isPast }: { week: any; isPast: boolean }) {
  const saldoColor = week.saldo > 5000 ? '#046C4E' : week.saldo >= 0 ? '#DD6B20' : '#C53030';
  return (
    <div className="flex items-center justify-between p-4 rounded-2xl transition-all" style={{ border: '1px solid #E8EDF5', background: '#FAFBFE' }}>
      <div>
        <div className="text-xs font-semibold" style={{ color: '#334155' }}>{week.label}</div>
        <div className="text-[11px] mt-0.5" style={{ color: '#CBD5E1' }}>{isPast ? 'Realizado' : 'Previsto'}</div>
      </div>
      <div className="text-right text-xs space-y-1">
        <div>Entradas: <span style={{ color: '#046C4E', fontWeight: 600 }}>{formatCurrency(isPast ? week.inReal : week.inProj)}</span></div>
        <div>Saídas: <span style={{ color: '#C53030', fontWeight: 600 }}>{formatCurrency(isPast ? week.outReal : week.outProj)}</span></div>
      </div>
      <span className="text-xs font-bold px-3.5 py-1.5 rounded-full ml-3" style={{ backgroundColor: saldoColor + '10', color: saldoColor }}>
        {formatCurrency(week.saldo)}
      </span>
    </div>
  );
}
