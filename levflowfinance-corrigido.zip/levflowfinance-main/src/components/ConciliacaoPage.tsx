import { useState } from 'react';
import { useEmpresa } from '@/hooks/useEmpresa';
import { useSupabaseData } from '@/hooks/useSupabaseData';
import { supabase } from '@/integrations/supabase/client';
import { formatCurrency, parseCurrencyInput, applyCurrencyMask, formatDate } from '@/lib/formatters';
import { CATEGORIAS_DRE, CATEGORIAS_RECEITA, CATEGORIAS_DESPESA } from '@/lib/constants';
import { CARD, INPUT, BTN_PRIMARY, SECTION_TITLE, LABEL, tabStyle, TAB_CONTAINER } from '@/lib/ui-styles';
import toast from 'react-hot-toast';
import { Landmark, ArrowDownCircle, ArrowUpCircle, CheckCircle, Plus, AlertTriangle, Loader2 } from 'lucide-react';

export default function ConciliacaoPage() {
  const { empresaAtual } = useEmpresa();
  const { bancos, pendencias, planoContas, formasPagamento, refetch } = useSupabaseData();
  const [tab, setTab] = useState<'entradas' | 'saidas'>('entradas');
  const [selectedPend, setSelectedPend] = useState<Set<string>>(new Set());
  const [saving, setSaving] = useState(false);

  const [fData, setFData] = useState(new Date().toISOString().slice(0, 10));
  const [fBanco, setFBanco] = useState('');
  const [fConta, setFConta] = useState('');
  const [fValor, setFValor] = useState('');
  const [fObs, setFObs] = useState('');

  const [resCat, setResCat] = useState('');
  const [resSubconta, setResSubconta] = useState('');

  if (!empresaAtual) return null;

  const empBancos = bancos.filter(b => b.empresa_id === empresaAtual.id);
  const empPend = pendencias.filter(p => p.empresa_id === empresaAtual.id);

  const isEntrada = tab === 'entradas';
  const tipoFilter = isEntrada ? 'entrada' : 'saida';
  const pendNaoIdent = empPend.filter(p => p.tipo === tipoFilter && !p.conta);
  const pendIdent = empPend.filter(p => p.tipo === tipoFilter && p.conta);

  const handleBancoUpdate = async (id: string, saldo: number) => {
    const { error } = await supabase.from('bancos').update({ saldo, ultima_atualizacao: new Date().toISOString().slice(0, 10) }).eq('id', id);
    if (error) toast.error(error.message); else { toast.success('Saldo atualizado!'); refetch(); }
  };

  const handleNovaPend = async () => {
    if (!fValor) { toast.error('Informe o valor'); return; }
    setSaving(true);
    const { error } = await supabase.from('pendencias').insert({
      empresa_id: empresaAtual.id, tipo: tipoFilter, data: fData, banco: fBanco,
      conta: fConta || null, valor: parseCurrencyInput(fValor), observacao: fObs,
    });
    setSaving(false);
    if (error) { toast.error(error.message); return; }
    toast.success('Pendência cadastrada!');
    setFValor(''); setFObs('');
    refetch();
  };

  const handleIdentificar = async () => {
    if (selectedPend.size !== 1) { toast.error('Selecione apenas um item'); return; }
    if (!resSubconta) { toast.error('Selecione a subcategoria'); return; }
    setSaving(true);
    const pendId = Array.from(selectedPend)[0];
    const pend = empPend.find(p => p.id === pendId);
    if (!pend) { setSaving(false); return; }
    await supabase.from('lancamentos_reais').insert({
      empresa_id: empresaAtual.id, conta: resSubconta, valor: Number(pend.valor),
      data_real: pend.data, descricao: pend.observacao || pend.descricao, banco: pend.banco,
    });
    await supabase.from('pendencias').delete().eq('id', pendId);
    setSaving(false);
    toast.success('Identificado e lançado!');
    setSelectedPend(new Set());
    refetch();
  };

  const handleValidarLote = async () => {
    const items = pendIdent;
    const ids = Array.from(selectedPend).filter(id => items.some(i => i.id === id));
    if (ids.length === 0) { toast.error('Selecione ao menos um item para validar'); return; }
    setSaving(true);
    for (const id of ids) {
      const p = items.find(i => i.id === id);
      if (!p) continue;
      await supabase.from('lancamentos_reais').insert({
        empresa_id: empresaAtual.id, conta: p.conta!, valor: Number(p.valor),
        data_real: p.data, descricao: p.observacao || p.descricao, banco: p.banco,
      });
      await supabase.from('pendencias').delete().eq('id', id);
    }
    setSaving(false);
    toast.success(`${ids.length} validado(s)!`);
    setSelectedPend(new Set());
    refetch();
  };

  const recContas = planoContas.filter(p => CATEGORIAS_RECEITA.includes(p.categoria_dre) && p.empresa_id === empresaAtual.id);
  const despContas = planoContas.filter(p => CATEGORIAS_DESPESA.includes(p.categoria_dre) && p.empresa_id === empresaAtual.id);

  return (
    <div className="space-y-6">
      {/* Saldos Bancários */}
      <div style={CARD}>
        <h3 className="font-medium mb-1 flex items-center gap-2" style={{ ...SECTION_TITLE }}><Landmark size={18} style={{ color: '#94A3B8' }} /> Saldos Bancários</h3>
        <p className="text-xs mb-4" style={{ color: '#94A3B8' }}>Atualize o saldo real de cada conta.</p>
        {empBancos.length === 0 ? (
          <div className="text-sm text-center py-4" style={{ color: '#CBD5E1' }}>Nenhuma conta bancária cadastrada. Adicione em Cadastro.</div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {empBancos.map(b => (
              <BancoSaldoCard key={b.id} banco={b} onUpdate={handleBancoUpdate} />
            ))}
          </div>
        )}
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div style={{ ...CARD, borderColor: '#BEE3F8' }}>
          <div className="text-xs font-medium" style={{ color: 'var(--color-primary, #6FA9FF)' }}>Entradas Pendentes ({empPend.filter(p => p.tipo === 'entrada' && !p.conta).length})</div>
          <div className="font-bold text-lg" style={{ color: '#334155' }}>{formatCurrency(empPend.filter(p => p.tipo === 'entrada' && !p.conta).reduce((s, p) => s + Number(p.valor), 0))}</div>
        </div>
        <div style={{ ...CARD, borderColor: '#FEB2B2' }}>
          <div className="text-xs font-medium" style={{ color: '#C53030' }}>Saídas Pendentes ({empPend.filter(p => p.tipo === 'saida' && !p.conta).length})</div>
          <div className="font-bold text-lg" style={{ color: '#334155' }}>{formatCurrency(empPend.filter(p => p.tipo === 'saida' && !p.conta).reduce((s, p) => s + Number(p.valor), 0))}</div>
        </div>
      </div>

      {/* Tabs simplificadas: Entradas | Saídas */}
      <div className="flex flex-wrap gap-2" style={TAB_CONTAINER}>
        <button onClick={() => { setTab('entradas'); setSelectedPend(new Set()); }} style={tabStyle(tab === 'entradas')} className="flex items-center gap-1.5">
          <ArrowDownCircle size={14} /> Entradas
        </button>
        <button onClick={() => { setTab('saidas'); setSelectedPend(new Set()); }} style={tabStyle(tab === 'saidas')} className="flex items-center gap-1.5">
          <ArrowUpCircle size={14} /> Saídas
        </button>
      </div>

      {/* Formulário de nova pendência */}
      <div style={CARD}>
        <h4 className="text-xs font-semibold mb-4" style={{ color: '#64748B' }}>
          Registrar Nova {isEntrada ? 'Entrada' : 'Saída'} Pendente
        </h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
          <div><label className={LABEL} style={{ color: '#94A3B8' }}>Data</label><input type="date" value={fData} onChange={e => setFData(e.target.value)} style={INPUT} /></div>
          <div><label className={LABEL} style={{ color: '#94A3B8' }}>Banco</label><select value={fBanco} onChange={e => setFBanco(e.target.value)} style={INPUT}><option value="">Selecione...</option>{empBancos.map(b => <option key={b.id} value={b.nome}>{b.nome}</option>)}</select></div>
          <div><label className={LABEL} style={{ color: '#94A3B8' }}>Valor</label><input value={fValor} onChange={e => setFValor(applyCurrencyMask(e.target.value))} placeholder="R$ 0,00" style={INPUT} /></div>
          <div><label className={LABEL} style={{ color: '#94A3B8' }}>Observação</label><input value={fObs} onChange={e => setFObs(e.target.value)} style={INPUT} /></div>
        </div>
        <button onClick={handleNovaPend} disabled={saving} className="flex items-center gap-2" style={{ ...BTN_PRIMARY, opacity: saving ? 0.7 : 1 }}>
          {saving ? <Loader2 size={14} className="animate-spin" /> : <Plus size={14} />} Registrar
        </button>
      </div>

      {/* Pendências não identificadas */}
      <div style={CARD}>
        <h4 className="text-xs font-semibold mb-3" style={{ color: '#64748B' }}>
          {isEntrada ? 'Entradas' : 'Saídas'} Não Identificadas ({pendNaoIdent.length})
        </h4>
        {pendNaoIdent.length === 0 ? (
          <div className="text-sm text-center py-4" style={{ color: '#CBD5E1' }}>
            Nenhuma pendência não identificada. Use o formulário acima para registrar.
          </div>
        ) : (
          <>
            <div className="overflow-auto" style={{ maxHeight: 300 }}>
              <table className="w-full text-xs" style={{ minWidth: 500 }}>
               <thead><tr style={{ background: '#FAFBFE' }}>
                  <th className="px-2 py-2.5" style={{ color: '#94A3B8' }}><input type="checkbox" checked={pendNaoIdent.length > 0 && pendNaoIdent.every(p => selectedPend.has(p.id))} onChange={e => { const n = new Set(selectedPend); if (e.target.checked) pendNaoIdent.forEach(p => n.add(p.id)); else pendNaoIdent.forEach(p => n.delete(p.id)); setSelectedPend(n); }} /></th>
                  <th className="px-2 py-2.5 text-left" style={{ color: '#94A3B8' }}>Data</th>
                  <th className="px-2 py-2.5 text-left" style={{ color: '#94A3B8' }}>Banco</th>
                  <th className="px-2 py-2.5 text-left" style={{ color: '#94A3B8' }}>Observação</th>
                  <th className="px-2 py-2.5 text-right" style={{ color: '#94A3B8' }}>Valor</th>
                </tr></thead>
                <tbody>{pendNaoIdent.map(p => (
                  <tr key={p.id} className="border-b" style={{ borderColor: '#E8EDF5' }}>
                    <td className="px-2 py-2 text-center"><input type="checkbox" checked={selectedPend.has(p.id)} onChange={e => { const n = new Set(selectedPend); if (e.target.checked) n.add(p.id); else n.delete(p.id); setSelectedPend(n); }} /></td>
                    <td className="px-2 py-2">{formatDate(p.data)}</td>
                    <td className="px-2 py-2">{p.banco || '-'}</td>
                    <td className="px-2 py-2">{p.observacao || '-'}</td>
                    <td className="px-2 py-2 text-right font-medium">{formatCurrency(Number(p.valor))}</td>
                  </tr>
                ))}</tbody>
              </table>
            </div>
            {selectedPend.size === 1 && (
              <div className="mt-4 p-4" style={{ background: '#FAFBFE', borderRadius: 14 }}>
                <div className="text-xs font-medium mb-2" style={{ color: '#64748B' }}>Identificar esta pendência</div>
                <div className="flex flex-wrap gap-3 items-end">
                  <div><label className={LABEL} style={{ color: '#94A3B8' }}>Categoria</label><select value={resCat} onChange={e => setResCat(e.target.value)} style={{ ...INPUT, height: 36, fontSize: 12 }}><option value="">Selecione...</option>{CATEGORIAS_DRE.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}</select></div>
                  <div><label className={LABEL} style={{ color: '#94A3B8' }}>Subcategoria</label><select value={resSubconta} onChange={e => setResSubconta(e.target.value)} style={{ ...INPUT, height: 36, fontSize: 12 }}><option value="">Selecione...</option>{planoContas.filter(p => p.categoria_dre === resCat && p.empresa_id === empresaAtual.id).map(p => <option key={p.id} value={p.nome_conta}>{p.nome_conta}</option>)}</select></div>
                  <button onClick={handleIdentificar} disabled={saving} className="text-white text-xs font-semibold px-4 flex items-center gap-1.5" style={{ background: 'var(--color-button-gradient, var(--color-button, var(--color-primary)))', height: 36, borderRadius: 12, opacity: saving ? 0.7 : 1 }}>
                    {saving ? <Loader2 size={12} className="animate-spin" /> : <CheckCircle size={12} />} Confirmar
                  </button>
                </div>
              </div>
            )}
            {selectedPend.size > 1 && (
              <div className="mt-2 text-xs flex items-center gap-1" style={{ color: '#DD6B20' }}><AlertTriangle size={12} /> Selecione apenas um item por vez para identificar.</div>
            )}
          </>
        )}
      </div>

      {/* Pendências já identificadas — validar em lote */}
      {pendIdent.length > 0 && (
        <div style={CARD}>
          <h4 className="text-xs font-semibold mb-3" style={{ color: '#64748B' }}>
            {isEntrada ? 'Entradas' : 'Saídas'} Pré-Identificadas — Validar ({pendIdent.length})
          </h4>
          <div className="overflow-auto" style={{ maxHeight: 300 }}>
            <table className="w-full text-xs" style={{ minWidth: 600 }}>
              <thead><tr style={{ background: '#FAFBFE' }}>
                <th className="px-2 py-2.5" style={{ color: '#94A3B8' }}><input type="checkbox" checked={pendIdent.length > 0 && pendIdent.every(p => selectedPend.has(p.id))} onChange={e => { const n = new Set(selectedPend); if (e.target.checked) pendIdent.forEach(p => n.add(p.id)); else pendIdent.forEach(p => n.delete(p.id)); setSelectedPend(n); }} /></th>
                <th className="px-2 py-2.5 text-left" style={{ color: '#94A3B8' }}>Data</th>
                <th className="px-2 py-2.5 text-left" style={{ color: '#94A3B8' }}>Categoria</th>
                <th className="px-2 py-2.5 text-left" style={{ color: '#94A3B8' }}>Banco</th>
                <th className="px-2 py-2.5 text-right" style={{ color: '#94A3B8' }}>Valor</th>
                <th className="px-2 py-2.5 text-left" style={{ color: '#94A3B8' }}>Observação</th>
              </tr></thead>
              <tbody>{pendIdent.map(p => (
                <tr key={p.id} className="border-b" style={{ borderColor: '#E8EDF5' }}>
                  <td className="px-2 py-2 text-center"><input type="checkbox" checked={selectedPend.has(p.id)} onChange={e => { const n = new Set(selectedPend); if (e.target.checked) n.add(p.id); else n.delete(p.id); setSelectedPend(n); }} /></td>
                  <td className="px-2 py-2">{formatDate(p.data)}</td>
                  <td className="px-2 py-2">{p.conta}</td>
                  <td className="px-2 py-2">{p.banco || '-'}</td>
                  <td className="px-2 py-2 text-right font-medium">{formatCurrency(Number(p.valor))}</td>
                  <td className="px-2 py-2">{p.observacao || '-'}</td>
                </tr>
              ))}</tbody>
            </table>
          </div>
          <div className="mt-4 flex justify-end">
            <button onClick={handleValidarLote} disabled={saving} className="flex items-center gap-2" style={{ ...BTN_PRIMARY, opacity: saving ? 0.7 : 1 }}>
              {saving ? <Loader2 size={14} className="animate-spin" /> : <CheckCircle size={14} />} Validar Selecionados
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function BancoSaldoCard({ banco, onUpdate }: { banco: any; onUpdate: (id: string, saldo: number) => Promise<void> }) {
  const [valor, setValor] = useState(applyCurrencyMask(String(Math.round(Number(banco.saldo || 0) * 100))));
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    await onUpdate(banco.id, parseCurrencyInput(valor));
    setSaving(false);
  };

  return (
    <div className="p-4" style={{ border: '1px solid #E8EDF5', borderRadius: 16 }}>
      <div className="flex items-center justify-between mb-2">
        <div className="font-medium text-sm flex items-center gap-1.5">
          <Landmark size={14} style={{ color: '#94A3B8' }} />{banco.nome}
        </div>
        <span className="text-xs px-2 py-0.5" style={{ background: '#FAFBFE', color: '#94A3B8', borderRadius: 14 }}>
          {banco.ultima_atualizacao || '-'}
        </span>
      </div>
      <input
        value={valor}
        onChange={e => setValor(applyCurrencyMask(e.target.value))}
        className="w-full mb-2"
        style={{ ...INPUT }}
        placeholder="R$ 0,00"
      />
      <button
        onClick={handleSave}
        disabled={saving}
        className="w-full flex items-center justify-center gap-2 text-white text-xs font-semibold"
        style={{
          height: 34,
          borderRadius: 12,
          background: 'var(--color-button-gradient, var(--color-button, var(--color-primary)))',
          opacity: saving ? 0.7 : 1,
          transition: 'opacity 0.2s',
        }}
      >
        {saving ? <Loader2 size={13} className="animate-spin" /> : <CheckCircle size={13} />}
        Atualizar Saldo da Conta
      </button>
    </div>
  );
}
