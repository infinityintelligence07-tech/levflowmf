import { useState, useMemo } from 'react';
import { useEmpresa } from '@/hooks/useEmpresa';
import { useSupabaseData } from '@/hooks/useSupabaseData';
import { supabase } from '@/integrations/supabase/client';
import { aggregateData, calcularDRE } from '@/lib/dre-engine';
import { formatCurrency } from '@/lib/formatters';
import { CATEGORIAS_DRE, CATEGORIAS_RECEITA, CATEGORIAS_DESPESA } from '@/lib/constants';
import { CARD, INPUT, BTN_PRIMARY, BTN_DANGER, SECTION_TITLE, LABEL, tabStyle, TAB_CONTAINER, BANNER } from '@/lib/ui-styles';
import toast from 'react-hot-toast';
import { ArrowDownCircle, ArrowUpCircle, FileText, Trash2, Save, Minus, Plus, Loader2, TrendingUp, TrendingDown, Check, X, Target, BarChart3 } from 'lucide-react';
import { startOfWeek, addDays, format } from 'date-fns';

interface RankingItem {
  conta: string;
  categoria: string;
  categoriaLabel: string;
  valorTotal: number;
  pctDoTotal: number;
}

function calcPiorSemana(orcamentos: any[], lancamentos: any[], pendencias: any[], planoContas: any[], acaoCfoRules: any[], empresa: any, saldoInicial: number) {
  const mapaT: Record<string, string> = {};
  planoContas.forEach((pc: any) => { mapaT[pc.nome_conta] = pc.categoria_dre; });

  const year = new Date().getFullYear();
  const jan1 = new Date(year, 0, 1);
  const dec31 = new Date(year, 11, 31);
  const todayStr = format(new Date(), 'yyyy-MM-dd');
  let weekStart = startOfWeek(jan1, { weekStartsOn: 1 });
  if (weekStart > jan1) weekStart = addDays(weekStart, -7);

  const weeks: { start: Date; end: Date }[] = [];
  while (weekStart <= dec31) {
    weeks.push({ start: weekStart, end: addDays(weekStart, 6) });
    weekStart = addDays(weekStart, 7);
  }

  const getOrcMult = (o: any, cat: string) => {
    let mult = 1.0;
    if (empresa && acaoCfoRules.length > 0) {
      const rules = acaoCfoRules.filter((r: any) =>
        r.categoria === cat &&
        (r.conta_nome === 'todas' || r.conta_nome === o.conta) &&
        r.data_inicio <= o.data_ref
      );
      if (rules.length > 0) mult = 1 + (Number(rules[rules.length - 1].pct) / 100);
    }
    return mult;
  };

  let acumProj = saldoInicial;
  let minProj = saldoInicial;
  let minProjLabel = '';

  let acumReal = saldoInicial;
  let minReal = saldoInicial;
  let minRealLabel = '';

  weeks.forEach(w => {
    const sStr = format(w.start, 'yyyy-MM-dd');
    const eStr = format(w.end, 'yyyy-MM-dd');

    let weekNetProj = 0;
    orcamentos.forEach((o: any) => {
      if (o.data_ref < sStr || o.data_ref > eStr) return;
      const cat = mapaT[o.conta];
      if (!cat) return;
      const val = Number(o.p1 || 0) * getOrcMult(o, cat);
      if (CATEGORIAS_RECEITA.includes(cat)) weekNetProj += val;
      else weekNetProj -= val;
    });
    acumProj += weekNetProj;
    if (acumProj < minProj) {
      minProj = acumProj;
      minProjLabel = `${format(w.start, 'dd/MM')} a ${format(w.end, 'dd/MM')}`;
    }

    let weekNetReal = 0;
    if (eStr <= todayStr) {
      lancamentos.forEach((l: any) => {
        if (!l.ativo || l.data_real < sStr || l.data_real > eStr) return;
        const cat = mapaT[l.conta];
        if (!cat) return;
        if (CATEGORIAS_RECEITA.includes(cat)) weekNetReal += Number(l.valor);
        else weekNetReal -= Number(l.valor);
      });
      pendencias.forEach((p: any) => {
        if (p.data < sStr || p.data > eStr) return;
        if (p.tipo === 'entrada') weekNetReal += Number(p.valor);
        else weekNetReal -= Number(p.valor);
      });
    } else if (sStr <= todayStr && eStr > todayStr) {
      lancamentos.forEach((l: any) => {
        if (!l.ativo || l.data_real < sStr || l.data_real > todayStr) return;
        const cat = mapaT[l.conta];
        if (!cat) return;
        if (CATEGORIAS_RECEITA.includes(cat)) weekNetReal += Number(l.valor);
        else weekNetReal -= Number(l.valor);
      });
      pendencias.forEach((p: any) => {
        if (p.data < sStr || p.data > todayStr) return;
        if (p.tipo === 'entrada') weekNetReal += Number(p.valor);
        else weekNetReal -= Number(p.valor);
      });
      orcamentos.forEach((o: any) => {
        if (o.data_ref <= todayStr || o.data_ref > eStr) return;
        const cat = mapaT[o.conta];
        if (!cat) return;
        const val = Number(o.p1 || 0) * getOrcMult(o, cat);
        if (CATEGORIAS_RECEITA.includes(cat)) weekNetReal += val;
        else weekNetReal -= val;
      });
    } else {
      weekNetReal = weekNetProj;
    }
    acumReal += weekNetReal;
    if (acumReal < minReal) {
      minReal = acumReal;
      minRealLabel = `${format(w.start, 'dd/MM')} a ${format(w.end, 'dd/MM')}`;
    }
  });

  const usarRealizado = minReal < minProj;
  return {
    minSaldo: usarRealizado ? minReal : minProj,
    minLabel: usarRealizado ? minRealLabel : minProjLabel,
    tipo: usarRealizado ? 'Realizado' : 'Projetado',
  };
}

export default function AcaoCFOPage() {
  const { empresaAtual } = useEmpresa();
  const { planoContas, orcamentos, lancamentos, pendencias, acaoCfo, refetch } = useSupabaseData();
  const [tab, setTab] = useState('entradas');
  const [cat, setCat] = useState('');
  const [subconta, setSubconta] = useState('todas');
  const [pct, setPct] = useState('');
  const [saving, setSaving] = useState(false);

  const today = new Date().toISOString().slice(0, 10);
  const yearEnd = `${new Date().getFullYear()}-12-31`;

  const si = empresaAtual?.saldo_inicial || 0;

  const aggOriginal = useMemo(() => empresaAtual ? aggregateData(orcamentos, lancamentos, pendencias, planoContas, [], empresaAtual, today, yearEnd) : { byConta: {}, byCategoria: {} } as any, [orcamentos, lancamentos, pendencias, planoContas, empresaAtual, today, yearEnd]);
  const dreOriginal = useMemo(() => calcularDRE(aggOriginal), [aggOriginal]);

  const aggSimulado = useMemo(() => empresaAtual ? aggregateData(orcamentos, lancamentos, pendencias, planoContas, acaoCfo, empresaAtual, today, yearEnd) : { byConta: {}, byCategoria: {} } as any, [orcamentos, lancamentos, pendencias, planoContas, acaoCfo, empresaAtual, today, yearEnd]);
  const dreSimulado = useMemo(() => calcularDRE(aggSimulado), [aggSimulado]);

  const piorOriginal = useMemo(() => empresaAtual ? calcPiorSemana(orcamentos, lancamentos, pendencias, planoContas, [], empresaAtual, si) : { minSaldo: 0, minLabel: '', tipo: 'Projetado' }, [orcamentos, lancamentos, pendencias, planoContas, empresaAtual, si]);
  const piorSimulado = useMemo(() => empresaAtual ? calcPiorSemana(orcamentos, lancamentos, pendencias, planoContas, acaoCfo, empresaAtual, si) : { minSaldo: 0, minLabel: '', tipo: 'Projetado' }, [orcamentos, lancamentos, pendencias, planoContas, acaoCfo, empresaAtual, si]);

  // Data-driven ranking: which subcategories have the most financial weight
  const rankingEntradas = useMemo<RankingItem[]>(() => {
    if (!empresaAtual) return [];
    const byConta = aggOriginal.byConta || {};
    const catLabels: Record<string, string> = {};
    CATEGORIAS_DRE.forEach(c => { catLabels[c.value] = c.label; });

    const items: RankingItem[] = [];
    planoContas
      .filter(p => p.empresa_id === empresaAtual.id && CATEGORIAS_RECEITA.includes(p.categoria_dre))
      .forEach(p => {
        const vals = byConta[p.nome_conta];
        const total = vals ? Math.abs(Number(vals.p1 || 0)) + Math.abs(Number(vals.real || 0)) : 0;
        if (total > 0) items.push({ conta: p.nome_conta, categoria: p.categoria_dre, categoriaLabel: catLabels[p.categoria_dre] || p.categoria_dre, valorTotal: total, pctDoTotal: 0 });
      });
    const grandTotal = items.reduce((s, i) => s + i.valorTotal, 0);
    items.forEach(i => { i.pctDoTotal = grandTotal > 0 ? (i.valorTotal / grandTotal) * 100 : 0; });
    items.sort((a, b) => b.valorTotal - a.valorTotal);
    return items;
  }, [aggOriginal, planoContas, empresaAtual]);

  const rankingSaidas = useMemo<RankingItem[]>(() => {
    if (!empresaAtual) return [];
    const byConta = aggOriginal.byConta || {};
    const catLabels: Record<string, string> = {};
    CATEGORIAS_DRE.forEach(c => { catLabels[c.value] = c.label; });

    const items: RankingItem[] = [];
    planoContas
      .filter(p => p.empresa_id === empresaAtual.id && CATEGORIAS_DESPESA.includes(p.categoria_dre))
      .forEach(p => {
        const vals = byConta[p.nome_conta];
        const total = vals ? Math.abs(Number(vals.p1 || 0)) + Math.abs(Number(vals.real || 0)) : 0;
        if (total > 0) items.push({ conta: p.nome_conta, categoria: p.categoria_dre, categoriaLabel: catLabels[p.categoria_dre] || p.categoria_dre, valorTotal: total, pctDoTotal: 0 });
      });
    const grandTotal = items.reduce((s, i) => s + i.valorTotal, 0);
    items.forEach(i => { i.pctDoTotal = grandTotal > 0 ? (i.valorTotal / grandTotal) * 100 : 0; });
    items.sort((a, b) => b.valorTotal - a.valorTotal);
    return items;
  }, [aggOriginal, planoContas, empresaAtual]);

  if (!empresaAtual) return null;

  const impacto = piorSimulado.minSaldo - piorOriginal.minSaldo;
  const empCfo = acaoCfo.filter(r => r.empresa_id === empresaAtual.id);
  const entradaCats = CATEGORIAS_DRE.filter(c => CATEGORIAS_RECEITA.includes(c.value as any));
  const saidaCats = CATEGORIAS_DRE.filter(c => CATEGORIAS_DESPESA.includes(c.value as any));

  const handleAplicar = async () => {
    if (!cat || !pct) { toast.error('Preencha todos os campos'); return; }
    setSaving(true);
    const { error } = await supabase.from('acao_cfo').insert({
      empresa_id: empresaAtual.id, tipo_macro: tab === 'entradas' ? 'entradas' : 'saidas',
      categoria: cat, conta_nome: subconta || 'todas', pct: parseFloat(pct), data_inicio: today,
    });
    setSaving(false);
    if (error) { toast.error(error.message); return; }
    toast.success('Regra aplicada!');
    setPct('');
    refetch();
  };

  const handleDeleteRule = async (id: string) => {
    await supabase.from('acao_cfo').delete().eq('id', id);
    toast.success('Excluído!');
    refetch();
  };

  const handleZerar = async () => {
    await supabase.from('acao_cfo').delete().eq('empresa_id', empresaAtual.id);
    toast.success('Simulação zerada!');
    refetch();
  };

  const handleEditPct = async (id: string, newPct: number) => {
    await supabase.from('acao_cfo').update({ pct: newPct }).eq('id', id);
    refetch();
  };

  const handleAplicarRanking = (item: RankingItem) => {
    setCat(item.categoria);
    setSubconta(item.conta);
    setPct('');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    toast.success(`Subcategoria "${item.conta}" selecionada — defina o % de ajuste`);
  };

  const subcontasForCat = planoContas.filter(p => p.categoria_dre === cat && p.empresa_id === empresaAtual.id);
  const currentRanking = tab === 'entradas' ? rankingEntradas : rankingSaidas;

  return (
    <div className="space-y-6">
      <div style={BANNER}>
        <h3 className="font-semibold text-base mb-1">Ação CFO</h3>
        <p className="text-xs opacity-80">Teste o impacto de aumentar receitas ou cortar custos antes de tomar decisões reais.</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div style={CARD}>
          <div className="text-xs font-medium" style={{ color: '#94A3B8' }}>Pior Semana do Ano (Original)</div>
          <div className="font-bold text-xl mt-1" style={{ color: piorOriginal.minSaldo >= 0 ? '#334155' : '#C53030' }}>{formatCurrency(piorOriginal.minSaldo)}</div>
          {piorOriginal.minLabel && <div className="text-[11px] mt-1" style={{ color: '#CBD5E1' }}>Semana {piorOriginal.minLabel} — Base: {piorOriginal.tipo}</div>}
        </div>
        <div style={{ ...CARD, borderColor: piorSimulado.minSaldo >= 0 ? '#046C4E' : '#C53030' }}>
          <div className="text-xs font-medium" style={{ color: '#94A3B8' }}>Pior Semana do Ano (Com Simulação)</div>
          <div className="font-bold text-xl mt-1" style={{ color: piorSimulado.minSaldo >= 0 ? '#046C4E' : '#C53030' }}>{formatCurrency(piorSimulado.minSaldo)}</div>
          {piorSimulado.minLabel && <div className="text-[11px] mt-1" style={{ color: '#CBD5E1' }}>Semana {piorSimulado.minLabel} — Base: {piorSimulado.tipo}</div>}
        </div>
        <div style={{ ...CARD, borderColor: impacto >= 0 ? '#046C4E' : '#C53030' }}>
          <div className="text-xs font-medium" style={{ color: '#94A3B8' }}>Impacto da Simulação</div>
          <div className="font-bold text-xl mt-1" style={{ color: impacto >= 0 ? '#046C4E' : '#C53030' }}>{impacto >= 0 ? '+' : ''}{formatCurrency(impacto)}</div>
          {piorSimulado.minSaldo < 0 && <div className="text-[11px] mt-1 font-semibold" style={{ color: '#C53030' }}>Necessidade de capital de giro</div>}
        </div>
      </div>

      <div className="flex flex-wrap gap-2" style={TAB_CONTAINER}>
        <button onClick={() => setTab('entradas')} style={tabStyle(tab === 'entradas')} className="flex items-center gap-1.5"><ArrowDownCircle size={14} /> Simular Receitas</button>
        <button onClick={() => setTab('saidas')} style={tabStyle(tab === 'saidas')} className="flex items-center gap-1.5"><ArrowUpCircle size={14} /> Simular Despesas</button>
        <button onClick={() => setTab('regras')} style={tabStyle(tab === 'regras')} className="flex items-center gap-1.5"><FileText size={14} /> Regras Ativas ({empCfo.length})</button>
      </div>

      <div style={CARD}>
        {(tab === 'entradas' || tab === 'saidas') && (
          <>
            <h4 className="text-xs font-medium mb-4" style={{ color: '#64748B' }}>
              {tab === 'entradas' ? 'Aumente uma categoria de receita para ver o impacto no resultado' : 'Reduza uma categoria de despesa para ver a economia'}
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
              <div>
                <label className={LABEL} style={{ color: '#94A3B8' }}>Categoria</label>
                <select value={cat} onChange={e => { setCat(e.target.value); setSubconta('todas'); }} style={INPUT}>
                  <option value="">Selecione...</option>
                  {(tab === 'entradas' ? entradaCats : saidaCats).map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
                </select>
              </div>
              <div>
                <label className={LABEL} style={{ color: '#94A3B8' }}>Subcategoria</label>
                <select value={subconta} onChange={e => setSubconta(e.target.value)} style={INPUT}>
                  <option value="todas">Todas</option>
                  {subcontasForCat.map(s => <option key={s.id} value={s.nome_conta}>{s.nome_conta}</option>)}
                </select>
              </div>
              <div>
                <label className={LABEL} style={{ color: '#94A3B8' }}>Ajuste (%)</label>
                <div className="flex items-center gap-1">
                  <button onClick={() => setPct(String((parseFloat(pct) || 0) - 1))} className="w-9 h-9 flex items-center justify-center rounded-xl" style={{ border: '1px solid #E8EDF5' }}><Minus size={12} /></button>
                  <input value={pct} onChange={e => setPct(e.target.value)} placeholder="0" style={{ ...INPUT, textAlign: 'center' as const }} />
                  <button onClick={() => setPct(String((parseFloat(pct) || 0) + 1))} className="w-9 h-9 flex items-center justify-center rounded-xl" style={{ border: '1px solid #E8EDF5' }}><Plus size={12} /></button>
                </div>
              </div>
              <button onClick={handleAplicar} disabled={saving} className="flex items-center gap-2 justify-center" style={{ ...BTN_PRIMARY, opacity: saving ? 0.7 : 1 }}>
                {saving ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />} Aplicar
              </button>
            </div>

            {/* Data-driven Ranking Section */}
            <div className="mt-8 pt-6" style={{ borderTop: '1px solid #E8EDF5' }}>
              <div className="flex items-center gap-2 mb-2">
                <BarChart3 size={16} style={{ color: 'var(--color-primary, #6FA9FF)' }} />
                <h4 className="text-sm font-semibold" style={{ color: '#334155' }}>
                  {tab === 'entradas' ? 'Subcategorias com Maior Impacto nas Receitas' : 'Subcategorias com Maior Impacto nas Despesas'}
                </h4>
              </div>
              <p className="text-xs mb-4" style={{ color: '#94A3B8' }}>
                {tab === 'entradas'
                  ? 'Estas são as subcategorias de receita com maior volume — ajustá-las gera o maior impacto no seu caixa.'
                  : 'Estas são as subcategorias de despesa com maior volume — reduzi-las gera a maior economia no seu caixa.'}
              </p>

              {currentRanking.length === 0 ? (
                <div className="text-center py-6">
                  <div className="text-sm" style={{ color: '#CBD5E1' }}>Nenhuma subcategoria com lançamentos encontrada</div>
                </div>
              ) : (
                <div className="space-y-2">
                  {currentRanking.map((item, idx) => {
                    const maxVal = currentRanking[0]?.valorTotal || 1;
                    const barWidth = (item.valorTotal / maxVal) * 100;
                    const isTop3 = idx < 3;

                    return (
                      <div
                        key={item.conta}
                        className="relative p-3 transition-all cursor-pointer hover:shadow-sm"
                        style={{
                          border: `1px solid ${isTop3 ? (tab === 'entradas' ? '#BBF7D0' : '#FECACA') : '#E8EDF5'}`,
                          borderRadius: 14,
                          background: isTop3 ? (tab === 'entradas' ? '#F0FDF4' : '#FEF2F2') : '#fff',
                        }}
                        onClick={() => handleAplicarRanking(item)}
                        title="Clique para selecionar esta subcategoria na simulação"
                      >
                        {/* Background bar */}
                        <div
                          className="absolute top-0 left-0 h-full rounded-l-[14px] pointer-events-none"
                          style={{
                            width: `${barWidth}%`,
                            background: tab === 'entradas'
                              ? 'rgba(16, 185, 129, 0.06)'
                              : 'rgba(239, 68, 68, 0.06)',
                            borderRadius: 14,
                          }}
                        />

                        <div className="relative flex items-center justify-between gap-3">
                          <div className="flex items-center gap-3 flex-1 min-w-0">
                            <span
                              className="w-6 h-6 flex items-center justify-center rounded-full text-[11px] font-bold shrink-0"
                              style={{
                                background: isTop3
                                  ? (tab === 'entradas' ? '#10B981' : '#EF4444')
                                  : '#CBD5E1',
                                color: '#fff',
                              }}
                            >
                              {idx + 1}
                            </span>
                            <div className="min-w-0">
                              <div className="text-sm font-medium truncate" style={{ color: '#334155' }}>{item.conta}</div>
                              <div className="text-[11px]" style={{ color: '#94A3B8' }}>{item.categoriaLabel}</div>
                            </div>
                          </div>

                          <div className="text-right shrink-0">
                            <div className="text-sm font-semibold" style={{ color: '#334155' }}>{formatCurrency(item.valorTotal)}</div>
                            <div className="text-[11px] font-medium" style={{ color: isTop3 ? (tab === 'entradas' ? '#10B981' : '#EF4444') : '#94A3B8' }}>
                              {item.pctDoTotal.toFixed(1)}% do total
                            </div>
                          </div>

                          <div className="shrink-0" style={{ color: '#CBD5E1' }}>
                            {tab === 'entradas' ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </>
        )}

        {tab === 'regras' && (
          <>
            {empCfo.length === 0 ? (
              <div className="text-center py-8">
                <div className="text-sm" style={{ color: '#CBD5E1' }}>Nenhuma regra ativa</div>
                <p className="text-xs mt-1" style={{ color: '#CBD5E1' }}>Use as abas acima para simular ajustes nas receitas ou despesas.</p>
              </div>
            ) : (
              <>
                <button onClick={handleZerar} className="mb-4 text-xs flex items-center gap-1" style={BTN_DANGER}><Trash2 size={12} /> Limpar Todas as Regras</button>
                <div className="space-y-2">
                  {empCfo.map(r => (
                    <div key={r.id} className="flex flex-wrap items-center gap-3 p-3" style={{ border: '1px solid #E8EDF5', borderRadius: 14 }}>
                      {r.tipo_macro === 'entradas' ? <ArrowDownCircle size={14} style={{ color: '#046C4E' }} /> : <ArrowUpCircle size={14} style={{ color: '#C53030' }} />}
                      <span className="text-xs font-medium flex-1">{r.categoria} / {r.conta_nome} — A partir de {r.data_inicio}</span>
                      <input style={{ ...INPUT, width: 64, height: 32, fontSize: 12, textAlign: 'right' as const, borderRadius: 10 }}
                        defaultValue={Number(r.pct)} onBlur={e => handleEditPct(r.id, parseFloat(e.target.value))} />
                      <span className="text-xs" style={{ color: '#94A3B8' }}>%</span>
                      <button onClick={() => handleDeleteRule(r.id)} style={{ color: '#C53030' }}><Trash2 size={14} /></button>
                    </div>
                  ))}
                </div>
              </>
            )}
          </>
        )}
      </div>
    </div>
  );
}