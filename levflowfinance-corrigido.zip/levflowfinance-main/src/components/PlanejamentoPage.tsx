import { useState, useMemo } from 'react';
import CurrencyInput from '@/components/CurrencyInput';
import { useEmpresa } from '@/hooks/useEmpresa';
import { useSupabaseData } from '@/hooks/useSupabaseData';
import { supabase } from '@/integrations/supabase/client';
import { formatCurrency, parseCurrencyInput, applyCurrencyMask, formatDate } from '@/lib/formatters';
import { CATEGORIAS_DRE, CATEGORIAS_RECEITA } from '@/lib/constants';
import { CARD, INPUT, BTN_PRIMARY, SECTION_TITLE, LABEL } from '@/lib/ui-styles';
import toast from 'react-hot-toast';
import { Save, Trash2, CheckCircle, RefreshCw, AlertTriangle, Calendar } from 'lucide-react';

export default function PlanejamentoPage() {
  const { empresaAtual } = useEmpresa();
  const { planoContas, orcamentos, refetch, loading } = useSupabaseData();
  const [categoria, setCategoria] = useState('');
  const [subconta, setSubconta] = useState('');
  const [valor, setValor] = useState('');
  const [faturado, setFaturado] = useState('');
  const [dataLanc, setDataLanc] = useState(new Date().toISOString().slice(0, 10));
  const [dataRef, setDataRef] = useState('');
  const [descricao, setDescricao] = useState('');
  const [recorrencia, setRecorrencia] = useState(false);
  const [freq, setFreq] = useState('Mensal');
  const [termino, setTermino] = useState<'parcelas' | 'data'>('parcelas');
  const [parcelas, setParcelas] = useState(2);
  const [dataLimite, setDataLimite] = useState('');
  const [ajusteFds, setAjusteFds] = useState('manter');
  const [selected, setSelected] = useState<Set<string>>(new Set());

  // Filters
  const [filtCat, setFiltCat] = useState('');
  const [filtSearch, setFiltSearch] = useState('');

  if (!empresaAtual) return null;

  const isReceita = CATEGORIAS_RECEITA.includes(categoria as any);
  const subcontas = planoContas.filter(pc => pc.categoria_dre === categoria && pc.empresa_id === empresaAtual.id);

  const checkWeekend = (dateStr: string) => {
    const d = new Date(dateStr + 'T00:00:00');
    return d.getDay() === 0 || d.getDay() === 6;
  };

  const adjustDate = (dateStr: string): string => {
    if (!checkWeekend(dateStr) || ajusteFds === 'manter') return dateStr;
    const d = new Date(dateStr + 'T00:00:00');
    if (ajusteFds === 'antecipar') {
      while (d.getDay() === 0 || d.getDay() === 6) d.setDate(d.getDate() - 1);
    } else {
      while (d.getDay() === 0 || d.getDay() === 6) d.setDate(d.getDate() + 1);
    }
    return d.toISOString().slice(0, 10);
  };

  const handleSave = async () => {
    if (!subconta || !dataRef) { toast.error('Preencha todos os campos'); return; }
    const v = parseCurrencyInput(valor);
    const f = isReceita ? parseCurrencyInput(faturado) : 0;
    const c2 = empresaAtual.cenario_c2;
    const c3 = empresaAtual.cenario_c3;

    const dates: { ref: string; desc: string }[] = [];
    if (!recorrencia) {
      dates.push({ ref: adjustDate(dataRef), desc: descricao });
    } else {
      let count = 0;
      const maxCount = termino === 'parcelas' ? parcelas : 999;
      const maxDate = termino === 'data' ? dataLimite : '2099-12-31';
      const current = new Date(dataRef + 'T00:00:00');

      while (count < maxCount && current.toISOString().slice(0, 10) <= maxDate) {
        count++;
        const adjusted = adjustDate(current.toISOString().slice(0, 10));
        dates.push({ ref: adjusted, desc: `${descricao} (Parc ${count}/${termino === 'parcelas' ? parcelas : '?'})` });
        if (freq === 'Mensal') current.setMonth(current.getMonth() + 1);
        else current.setDate(current.getDate() + 7);
      }
    }

    const records = dates.map(d => ({
      empresa_id: empresaAtual.id,
      conta: subconta,
      data_lancamento: dataLanc,
      data_ref: d.ref,
      p1: v,
      p2: isReceita ? v * (1 + c2 / 100) : v,
      p3: isReceita ? v * (1 + c3 / 100) : v,
      faturado: f,
      descricao: d.desc,
    }));

    const { error } = await supabase.from('orcamentos').insert(records);
    if (error) { toast.error(error.message); return; }
    toast.success(`${records.length} lançamento(s) salvo(s)!`);
    setValor(''); setFaturado(''); setDescricao(''); setRecorrencia(false);
    refetch();
  };

  let filteredOrcs = orcamentos.filter(o => o.empresa_id === empresaAtual.id).sort((a, b) => b.data_ref.localeCompare(a.data_ref));
  if (filtCat) filteredOrcs = filteredOrcs.filter(o => {
    const cat = planoContas.find(p => p.nome_conta === o.conta)?.categoria_dre;
    return cat === filtCat;
  });
  if (filtSearch) filteredOrcs = filteredOrcs.filter(o => (o.descricao || '').toLowerCase().includes(filtSearch.toLowerCase()) || o.conta.toLowerCase().includes(filtSearch.toLowerCase()));

  const handleInlineEdit = async (id: string, field: string, value: any) => {
    const { error } = await supabase.from('orcamentos').update({ [field]: value }).eq('id', id);
    if (error) toast.error(error.message);
    else refetch();
  };

  const handleDelete = async () => {
    if (selected.size === 0) return;
    const { error } = await supabase.from('orcamentos').delete().in('id', Array.from(selected));
    if (error) toast.error(error.message);
    else { toast.success('Excluído!'); setSelected(new Set()); refetch(); }
  };

  const handleConciliar = async () => {
    if (selected.size === 0) return;
    const { error } = await supabase.from('orcamentos').update({ efetivado: true }).in('id', Array.from(selected));
    if (error) toast.error(error.message);
    else { toast.success('Conciliado!'); setSelected(new Set()); refetch(); }
  };

  const showFds = dataRef && checkWeekend(dataRef);

  return (
    <div className="space-y-6">
      {planoContas.filter(p => p.empresa_id === empresaAtual.id).length === 0 && (
        <div className="p-4 flex items-center gap-2 text-sm" style={{ background: '#FFFBEB', border: '1px solid #FDE68A', borderRadius: 16, color: '#92400E' }}>
          <AlertTriangle size={16} /> Nenhum plano de contas cadastrado. Vá em Cadastro para configurar antes de planejar.
        </div>
      )}

      <div style={CARD}>
        <h3 style={SECTION_TITLE}>Novo Lançamento</h3>
        <p className="text-xs mb-5" style={{ color: '#94A3B8' }}>Registre uma nova projeção de receita ou despesa</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <label className={LABEL} style={{ color: '#94A3B8' }}>Categoria</label>
            <select value={categoria} onChange={e => { setCategoria(e.target.value); setSubconta(''); }} style={INPUT}>
              <option value="">Selecione...</option>
              {CATEGORIAS_DRE.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
            </select>
          </div>
          <div>
            <label className={LABEL} style={{ color: '#94A3B8' }}>Subcategoria</label>
            <select value={subconta} onChange={e => setSubconta(e.target.value)} style={INPUT}>
              <option value="">Selecione...</option>
              {subcontas.map(s => <option key={s.id} value={s.nome_conta}>{s.nome_conta}</option>)}
            </select>
          </div>
          {isReceita ? (
            <>
              <div>
                <label className={LABEL} style={{ color: '#94A3B8' }}>Faturado</label>
                <input value={faturado} onChange={e => setFaturado(applyCurrencyMask(e.target.value))} placeholder="R$ 0,00" style={INPUT} />
                <div className="mt-1 text-[10px]" style={{ color: '#94A3B8' }}>Valor total faturado</div>
              </div>
              <div>
                <label className={LABEL} style={{ color: '#94A3B8' }}>Liquidez</label>
                <input value={valor} onChange={e => setValor(applyCurrencyMask(e.target.value))} placeholder="R$ 0,00" style={INPUT} />
                <div className="mt-1 text-[10px]" style={{ color: '#046C4E' }}>Valor que entra no caixa (DRE)</div>
              </div>
            </>
          ) : (
            <div>
              <label className={LABEL} style={{ color: '#94A3B8' }}>Projeção</label>
              <input value={valor} onChange={e => setValor(applyCurrencyMask(e.target.value))} placeholder="R$ 0,00" style={INPUT} />
            </div>
          )}
          <div>
            <label className={LABEL} style={{ color: '#94A3B8' }}>Data Lançamento</label>
            <input type="date" value={dataLanc} onChange={e => setDataLanc(e.target.value)} style={INPUT} />
          </div>
          <div>
            <label className={LABEL} style={{ color: '#94A3B8' }}>Primeiro Vencimento</label>
            <input type="date" value={dataRef} onChange={e => setDataRef(e.target.value)} style={INPUT} />
          </div>
        </div>

        {showFds && (
          <div className="mt-4 p-3" style={{ background: '#FFFBEB', border: '1px solid #FDE68A', borderRadius: 12, fontSize: 12 }}>
            <div className="flex items-center gap-1.5 mb-2 font-medium" style={{ color: '#92400E' }}><AlertTriangle size={14} /> O vencimento selecionado cai em um fim de semana.</div>
            <div className="flex gap-4">
              {[{ v: 'manter', l: 'Manter Data' }, { v: 'antecipar', l: 'Antecipar (Sexta)' }, { v: 'proximo', l: 'Próximo dia útil (Segunda)' }].map(op => (
                <label key={op.v} className="flex items-center gap-1">
                  <input type="radio" name="fds" value={op.v} checked={ajusteFds === op.v} onChange={() => setAjusteFds(op.v)} />
                  {op.l}
                </label>
              ))}
            </div>
          </div>
        )}

        <div className="mt-4 flex flex-col sm:flex-row items-start sm:items-center gap-3">
          <label className="flex items-center gap-2 text-sm" style={{ color: '#64748B' }}>
            <input type="checkbox" checked={recorrencia} onChange={e => setRecorrencia(e.target.checked)} />
            <RefreshCw size={14} /> Criar Recorrência
          </label>
          {recorrencia && (
            <div className="flex flex-wrap items-center gap-3 text-xs">
              <select value={freq} onChange={e => setFreq(e.target.value)} style={{ ...INPUT, width: 'auto', height: 32, fontSize: 12 }}>
                <option>Mensal</option><option>Semanal</option>
              </select>
              <select value={termino} onChange={e => setTermino(e.target.value as any)} style={{ ...INPUT, width: 'auto', height: 32, fontSize: 12 }}>
                <option value="parcelas">Por Qtd Parcelas</option><option value="data">Por Data Limite</option>
              </select>
              {termino === 'parcelas' && <input type="number" min={2} value={parcelas} onChange={e => setParcelas(Number(e.target.value))} style={{ ...INPUT, width: 60, height: 32, fontSize: 12 }} />}
              {termino === 'data' && <input type="date" value={dataLimite} onChange={e => setDataLimite(e.target.value)} style={{ ...INPUT, width: 'auto', height: 32, fontSize: 12 }} />}
            </div>
          )}
        </div>

        <div className="mt-4">
          <label className={LABEL} style={{ color: '#94A3B8' }}>Observação</label>
          <input value={descricao} onChange={e => setDescricao(e.target.value)} placeholder="Observação..." style={INPUT} />
        </div>

        <div className="mt-5 flex justify-end">
          <button onClick={handleSave} className="flex items-center gap-2" style={BTN_PRIMARY}>
            <Save size={14} /> Salvar
          </button>
        </div>
      </div>

      {/* Histórico */}
      <div style={CARD}>
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-4 gap-2">
          <h3 style={SECTION_TITLE}>Histórico de Planejamento</h3>
          {selected.size > 0 && (
            <div className="flex gap-2">
              <button onClick={handleDelete} className="text-white text-xs font-semibold px-3 py-1.5 rounded-lg flex items-center gap-1" style={{ backgroundColor: '#C53030', borderRadius: 10 }}><Trash2 size={12} /> Excluir ({selected.size})</button>
              <button onClick={handleConciliar} className="text-white text-xs font-semibold px-3 py-1.5 rounded-lg flex items-center gap-1" style={{ backgroundColor: '#046C4E', borderRadius: 10 }}><CheckCircle size={12} /> Conciliar ({selected.size})</button>
            </div>
          )}
        </div>
        <div className="flex flex-wrap gap-2 mb-4">
          <select value={filtCat} onChange={e => setFiltCat(e.target.value)} className="text-xs" style={{ ...INPUT, width: 'auto', height: 32, fontSize: 12 }}>
            <option value="">Todas categorias</option>
            {CATEGORIAS_DRE.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
          </select>
          <input value={filtSearch} onChange={e => setFiltSearch(e.target.value)} placeholder="Buscar..." className="text-xs" style={{ ...INPUT, height: 32, fontSize: 12, flex: 1, minWidth: 120 }} />
        </div>
        <div className="overflow-auto" style={{ maxHeight: 500 }}>
          <table className="w-full text-xs" style={{ minWidth: 900 }}>
            <thead>
              <tr style={{ background: '#FAFBFE' }}>
                <th className="px-2 py-2.5 text-left" style={{ color: '#94A3B8' }}><input type="checkbox" checked={filteredOrcs.length > 0 && filteredOrcs.every(o => selected.has(o.id))} onChange={e => { if (e.target.checked) setSelected(new Set(filteredOrcs.map(o => o.id))); else setSelected(new Set()); }} /></th>
                <th className="px-2 py-2.5 text-left" style={{ color: '#94A3B8' }}>Status</th>
                <th className="px-2 py-2.5 text-left" style={{ color: '#94A3B8' }}>Lançamento</th>
                <th className="px-2 py-2.5 text-left" style={{ color: '#94A3B8' }}>Vencimento</th>
                <th className="px-2 py-2.5 text-left" style={{ color: '#94A3B8' }}>Categoria</th>
                <th className="px-2 py-2.5 text-left" style={{ color: '#94A3B8' }}>Conta</th>
                <th className="px-2 py-2.5 text-right" style={{ color: '#94A3B8' }}>Previsto</th>
                <th className="px-2 py-2.5 text-left" style={{ color: '#94A3B8' }}>Observação</th>
              </tr>
            </thead>
            <tbody>
              {filteredOrcs.map(orc => {
                const cat = planoContas.find(p => p.nome_conta === orc.conta)?.categoria_dre;
                const isRec = CATEGORIAS_RECEITA.includes(cat);
                let statusLabel = 'Pendente';
                let statusColor = '#DD6B20';
                if (orc.efetivado) { statusLabel = 'Efetivado'; statusColor = '#046C4E'; }
                else if (isRec) { statusLabel = 'Projetado'; statusColor = 'var(--color-primary, #6FA9FF)'; }
                return (
                  <tr key={orc.id} className="border-b" style={{ borderColor: '#E8EDF5' }}>
                    <td className="px-2 py-2"><input type="checkbox" checked={selected.has(orc.id)} onChange={e => {
                      const n = new Set(selected);
                      if (e.target.checked) n.add(orc.id); else n.delete(orc.id);
                      setSelected(n);
                    }} /></td>
                    <td className="px-2 py-2"><span className="text-xs px-2 py-0.5" style={{ background: statusColor + '12', color: statusColor, borderRadius: 14 }}>{statusLabel}</span></td>
                    <td className="px-2 py-2">{formatDate(orc.data_lancamento)}</td>
                    <td className="px-2 py-2">
                      <input type="date" value={orc.data_ref} onChange={e => handleInlineEdit(orc.id, 'data_ref', e.target.value)}
                        style={{ ...INPUT, width: 'auto', height: 28, fontSize: 11 }} />
                    </td>
                    <td className="px-2 py-2">{CATEGORIAS_DRE.find(c => c.value === cat)?.label || cat}</td>
                    <td className="px-2 py-2">{orc.conta}</td>
                    <td className="px-2 py-2 text-right">
                      <CurrencyInput style={{ ...INPUT, width: 100, height: 28, fontSize: 11, textAlign: 'right' as const }}
                        defaultValue={Number(orc.p1)}
                        onCommit={v => handleInlineEdit(orc.id, 'p1', v)} />
                    </td>
                    <td className="px-2 py-2">
                      <input style={{ ...INPUT, width: 130, height: 28, fontSize: 11 }}
                        defaultValue={orc.descricao || ''}
                        onBlur={e => handleInlineEdit(orc.id, 'descricao', e.target.value)} />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
