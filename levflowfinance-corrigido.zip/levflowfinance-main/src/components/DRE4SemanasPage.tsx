import { useState, useMemo, useRef } from 'react';
import { useSupabaseData } from '@/hooks/useSupabaseData';
import { useEmpresa } from '@/hooks/useEmpresa';
import { aggregateData, calcularDRE, calcularSaldoHistoricoAte, applyScenarios, type DREWithDetails } from '@/lib/dre-engine';
import { formatCurrency } from '@/lib/formatters';
import { DRE_LINES } from '@/lib/constants';
import { DRE_TABLE, INPUT } from '@/lib/ui-styles';

import { startOfWeek, addDays, format, getDay } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Calendar, ChevronLeft, ChevronRight } from 'lucide-react';


export default function DRE4SemanasPage() {
  const { empresaAtual, isAllMode, empresas } = useEmpresa();
  const { planoContas, orcamentos, lancamentos, pendencias, acaoCfo, loading } = useSupabaseData();
  const [baseDate, setBaseDate] = useState(new Date().toISOString().slice(0, 10));
  const [expandedRows, setExpandedRows] = useState<Set<string>>(new Set());
  const scrollRef = useRef<HTMLDivElement>(null);

  // Auto-advance weekend to next Monday
  const adjustedBaseDate = useMemo(() => {
    const base = new Date(baseDate + 'T00:00:00');
    const day = getDay(base); // 0=Sun, 6=Sat
    if (day === 0) return format(addDays(base, 1), 'yyyy-MM-dd');
    if (day === 6) return format(addDays(base, 2), 'yyyy-MM-dd');
    return baseDate;
  }, [baseDate]);

  const weeks = useMemo(() => {
    const base = new Date(adjustedBaseDate + 'T00:00:00');
    // Find the Monday on or after the adjusted base date
    let firstMonday = startOfWeek(base, { weekStartsOn: 1 });
    if (firstMonday < base) firstMonday = addDays(firstMonday, 7);
    // 4 weeks, Mon–Fri each
    const result: { label: string; sublabel: string; start: string; end: string }[] = [];
    for (let i = 0; i < 4; i++) {
      const start = addDays(firstMonday, i * 7);
      const end = addDays(start, 4); // Friday
      const startFmt = format(start, 'dd/MM', { locale: ptBR });
      const endFmt = format(end, 'dd/MM', { locale: ptBR });
      result.push({
        label: `Semana ${i + 1}`,
        sublabel: `${startFmt} a ${endFmt}`,
        start: format(start, 'yyyy-MM-dd'),
        end: format(end, 'yyyy-MM-dd'),
      });
    }
    return result;
  }, [adjustedBaseDate]);

  const saldoInicial = isAllMode
    ? empresas.filter(e => e.ativo).reduce((s, e) => s + e.saldo_inicial, 0)
    : empresaAtual?.saldo_inicial || 0;

  const weekDREs = useMemo(() => {
    return weeks.map(w => {
      const agg = aggregateData(orcamentos, lancamentos, pendencias, planoContas, acaoCfo, empresaAtual, w.start, w.end);
      return calcularDRE(agg);
    });
  }, [weeks, orcamentos, lancamentos, pendencias, planoContas, acaoCfo, empresaAtual]);

  const pctC2 = empresaAtual?.cenario_c2 ?? 30;
  const pctC3 = empresaAtual?.cenario_c3 ?? 70;

  const totalDRE = useMemo(() => {
    const allStart = weeks[0]?.start || '';
    const allEnd = weeks[weeks.length - 1]?.end || '';
    const agg = aggregateData(orcamentos, lancamentos, pendencias, planoContas, acaoCfo, empresaAtual, allStart, allEnd);
    const baseDRE = calcularDRE(agg);
    return applyScenarios(baseDRE, pctC2, pctC3);
  }, [weeks, orcamentos, lancamentos, pendencias, planoContas, acaoCfo, empresaAtual, pctC2, pctC3]);

  const toggleRow = (key: string) => {
    setExpandedRows(prev => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  };

  const saldoAcumuladoInicial = calcularSaldoHistoricoAte(lancamentos, pendencias, planoContas, saldoInicial, weeks[0]?.start || '');

  const saldosAcumulados = useMemo(() => {
    const result: { prev: number; real: number }[] = [];
    let acumPrev = saldoAcumuladoInicial;
    let acumReal = saldoAcumuladoInicial;
    weekDREs.forEach(wd => {
      acumPrev += wd.resultado_liquido.p1;
      acumReal += wd.resultado_liquido.real;
      result.push({ prev: acumPrev, real: acumReal });
    });
    return result;
  }, [weekDREs, saldoAcumuladoInicial]);

  const cellColor = (val: number) => val === 0 ? DRE_TABLE.neutralColor : '#64748B';

  const scroll = (dir: 'left' | 'right') => {
    if (!scrollRef.current) return;
    scrollRef.current.scrollLeft += dir === 'left' ? -320 : 320;
  };

  if (loading) return <div className="flex items-center justify-center h-64" style={{ color: DRE_TABLE.neutralColor }}>Carregando...</div>;


  return (
    <div>
      <div className="flex items-center gap-3 mb-5">
        <Calendar size={15} style={{ color: DRE_TABLE.neutralColor }} />
        <label className="text-sm font-medium" style={{ color: '#64748B' }}>Data base:</label>
        <input type="date" value={baseDate} onChange={e => setBaseDate(e.target.value)} style={{ ...INPUT, width: 'auto' }} />
      </div>

      <div className="flex items-center gap-2 mb-2 justify-end">
        <button onClick={() => scroll('left')} className="flex items-center justify-center rounded-lg border transition-colors hover:bg-muted" style={{ width: 32, height: 32, border: '1px solid var(--color-card-border, #E8EDF5)' }}>
          <ChevronLeft size={16} style={{ color: '#64748B' }} />
        </button>
        <span className="text-xs" style={{ color: DRE_TABLE.neutralColor }}>Deslizar tabela</span>
        <button onClick={() => scroll('right')} className="flex items-center justify-center rounded-lg border transition-colors hover:bg-muted" style={{ width: 32, height: 32, border: '1px solid var(--color-card-border, #E8EDF5)' }}>
          <ChevronRight size={16} style={{ color: '#64748B' }} />
        </button>
      </div>

      <div ref={scrollRef} className="dre-scroll" style={{ ...DRE_TABLE.wrapper, scrollBehavior: 'smooth' }}>
        <table className="w-full text-xs" style={{ ...DRE_TABLE.cellFont, minWidth: 1200, borderCollapse: 'collapse' }}>
          <colgroup>
            <col style={{ minWidth: 210, width: 210 }} />
            {weeks.map((_, i) => (
              <Fragment key={i}>
                <col style={{ minWidth: 100, width: 100 }} />
                <col style={{ minWidth: 100, width: 100 }} />
                <col style={{ minWidth: 100, width: 100 }} />
              </Fragment>
            ))}
            <col style={{ minWidth: 100 }} />
            <col style={{ minWidth: 100 }} />
            <col style={{ minWidth: 100 }} />
            <col style={{ minWidth: 100 }} />
          </colgroup>
          <thead>
            <tr style={{ background: 'var(--color-primary-gradient, var(--color-primary, #1A2B6D))' }}>
              <th className="sticky left-0 z-10 text-left px-3 py-2.5 border-b font-semibold text-xs tracking-wide uppercase" style={{ minWidth: 210, background: 'var(--color-primary, #1A2B6D)', color: '#fff' }}>Categoria</th>
              {weeks.map((w, i) => (
                <th key={i} colSpan={3} className="text-center px-1 py-2.5 border-b border-l font-semibold text-xs tracking-wide" style={{ color: 'rgba(255,255,255,0.8)', borderLeftColor: 'rgba(255,255,255,0.12)' }}>
                  Semana {i + 1}<br /><span style={{ color: 'rgba(255,255,255,0.55)', fontWeight: 400, fontSize: 10 }}>{w.sublabel}</span>
                </th>
              ))}
              <th colSpan={4} className="text-center px-1 py-2.5 border-b border-l font-semibold text-xs tracking-wide uppercase" style={{ color: '#fff', borderLeftColor: 'rgba(255,255,255,0.12)' }}>Acumulado</th>
            </tr>
            <tr style={{ background: DRE_TABLE.subHeaderBg }}>
              <th className="sticky left-0 z-10 border-b" style={{ background: DRE_TABLE.subHeaderBg }} />
              {weeks.map((_, i) => (
                <Fragment key={i}>
                  <th className="text-center px-1 py-1.5 border-b border-l text-[10px]" style={{ color: DRE_TABLE.neutralColor }}>Previsto</th>
                  <th className="text-center px-1 py-1.5 border-b text-[10px]" style={{ color: DRE_TABLE.neutralColor, borderLeft: '1px dashed #E2E8F0' }}>Realizado</th>
                  <th className="text-center px-1 py-1.5 border-b text-[10px]" style={{ color: DRE_TABLE.neutralColor, borderLeft: '1px dashed #E2E8F0' }}>Variação</th>
                </Fragment>
              ))}
              <th className="px-1 py-1.5 border-b border-l text-center text-[10px] font-medium" style={{ background: DRE_TABLE.acumuladoBg, color: '#64748B' }}>Conservador</th>
              <th className="px-1 py-1.5 border-b text-center text-[10px] font-medium" style={{ background: DRE_TABLE.acumuladoBg, color: '#64748B', borderLeft: '1px dashed #DAE2F0' }}>Moderado</th>
              <th className="px-1 py-1.5 border-b text-center text-[10px] font-medium" style={{ background: DRE_TABLE.acumuladoBg, color: '#64748B', borderLeft: '1px dashed #DAE2F0' }}>Otimista</th>
              <th className="px-1 py-1.5 border-b text-center text-[10px] font-medium" style={{ background: DRE_TABLE.acumuladoBg, color: '#64748B', borderLeft: '1px dashed #DAE2F0' }}>Real</th>
            </tr>
          </thead>
          <tbody>
            {/* Saldo Inicial */}
            <tr style={{ background: DRE_TABLE.saldoInicialBg, borderBottom: '2px solid var(--color-card-border, #E8EDF5)' }}>
              <td className="sticky left-0 z-10 px-3 py-2 font-semibold" style={{ background: DRE_TABLE.saldoInicialBg, color: 'var(--color-primary, #6FA9FF)' }}>Saldo Inicial</td>
              {weeks.map((_, i) => {
                const val = i === 0 ? saldoAcumuladoInicial : saldosAcumulados[i - 1].real;
                return (
                  <Fragment key={i}>
                    <td colSpan={3} className="text-center font-semibold border-l" style={{ color: val >= 0 ? 'var(--color-primary, #6FA9FF)' : DRE_TABLE.negativeColor }}>{formatCurrency(val)}</td>
                  </Fragment>
                );
              })}
              <td colSpan={4} className="text-center font-semibold border-l" style={{ color: 'var(--color-primary, #6FA9FF)' }}>{formatCurrency(saldoAcumuladoInicial)}</td>
            </tr>

            {/* DRE Lines */}
            {DRE_LINES.map(line => {
              const isExpanded = expandedRows.has(line.key);
              const hasDetails = !line.isSubtotal && !!line.categoria;
              const subContas = hasDetails
                ? (() => {
                    const cat = line.categoria!;
                    const fromDRE = totalDRE.details[cat] || [];
                    const dreNames = new Set(fromDRE.map(d => d.nome));
                    const fromPlano = planoContas
                      .filter(pc => pc.categoria_dre === cat && !dreNames.has(pc.nome_conta))
                      .map(pc => ({ nome: pc.nome_conta, p1: 0, p2: 0, p3: 0, real: 0, _cat: cat }));
                    return [...fromDRE.map(d => ({ ...d, _cat: cat })), ...fromPlano];
                  })()
                : [];
              const isResultadoLiquido = line.key === 'resultado_liquido';
              const rowBg = isResultadoLiquido ? '#E0ECFF' : line.isSubtotal ? DRE_TABLE.subtotalBg : '#fff';
              const textStyle = isResultadoLiquido
                ? { color: 'var(--color-primary, #1A2B6D)', fontWeight: 700 }
                : line.isSubtotal ? { color: DRE_TABLE.subtotalColor, fontWeight: 600 } : {};

              return (
                <Fragment key={line.key}>
                  <tr style={{ background: rowBg }}>
                    <td className="sticky left-0 z-10 px-3 py-2 cursor-pointer whitespace-nowrap" style={{ background: rowBg, ...textStyle }}
                      onClick={() => hasDetails && toggleRow(line.key)}>
                      {hasDetails && (
                        <span className="mr-1.5" style={{ color: 'var(--color-primary, #6FA9FF)' }}>{isExpanded ? '−' : '+'}</span>
                      )}
                      {line.label}
                    </td>
                    {weekDREs.map((wd, wi) => {
                      const v = wd[line.key as keyof DREWithDetails] as any;
                      if (!v || typeof v !== 'object' || !('p1' in v)) return <Fragment key={wi}><td colSpan={3} className="border-l" /></Fragment>;
                      const diff = v.real - v.p1;
                      const diffFavorable = diff >= 0;
                      return (
                        <Fragment key={wi}>
                          <td className="text-right px-2 py-2 border-l whitespace-nowrap" style={{ color: cellColor(v.p1), ...textStyle }}>{formatCurrency(v.p1)}</td>
                          <td className="text-right px-2 py-2 whitespace-nowrap" style={{ color: cellColor(v.real), ...textStyle, borderLeft: '1px dashed #E2E8F0' }}>{formatCurrency(v.real)}</td>
                          <td className="text-right px-2 py-2 whitespace-nowrap" style={{ color: diff === 0 ? DRE_TABLE.neutralColor : diffFavorable ? DRE_TABLE.positiveColor : DRE_TABLE.negativeColor, fontWeight: 500, borderLeft: '1px dashed #E2E8F0' }}>
                            {formatCurrency(diff)}
                          </td>
                        </Fragment>
                      );
                    })}
                    {/* Acumulado - Cenários */}
                    {(() => {
                      const v = totalDRE[line.key as keyof DREWithDetails] as any;
                      if (!v || typeof v !== 'object' || !('p1' in v)) return <td colSpan={4} className="border-l" />;
                      return (
                        <>
                          <td className="text-right px-2 py-2 border-l font-semibold whitespace-nowrap" style={textStyle}>{formatCurrency(v.p1)}</td>
                          <td className="text-right px-2 py-2 font-semibold whitespace-nowrap" style={{ ...textStyle, borderLeft: '1px dashed #E2E8F0' }}>{formatCurrency(v.p2)}</td>
                          <td className="text-right px-2 py-2 font-semibold whitespace-nowrap" style={{ ...textStyle, borderLeft: '1px dashed #E2E8F0' }}>{formatCurrency(v.p3)}</td>
                          <td className="text-right px-2 py-2 font-semibold whitespace-nowrap" style={{ ...textStyle, borderLeft: '1px dashed #E2E8F0' }}>{formatCurrency(v.real)}</td>
                        </>
                      );
                    })()}
                  </tr>

                  {/* Sub-contas */}
                  {isExpanded && subContas.map(sc => (
                    <tr key={sc.nome} style={{ background: '#F8FAFC' }}>
                      <td className="sticky left-0 z-10 py-1.5" style={{ background: '#F8FAFC', paddingLeft: 35, fontSize: 11, color: '#64748B' }}>{sc.nome}</td>
                      {weekDREs.map((wd, wi) => {
                        const det = wd.details[sc._cat]?.find(d => d.nome === sc.nome);
                        const p = det?.p1 || 0;
                        const r = det?.real || 0;
                        const dv = r - p;
                        return (
                          <Fragment key={wi}>
                            <td className="text-right px-2 py-1.5 border-l whitespace-nowrap" style={{ color: '#64748B' }}>{formatCurrency(p)}</td>
                            <td className="text-right px-2 py-1.5 whitespace-nowrap" style={{ color: '#64748B', borderLeft: '1px dashed #E2E8F0' }}>{formatCurrency(r)}</td>
                            <td className="text-right px-2 py-1.5 whitespace-nowrap" style={{ color: dv === 0 ? DRE_TABLE.neutralColor : dv > 0 ? DRE_TABLE.positiveColor : DRE_TABLE.negativeColor, borderLeft: '1px dashed #E2E8F0' }}>{formatCurrency(dv)}</td>
                          </Fragment>
                        );
                      })}
                      <td className="text-right px-2 py-1.5 border-l whitespace-nowrap" style={{ color: '#64748B' }}>{formatCurrency(sc.p1)}</td>
                      <td className="text-right px-2 py-1.5 whitespace-nowrap" style={{ color: '#64748B', borderLeft: '1px dashed #E2E8F0' }}>{formatCurrency(sc.p2)}</td>
                      <td className="text-right px-2 py-1.5 whitespace-nowrap" style={{ color: '#64748B', borderLeft: '1px dashed #E2E8F0' }}>{formatCurrency(sc.p3)}</td>
                      <td className="text-right px-2 py-1.5 whitespace-nowrap" style={{ color: '#64748B', borderLeft: '1px dashed #E2E8F0' }}>{formatCurrency(sc.real)}</td>
                    </tr>
                  ))}
                </Fragment>
              );
            })}

            {/* Saldo Acumulado */}
            <tr style={{ background: 'var(--color-primary-gradient, var(--color-primary, #1A2B6D))', borderTop: '3px solid var(--color-primary, #1A2B6D)' }}>
              <td className="sticky left-0 z-10 px-3 py-3 font-bold text-sm" style={{ background: 'var(--color-primary, #1A2B6D)', color: '#fff' }}>Saldo Acumulado</td>
              {saldosAcumulados.map((s, i) => {
                const diff = s.real - s.prev;
                return (
                  <Fragment key={i}>
                    <td className="text-right px-2 py-3 border-l font-bold whitespace-nowrap" style={{ color: s.prev >= 0 ? '#93C5FD' : '#FCA5A5', borderLeftColor: 'rgba(255,255,255,0.15)' }}>{formatCurrency(s.prev)}</td>
                    <td className="text-right px-2 py-3 font-bold whitespace-nowrap" style={{ color: s.real >= 0 ? '#fff' : '#FCA5A5', borderLeft: '1px dashed rgba(255,255,255,0.15)' }}>{formatCurrency(s.real)}</td>
                    <td className="text-right px-2 py-3 font-bold whitespace-nowrap" style={{ color: diff >= 0 ? '#86EFAC' : '#FCA5A5', borderLeft: '1px dashed rgba(255,255,255,0.15)' }}>{formatCurrency(diff)}</td>
                  </Fragment>
                );
              })}
              {(() => {
                const finalAcum = saldosAcumulados[saldosAcumulados.length - 1];
                if (!finalAcum) return <td colSpan={4} className="border-l" />;
                const acumP2 = saldoAcumuladoInicial + totalDRE.resultado_liquido.p2;
                const acumP3 = saldoAcumuladoInicial + totalDRE.resultado_liquido.p3;
                return (
                  <>
                    <td className="text-right px-2 py-3 border-l font-bold whitespace-nowrap" style={{ color: '#93C5FD', borderLeftColor: 'rgba(255,255,255,0.15)' }}>{formatCurrency(finalAcum.prev)}</td>
                    <td className="text-right px-2 py-3 font-bold whitespace-nowrap" style={{ color: '#93C5FD', borderLeft: '1px dashed rgba(255,255,255,0.15)' }}>{formatCurrency(acumP2)}</td>
                    <td className="text-right px-2 py-3 font-bold whitespace-nowrap" style={{ color: '#93C5FD', borderLeft: '1px dashed rgba(255,255,255,0.15)' }}>{formatCurrency(acumP3)}</td>
                    <td className="text-right px-2 py-3 font-bold whitespace-nowrap" style={{ color: '#fff', borderLeft: '1px dashed rgba(255,255,255,0.15)' }}>{formatCurrency(finalAcum.real)}</td>
                  </>
                );
              })()}
            </tr>

            {/* ── Resumo Previsto ── */}
            {(() => {
              const getEnt = (dre: DREWithDetails) => dre.receita_bruta.p1 + dre.outras_receitas.p1;
              const getSai = (dre: DREWithDetails) => Math.abs(dre.deducoes.p1) + Math.abs(dre.custos_variaveis.p1) + Math.abs(dre.despesas_operacionais.p1) + Math.abs(dre.despesas_financeiras.p1) + Math.abs(dre.distribuicao_lucro.p1);
              const rows = [
                { label: 'Entrada Prevista', get: getEnt, color: '#046C4E' },
                { label: 'Saída Prevista', get: getSai, color: '#C53030' },
                { label: 'Saldo Previsto', get: (d: DREWithDetails) => getEnt(d) - getSai(d), color: 'dynamic' },
              ];
              return rows.map((r, ri) => {
                const isSaldo = ri === 2;
                const bg = isSaldo ? '#F0FDF9' : '#FAFBFE';
                return (
                  <tr key={r.label} style={{ background: bg, borderTop: ri === 0 ? '4px solid #DAE2F0' : isSaldo ? '1px solid #DAE2F0' : '1px solid #EDF1F7' }}>
                    <td className="sticky left-0 z-10 px-3 py-2 whitespace-nowrap text-[11px]" style={{ background: bg, color: isSaldo ? 'var(--color-primary, #1A2B6D)' : '#475569', fontWeight: isSaldo ? 700 : 600 }}>
                      {r.label}
                    </td>
                    {weekDREs.map((wd, wi) => {
                      const val = r.get(wd);
                      const c = r.color === 'dynamic' ? (val >= 0 ? '#046C4E' : '#C53030') : r.color;
                      return (
                        <td key={wi} colSpan={3} className="text-center px-2 py-2 border-l whitespace-nowrap text-[11px]" style={{ color: c, fontWeight: isSaldo ? 700 : 600, borderLeftColor: '#DAE2F0' }}>
                          {formatCurrency(val)}
                        </td>
                      );
                    })}
                    <td colSpan={4} className="text-center px-2 py-2 border-l whitespace-nowrap text-[11px]" style={{ color: r.color === 'dynamic' ? (r.get(totalDRE) >= 0 ? '#046C4E' : '#C53030') : r.color, fontWeight: isSaldo ? 700 : 600, borderLeftColor: '#DAE2F0' }}>
                      {formatCurrency(r.get(totalDRE))}
                    </td>
                  </tr>
                );
              });
            })()}

            {/* ── Resumo Realizado ── */}
            {(() => {
              const getEnt = (dre: DREWithDetails) => dre.receita_bruta.real + dre.outras_receitas.real;
              const getSai = (dre: DREWithDetails) => Math.abs(dre.deducoes.real) + Math.abs(dre.custos_variaveis.real) + Math.abs(dre.despesas_operacionais.real) + Math.abs(dre.despesas_financeiras.real) + Math.abs(dre.distribuicao_lucro.real);
              const rows = [
                { label: 'Entrada Realizada', get: getEnt, color: '#046C4E' },
                { label: 'Saída Realizada', get: getSai, color: '#C53030' },
                { label: 'Saldo Realizado', get: (d: DREWithDetails) => getEnt(d) - getSai(d), color: 'dynamic' },
              ];
              return rows.map((r, ri) => {
                const isSaldo = ri === 2;
                const bg = isSaldo ? '#EFF6FF' : '#F8FAFC';
                return (
                  <tr key={r.label} style={{ background: bg, borderTop: ri === 0 ? '4px solid #93C5FD' : isSaldo ? '1px solid #DAE2F0' : '1px solid #EDF1F7' }}>
                    <td className="sticky left-0 z-10 px-3 py-2 whitespace-nowrap text-[11px]" style={{ background: bg, color: isSaldo ? 'var(--color-primary, #1A2B6D)' : '#475569', fontWeight: isSaldo ? 700 : 600 }}>
                      {r.label}
                    </td>
                    {weekDREs.map((wd, wi) => {
                      const val = r.get(wd);
                      const c = r.color === 'dynamic' ? (val >= 0 ? '#046C4E' : '#C53030') : r.color;
                      return (
                        <td key={wi} colSpan={3} className="text-center px-2 py-2 border-l whitespace-nowrap text-[11px]" style={{ color: c, fontWeight: isSaldo ? 700 : 600, borderLeftColor: '#DAE2F0' }}>
                          {formatCurrency(val)}
                        </td>
                      );
                    })}
                    <td colSpan={4} className="text-center px-2 py-2 border-l whitespace-nowrap text-[11px]" style={{ color: r.color === 'dynamic' ? (r.get(totalDRE) >= 0 ? '#046C4E' : '#C53030') : r.color, fontWeight: isSaldo ? 700 : 600, borderLeftColor: '#DAE2F0' }}>
                      {formatCurrency(r.get(totalDRE))}
                    </td>
                  </tr>
                );
              });
            })()}

          </tbody>
        </table>
      </div>
    </div>
  );
}

function Fragment({ children }: { children?: React.ReactNode }) {
  return <>{children}</>;
}
