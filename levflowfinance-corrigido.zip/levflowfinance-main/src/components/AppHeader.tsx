import { useEmpresa, getPrimaryCSS } from '@/hooks/useEmpresa';
import { useAuth } from '@/hooks/useAuth';
import { ChevronDown, LogOut, User } from 'lucide-react';

export default function AppHeader({ onLogoClick }: { onLogoClick?: () => void }) {
  const { empresas, empresaAtual, empresaId, setEmpresaId } = useEmpresa();
  const { profile, signOut, isEco } = useAuth();

  const headerBg = empresaAtual ? getPrimaryCSS(empresaAtual) : '#6FA9FF';

  return (
    <div
      className="relative flex flex-col sm:flex-row items-start sm:items-center justify-between px-8 sm:px-10 py-9 sm:py-10 mb-4 gap-4 overflow-hidden"
      style={{
        borderRadius: 20,
        background: headerBg,
        backdropFilter: 'blur(20px)',
        WebkitBackdropFilter: 'blur(20px)',
        boxShadow: '0 8px 32px rgba(111, 169, 255, 0.18), inset 0 1px 0 rgba(255,255,255,0.12)',
        border: '1px solid rgba(255,255,255,0.08)',
      }}
    >
      <div className="absolute -top-20 -right-20 w-60 h-60 rounded-full pointer-events-none" style={{ background: 'radial-gradient(circle, rgba(255,255,255,0.12) 0%, transparent 70%)' }} />
      <div className="absolute -bottom-16 -left-16 w-40 h-40 rounded-full pointer-events-none" style={{ background: 'radial-gradient(circle, rgba(255,255,255,0.08) 0%, transparent 70%)' }} />

      <div className="flex items-center gap-5 relative z-10 cursor-pointer" onClick={onLogoClick}>
        {empresaAtual?.logo_b64 ? (
          <img src={`data:image/png;base64,${empresaAtual.logo_b64}`} alt="Logo" style={{ maxHeight: 32 }} />
        ) : (
          <div className="flex items-center justify-center px-4 py-2">
            <span className="font-bold text-sm" style={{ color: 'rgba(255,255,255,0.7)', letterSpacing: '-0.02em' }}>LOGO</span>
          </div>
        )}
        <div>
          <div className="text-white font-semibold" style={{ fontSize: 20, letterSpacing: '-0.03em' }}>
            DRE por Fluxo de Caixa
          </div>
          <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.5)', marginTop: 2 }}>
            Flua com paz nas suas decisões
          </div>
        </div>
      </div>

      <div className="flex items-center gap-3 relative z-10">
        <div className="w-full sm:w-auto relative">
          <select
            value={empresaId || 'TODAS'}
            onChange={e => setEmpresaId(e.target.value === 'TODAS' ? null : e.target.value)}
            className="px-4 pr-10 font-medium text-sm w-full sm:w-auto appearance-none cursor-pointer"
            style={{
              height: 42,
              borderRadius: 12,
              border: '1px solid rgba(255,255,255,0.12)',
              color: '#334155',
              minWidth: 260,
              background: 'rgba(255,255,255,0.92)',
              backdropFilter: 'blur(8px)',
              boxShadow: '0 2px 12px rgba(0,0,0,0.06)',
              fontSize: 13,
            }}
          >
            {isEco && <option value="TODAS">Consolidado (Todas as Empresas)</option>}
            {empresas.filter(e => e.ativo).map(e => (
              <option key={e.id} value={e.id}>{e.nome}</option>
            ))}
          </select>
          <ChevronDown size={15} className="absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" style={{ color: '#94A3B8' }} />
        </div>

        {/* User info + logout */}
        <div className="flex items-center gap-2">
          <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-xl" style={{ background: 'rgba(255,255,255,0.15)' }}>
            <User size={14} color="rgba(255,255,255,0.7)" />
            <span className="text-xs font-medium text-white/80">{profile?.full_name || 'Usuário'}</span>
            <span className="text-[10px] px-1.5 py-0.5 rounded-full font-semibold" style={{
              background: isEco ? 'rgba(125,255,251,0.25)' : 'rgba(255,255,255,0.2)',
              color: isEco ? '#7DFFFB' : 'rgba(255,255,255,0.8)',
            }}>
              {isEco ? 'Eco' : 'Finance'}
            </span>
          </div>
          <button
            onClick={signOut}
            className="flex items-center justify-center rounded-xl transition-all hover:bg-white/20"
            style={{ width: 38, height: 38, background: 'rgba(255,255,255,0.1)' }}
            title="Sair"
          >
            <LogOut size={16} color="rgba(255,255,255,0.7)" />
          </button>
        </div>
      </div>
    </div>
  );
}
