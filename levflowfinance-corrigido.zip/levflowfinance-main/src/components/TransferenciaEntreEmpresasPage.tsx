import { useState, useMemo, useEffect } from 'react';
import { useEmpresa } from '@/hooks/useEmpresa';
import { supabase } from '@/integrations/supabase/client';
import { formatCurrency, applyCurrencyMask, parseCurrencyInput } from '@/lib/formatters';
import { CATEGORIAS_RECEITA } from '@/lib/constants';
import { CARD, BANNER } from '@/lib/ui-styles';
import {
  ArrowRightLeft, Calendar, AlertTriangle, CheckCircle, Building2,
  TrendingUp, TrendingDown, X, Landmark, Send
} from 'lucide-react';
import { addDays, format, differenceInDays, eachDayOfInterval, startOfWeek, endOfWeek, eachWeekOfInterval } from 'date-fns';
import toast from 'react-hot-toast';

interface EmpresaCashFlow {
  empresaId: string;
  empresaNome: string;
  saldoAtual: number;
  periodos: { label: string; start: string; end: string; entradas: number; saidas: number; saldo: number; saldoAcumulado: number }[];
  saudavel: boolean;
  menorSaldo: number;
}

interface TransferRec {
  receptor: string;
  receptorId: string;
  doador: string;
  doadorId: string;
  valor: number;
  valorEditado: string;
  deficit: number;
  periodoLabel: string;
  viavel: boolean;
}

interface TransferModal {
  rec: TransferRec;
  bancoOrigemId: string;
  bancoDestinoId: string;
}

export default function TransferenciaEntreEmpresasPage() {
  const { empresas } = useEmpresa();
  const todayStr = format(new Date(), 'yyyy-MM-dd');
  const [dateStart, setDateStart] = useState(todayStr);
  const [dateEnd, setDateEnd] = useState(format(addDays(new Date(), 30), 'yyyy-MM-dd'));
  const [allData, setAllData] = useState<{ planoContas: any[]; orcamentos: any[]; lancamentos: any[]; bancos: any[]; pendencias: any[] }>({
    planoContas: [], orcamentos: [], lancamentos: [], bancos: [], pendencias: [],
  });
  const [loading, setLoading] = useState(true);
  const [transferModal, setTransferModal] = useState<TransferModal | null>(null);
  const [editedRecs, setEditedRecs] = useState<Record<number, string>>({});
  const [executing, setExecuting] = useState(false);

  const activeEmpresas = empresas.filter(e => e.ativo);
  const activeIds = activeEmpresas.map(e => e.id);

  const fetchData = () => {
    if (activeIds.length === 0) { setLoading(false); return; }
    setLoading(true);
    Promise.all([
      supabase.from('plano_contas').select('*').in('empresa_id', activeIds),
      supabase.from('orcamentos').select('*').in('empresa_id', activeIds),
      supabase.from('lancamentos_reais').select('*').in('empresa_id', activeIds),
      supabase.from('bancos').select('*').in('empresa_id', activeIds),
      supabase.from('pendencias').select('*').in('empresa_id', activeIds),
    ]).then(([pc, orc, lr, b, pen]) => {
      setAllData({
        planoContas: pc.data || [],
        orcamentos: orc.data || [],
        lancamentos: lr.data || [],
        bancos: b.data || [],
        pendencias: pen.data || [],
      });
      setLoading(false);
    });
  };

  useEffect(() => { fetchData(); }, [activeIds.join(',')]);

  // Determine if daily or weekly based on range
  const totalDays = useMemo(() => {
    const s = new Date(dateStart);
    const e = new Date(dateEnd);
    return Math.max(differenceInDays(e, s) + 1, 1);
  }, [dateStart, dateEnd]);

  const cashFlows = useMemo(() => {
    if (loading || activeEmpresas.length === 0) return [];

    const s = new Date(dateStart);
    const e = new Date(dateEnd);

    // Build periods: daily if <= 14 days, weekly otherwise
    const periodos: { label: string; start: string; end: string }[] = [];
    if (totalDays <= 14) {
      eachDayOfInterval({ start: s, end: e }).forEach(d => {
        const ds = format(d, 'yyyy-MM-dd');
        periodos.push({ label: format(d, 'dd/MM'), start: ds, end: ds });
      });
    } else {
      const weeks = eachWeekOfInterval({ start: s, end: e }, { weekStartsOn: 1 });
      weeks.forEach(ws => {
        const we = endOfWeek(ws, { weekStartsOn: 1 });
        const actualEnd = we > e ? e : we;
        const actualStart = ws < s ? s : ws;
        periodos.push({
          label: `${format(actualStart, 'dd/MM')} - ${format(actualEnd, 'dd/MM')}`,
          start: format(actualStart, 'yyyy-MM-dd'),
          end: format(actualEnd, 'yyyy-MM-dd'),
        });
      });
    }

    const results: EmpresaCashFlow[] = activeEmpresas.map(emp => {
      const empPC = allData.planoContas.filter((p: any) => p.empresa_id === emp.id);
      const empOrc = allData.orcamentos.filter((o: any) => o.empresa_id === emp.id);
      const empLanc = allData.lancamentos.filter((l: any) => l.empresa_id === emp.id);
      const empBancos = allData.bancos.filter((b: any) => b.empresa_id === emp.id);
      const empPend = allData.pendencias.filter((p: any) => p.empresa_id === emp.id);

      const saldoBancos = empBancos.reduce((acc: number, b: any) => acc + Number(b.saldo || 0), 0);
      const catMap: Record<string, string> = {};
      empPC.forEach((pc: any) => { catMap[pc.nome_conta] = pc.categoria_dre; });

      let acumulado = saldoBancos;
      const periodosCalc = periodos.map(per => {
        let entradas = 0;
        let saidas = 0;

        empOrc.forEach((o: any) => {
          if (o.data_ref >= per.start && o.data_ref <= per.end) {
            const cat = catMap[o.conta];
            const valor = Number(o.p1 || 0);
            if (CATEGORIAS_RECEITA.includes(cat)) entradas += valor;
            else saidas += valor;
          }
        });

        empLanc.forEach((l: any) => {
          if (!l.ativo) return;
          if (l.data_real >= per.start && l.data_real <= per.end) {
            const cat = catMap[l.conta];
            const valor = Number(l.valor || 0);
            if (CATEGORIAS_RECEITA.includes(cat)) entradas += valor;
            else saidas += valor;
          }
        });

        empPend.forEach((p: any) => {
          if (p.data >= per.start && p.data <= per.end) {
            if (p.tipo === 'entrada') entradas += Number(p.valor || 0);
            else saidas += Number(p.valor || 0);
          }
        });

        const saldo = entradas - saidas;
        acumulado += saldo;
        return { ...per, entradas, saidas, saldo, saldoAcumulado: acumulado };
      });

      const menorSaldo = periodosCalc.length > 0 ? Math.min(...periodosCalc.map(p => p.saldoAcumulado)) : saldoBancos;

      return {
        empresaId: emp.id,
        empresaNome: emp.nome,
        saldoAtual: saldoBancos,
        periodos: periodosCalc,
        saudavel: menorSaldo >= 0,
        menorSaldo,
      };
    });

    return results;
  }, [allData, activeEmpresas, dateStart, dateEnd, totalDays, loading]);

  const needCash = cashFlows.filter(c => !c.saudavel).sort((a, b) => a.menorSaldo - b.menorSaldo);
  const healthy = cashFlows.filter(c => c.saudavel).sort((a, b) => b.menorSaldo - a.menorSaldo);

  const recommendations: TransferRec[] = useMemo(() => {
    if (needCash.length === 0 || healthy.length === 0) return [];
    return needCash.map(empresa => {
      const criticalPeriod = empresa.periodos.find(p => p.saldoAcumulado < 0);
      const deficit = criticalPeriod ? Math.abs(criticalPeriod.saldoAcumulado) : Math.abs(empresa.menorSaldo);
      const donor = healthy[0];
      const canTransfer = Math.min(deficit, donor.menorSaldo * 0.5);
      const valor = canTransfer > 0 ? canTransfer : deficit;
      return {
        receptor: empresa.empresaNome,
        receptorId: empresa.empresaId,
        doador: donor.empresaNome,
        doadorId: donor.empresaId,
        valor,
        valorEditado: applyCurrencyMask(String(Math.round(valor * 100))),
        deficit,
        periodoLabel: criticalPeriod?.label || empresa.periodos[empresa.periodos.length - 1]?.label || '-',
        viavel: canTransfer >= deficit,
      };
    });
  }, [needCash, healthy]);

  const getEditedValue = (i: number) => editedRecs[i] ?? recommendations[i]?.valorEditado ?? '';

  const handleExecuteTransfer = async () => {
    if (!transferModal) return;
    const { rec, bancoOrigemId, bancoDestinoId } = transferModal;
    if (!bancoOrigemId || !bancoDestinoId) {
      toast.error('Selecione o banco de origem e destino.');
      return;
    }

    const idx = recommendations.findIndex(r => r.receptorId === rec.receptorId && r.doadorId === rec.doadorId);
    const valorStr = getEditedValue(idx >= 0 ? idx : 0);
    const valor = parseCurrencyInput(valorStr);
    if (valor <= 0) { toast.error('Valor inválido.'); return; }

    setExecuting(true);
    try {
      // Get current balances
      const { data: bancoOrigem } = await supabase.from('bancos').select('saldo, nome').eq('id', bancoOrigemId).single();
      const { data: bancoDest } = await supabase.from('bancos').select('saldo, nome').eq('id', bancoDestinoId).single();

      if (!bancoOrigem || !bancoDest) { toast.error('Banco não encontrado.'); setExecuting(false); return; }

      const saldoOrigem = Number(bancoOrigem.saldo || 0);
      const saldoDest = Number(bancoDest.saldo || 0);

      // Update balances
      const { error: e1 } = await supabase.from('bancos').update({ saldo: saldoOrigem - valor }).eq('id', bancoOrigemId);
      const { error: e2 } = await supabase.from('bancos').update({ saldo: saldoDest + valor }).eq('id', bancoDestinoId);

      if (e1 || e2) {
        toast.error('Erro ao atualizar saldos bancários.');
        setExecuting(false);
        return;
      }

      // Ensure plano_contas entries exist for transfer accounts
      const contaSaida = 'Transferência Enviada';
      const contaEntrada = 'Transferência Recebida';

      // Check/create plano_contas for donor (expense)
      const { data: pcDoador } = await supabase.from('plano_contas')
        .select('id').eq('empresa_id', rec.doadorId).eq('nome_conta', contaSaida).maybeSingle();
      if (!pcDoador) {
        await supabase.from('plano_contas').insert({
          empresa_id: rec.doadorId, nome_conta: contaSaida, categoria_dre: 'despesas_financeiras',
        });
      }

      // Check/create plano_contas for receiver (revenue)
      const { data: pcReceptor } = await supabase.from('plano_contas')
        .select('id').eq('empresa_id', rec.receptorId).eq('nome_conta', contaEntrada).maybeSingle();
      if (!pcReceptor) {
        await supabase.from('plano_contas').insert({
          empresa_id: rec.receptorId, nome_conta: contaEntrada, categoria_dre: 'outras_receitas',
        });
      }

      // Create real entries: expense for donor, revenue for receiver
      const todayDate = format(new Date(), 'yyyy-MM-dd');
      await supabase.from('lancamentos_reais').insert([
        {
          empresa_id: rec.doadorId,
          conta: contaSaida,
          valor,
          data_real: todayDate,
          descricao: `Transferência para ${rec.receptor} - ${bancoOrigem.nome} → ${bancoDest.nome}`,
          banco: bancoOrigem.nome,
          ativo: true,
          nao_previsto: true,
        },
        {
          empresa_id: rec.receptorId,
          conta: contaEntrada,
          valor,
          data_real: todayDate,
          descricao: `Transferência de ${rec.doador} - ${bancoOrigem.nome} → ${bancoDest.nome}`,
          banco: bancoDest.nome,
          ativo: true,
          nao_previsto: true,
        },
      ]);

      toast.success(`Transferência de ${formatCurrency(valor)} realizada com sucesso!`);
      setTransferModal(null);
      fetchData(); // Refresh data
    } catch (err) {
      toast.error('Erro ao realizar transferência.');
    }
    setExecuting(false);
  };

  // Banks by company for modal
  const bancosByEmpresa = (empresaId: string) => allData.bancos.filter((b: any) => b.empresa_id === empresaId);

  if (loading) return <div className="flex items-center justify-center h-64" style={{ color: '#94A3B8' }}>Carregando análise...</div>;

  const cardStyle = CARD;

  return (
    <div className="space-y-5">
      <div style={BANNER}>
        <h3 className="font-semibold text-base flex items-center gap-2"><ArrowRightLeft size={16} /> Transferência entre Empresas</h3>
        <p className="text-xs opacity-80">Análise de necessidade de caixa e recomendações de transferência entre empresas do grupo.</p>
      </div>

      {/* Filtro por período */}
      <div className="flex flex-wrap items-center gap-4 px-5 py-3" style={{ background: '#fff', border: '1px solid #E8EDF5', borderRadius: 20 }}>
        <span className="text-xs font-semibold uppercase tracking-wider" style={{ color: '#94A3B8' }}>Período de Análise</span>
        <div className="flex items-center gap-2">
          <Calendar size={14} style={{ color: '#94A3B8' }} />
          <input type="date" value={dateStart} onChange={e => setDateStart(e.target.value)}
            className="text-sm" style={{ height: 36, borderRadius: 12, border: '1px solid #E8EDF5', padding: '0 10px', background: '#FAFBFE' }} />
          <span className="text-xs" style={{ color: '#CBD5E1' }}>até</span>
          <input type="date" value={dateEnd} onChange={e => setDateEnd(e.target.value)}
            className="text-sm" style={{ height: 36, borderRadius: 12, border: '1px solid #E8EDF5', padding: '0 10px', background: '#FAFBFE' }} />
        </div>
        <span className="text-xs" style={{ color: '#94A3B8' }}>
          {totalDays} {totalDays === 1 ? 'dia' : 'dias'} • Exibição {totalDays <= 14 ? 'diária' : 'semanal'}
        </span>
      </div>

      {/* Recomendações */}
      {recommendations.length > 0 ? (
        <div style={{ ...cardStyle, background: 'linear-gradient(135deg, #FFF5F5 0%, #fff 100%)', borderColor: '#FECACA' }}>
          <div className="flex items-center gap-2 mb-4">
            <AlertTriangle size={16} style={{ color: '#C53030' }} />
            <span className="font-semibold text-sm" style={{ color: '#C53030' }}>Recomendações de Transferência</span>
          </div>
          <div className="space-y-3">
            {recommendations.map((rec, i) => (
              <div key={i} className="p-4 rounded-xl" style={{ background: '#fff', border: '1px solid #FECACA' }}>
                <div className="flex flex-wrap items-center gap-3 mb-2">
                  <div className="flex items-center gap-1.5">
                    <Building2 size={14} style={{ color: '#046C4E' }} />
                    <span className="text-sm font-semibold" style={{ color: '#046C4E' }}>{rec.doador}</span>
                  </div>
                  <ArrowRightLeft size={14} style={{ color: '#94A3B8' }} />
                  <div className="flex items-center gap-1.5">
                    <Building2 size={14} style={{ color: '#C53030' }} />
                    <span className="text-sm font-semibold" style={{ color: '#C53030' }}>{rec.receptor}</span>
                  </div>
                </div>
                <div className="text-xs space-y-2" style={{ color: '#64748B' }}>
                  <div>Déficit previsto: <strong style={{ color: '#C53030' }}>{formatCurrency(rec.deficit)}</strong> em <strong>{rec.periodoLabel}</strong></div>
                  <div className="flex items-center gap-2">
                    <span>Transferência sugerida:</span>
                    <input
                      value={getEditedValue(i)}
                      onChange={e => setEditedRecs(prev => ({ ...prev, [i]: applyCurrencyMask(e.target.value) }))}
                      className="font-bold text-sm"
                      style={{
                        color: '#1A2B6D', width: 150, height: 32, borderRadius: 10,
                        border: '1px solid #E8EDF5', padding: '0 8px', background: '#FAFBFE',
                      }}
                    />
                  </div>
                  {!rec.viavel && (
                    <div className="text-xs px-2 py-1 rounded-lg inline-block" style={{ background: '#FEF3C7', color: '#92400E' }}>
                      ⚠ O doador não tem saldo suficiente para cobrir 100% do déficit.
                    </div>
                  )}
                  <div className="mt-2">
                    <button
                      onClick={() => setTransferModal({
                        rec: { ...rec, valorEditado: getEditedValue(i) },
                        bancoOrigemId: '',
                        bancoDestinoId: '',
                      })}
                      className="text-white font-semibold flex items-center gap-2 text-xs"
                      style={{
                        height: 34, borderRadius: 12, padding: '0 16px',
                        background: 'var(--color-button-gradient, var(--color-button, var(--color-primary)))',
                      }}
                    >
                      <Send size={12} /> Realizar Transferência
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div style={{ ...cardStyle, background: 'linear-gradient(135deg, #F0FDF4 0%, #fff 100%)', borderColor: '#BBF7D0' }}>
          <div className="flex items-center gap-2">
            <CheckCircle size={16} style={{ color: '#046C4E' }} />
            <span className="font-semibold text-sm" style={{ color: '#046C4E' }}>Todas as empresas estão saudáveis no período analisado</span>
          </div>
          <p className="text-xs mt-1" style={{ color: '#64748B' }}>Nenhuma transferência necessária.</p>
        </div>
      )}

      {/* Detalhamento por empresa */}
      <div className="space-y-4">
        {cashFlows.map(cf => (
          <div key={cf.empresaId} style={cardStyle}>
            <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <Building2 size={16} style={{ color: 'var(--color-primary, #6FA9FF)' }} />
                <span className="font-semibold text-sm">{cf.empresaNome}</span>
              </div>
              <div className="flex items-center gap-2">
                {cf.saudavel ? (
                  <span className="text-xs px-2 py-1 rounded-full font-medium" style={{ background: '#F0FDF4', color: '#046C4E' }}>
                    <TrendingUp size={12} className="inline mr-1" />Saudável
                  </span>
                ) : (
                  <span className="text-xs px-2 py-1 rounded-full font-medium" style={{ background: '#FFF5F5', color: '#C53030' }}>
                    <TrendingDown size={12} className="inline mr-1" />Precisa de Aporte
                  </span>
                )}
                <span className="text-xs font-medium" style={{ color: '#94A3B8' }}>Saldo atual: {formatCurrency(cf.saldoAtual)}</span>
              </div>
            </div>
            <div className="overflow-auto">
              <table className="w-full text-xs" style={{ minWidth: 600 }}>
                <thead>
                  <tr style={{ background: '#FAFBFE' }}>
                    <th className="text-left px-3 py-2 font-medium" style={{ color: '#94A3B8' }}>Período</th>
                    <th className="text-right px-3 py-2 font-medium" style={{ color: '#94A3B8' }}>Entradas</th>
                    <th className="text-right px-3 py-2 font-medium" style={{ color: '#94A3B8' }}>Saídas</th>
                    <th className="text-right px-3 py-2 font-medium" style={{ color: '#94A3B8' }}>Resultado</th>
                    <th className="text-right px-3 py-2 font-medium" style={{ color: '#94A3B8' }}>Saldo Acumulado</th>
                  </tr>
                </thead>
                <tbody>
                  {cf.periodos.map((p, i) => (
                    <tr key={i} className="border-b" style={{ borderColor: '#F1F5F9' }}>
                      <td className="px-3 py-2 font-medium" style={{ color: '#334155' }}>{p.label}</td>
                      <td className="text-right px-3 py-2 whitespace-nowrap" style={{ color: '#046C4E' }}>{formatCurrency(p.entradas)}</td>
                      <td className="text-right px-3 py-2 whitespace-nowrap" style={{ color: '#C53030' }}>{formatCurrency(p.saidas)}</td>
                      <td className="text-right px-3 py-2 whitespace-nowrap font-medium" style={{ color: p.saldo >= 0 ? '#046C4E' : '#C53030' }}>{formatCurrency(p.saldo)}</td>
                      <td className="text-right px-3 py-2 whitespace-nowrap font-bold" style={{ color: p.saldoAcumulado >= 0 ? '#046C4E' : '#C53030' }}>{formatCurrency(p.saldoAcumulado)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ))}
      </div>

      {/* Modal de Transferência */}
      {transferModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center" style={{ background: 'rgba(0,0,0,0.4)' }}>
          <div className="w-full max-w-md mx-4 p-6" style={{ background: '#fff', borderRadius: 24, boxShadow: '0 20px 60px rgba(0,0,0,0.15)' }}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-sm flex items-center gap-2">
                <ArrowRightLeft size={16} style={{ color: 'var(--color-primary, #6FA9FF)' }} />
                Realizar Transferência
              </h3>
              <button onClick={() => setTransferModal(null)}><X size={18} style={{ color: '#94A3B8' }} /></button>
            </div>

            <div className="space-y-4">
              <div className="p-3 rounded-xl text-xs" style={{ background: '#FAFBFE', border: '1px solid #E8EDF5' }}>
                <div className="flex items-center gap-2 mb-1">
                  <span style={{ color: '#046C4E', fontWeight: 600 }}>{transferModal.rec.doador}</span>
                  <ArrowRightLeft size={12} style={{ color: '#94A3B8' }} />
                  <span style={{ color: '#C53030', fontWeight: 600 }}>{transferModal.rec.receptor}</span>
                </div>
                <div style={{ color: '#64748B' }}>Valor: <strong style={{ color: '#1A2B6D' }}>{transferModal.rec.valorEditado}</strong></div>
              </div>

              <div>
                <label className="text-xs font-medium block mb-1" style={{ color: '#64748B' }}>
                  <Landmark size={12} className="inline mr-1" />Banco de Origem ({transferModal.rec.doador})
                </label>
                <select
                  value={transferModal.bancoOrigemId}
                  onChange={e => setTransferModal({ ...transferModal, bancoOrigemId: e.target.value })}
                  style={{ width: '100%', height: 38, borderRadius: 12, border: '1px solid #E8EDF5', fontSize: 13, padding: '0 8px' }}
                >
                  <option value="">Selecione o banco...</option>
                  {bancosByEmpresa(transferModal.rec.doadorId).map((b: any) => (
                    <option key={b.id} value={b.id}>{b.nome} — {formatCurrency(Number(b.saldo || 0))}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs font-medium block mb-1" style={{ color: '#64748B' }}>
                  <Landmark size={12} className="inline mr-1" />Banco de Destino ({transferModal.rec.receptor})
                </label>
                <select
                  value={transferModal.bancoDestinoId}
                  onChange={e => setTransferModal({ ...transferModal, bancoDestinoId: e.target.value })}
                  style={{ width: '100%', height: 38, borderRadius: 12, border: '1px solid #E8EDF5', fontSize: 13, padding: '0 8px' }}
                >
                  <option value="">Selecione o banco...</option>
                  {bancosByEmpresa(transferModal.rec.receptorId).map((b: any) => (
                    <option key={b.id} value={b.id}>{b.nome} — {formatCurrency(Number(b.saldo || 0))}</option>
                  ))}
                </select>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  onClick={() => setTransferModal(null)}
                  className="flex-1 text-xs font-medium py-2 rounded-xl"
                  style={{ border: '1px solid #E8EDF5', color: '#64748B' }}
                >
                  Cancelar
                </button>
                <button
                  onClick={handleExecuteTransfer}
                  disabled={executing}
                  className="flex-1 text-white text-xs font-semibold py-2 rounded-xl flex items-center justify-center gap-2"
                  style={{ background: 'var(--color-button-gradient, var(--color-button, var(--color-primary)))', opacity: executing ? 0.6 : 1 }}
                >
                  <Send size={12} /> {executing ? 'Processando...' : 'Confirmar Transferência'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
