import { useEmpresa } from '@/hooks/useEmpresa';
import { useAuth } from '@/hooks/useAuth';
import { BarChart3, Table2, CalendarRange, Target, Banknote, Landmark, Briefcase, Settings, ChevronDown, ArrowRightLeft } from 'lucide-react';
import { useState } from 'react';

const TABS_ALL = [
  { id: 'dash', label: 'Visão Geral', icon: BarChart3 },
  { id: 'dre4', label: 'DRE 4 Semanas', icon: Table2 },
  { id: 'dreanual', label: 'DRE Anual', icon: CalendarRange },
  { id: 'transferencia', label: 'Transferência entre Empresas', icon: ArrowRightLeft },
];

const GROUPS_EMPRESA = [
  {
    label: 'Análise',
    tabs: [
      { id: 'dash', label: 'Visão Geral', icon: BarChart3 },
      { id: 'dre4', label: 'DRE 4 Semanas', icon: Table2 },
      { id: 'dreanual', label: 'DRE Anual', icon: CalendarRange },
    ],
  },
  {
    label: 'Operacional',
    tabs: [
      { id: 'planejamento', label: 'Planejamento', icon: Target },
      { id: 'realizado', label: 'Realizado', icon: Banknote },
      { id: 'conciliacao', label: 'Conciliação', icon: Landmark },
    ],
  },
  {
    label: 'Ferramentas',
    tabs: [
      { id: 'acaocfo', label: 'Ação CFO', icon: Briefcase },
      { id: 'cadastro', label: 'Cadastro', icon: Settings },
    ],
  },
];

interface Props {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export default function AppNav({ activeTab, onTabChange }: Props) {
  const { isAllMode } = useEmpresa();

  if (isAllMode) {
    return (
      <div
        className="flex items-center gap-1 bg-white px-3 py-2 mb-6 overflow-x-auto"
        style={{ borderRadius: 16, border: '1px solid #E8EDF5', boxShadow: '0 1px 4px rgba(111,169,255,0.04)' }}
      >
        {TABS_ALL.map(t => {
          const Icon = t.icon;
          const isActive = activeTab === t.id;
          return (
            <button
              key={t.id}
              onClick={() => onTabChange(t.id)}
              className="font-medium transition-all flex items-center gap-2 whitespace-nowrap flex-shrink-0"
              style={{
                borderRadius: 12, height: 40, fontSize: 13, padding: '0 16px',
                background: isActive ? 'var(--color-button-gradient, var(--color-button, var(--color-primary)))' : 'transparent',
                color: isActive ? '#fff' : '#94A3B8',
                boxShadow: isActive ? '0 2px 8px rgba(111,169,255,0.25)' : 'none',
              }}
              onMouseEnter={e => { if (!isActive) (e.currentTarget as HTMLElement).style.backgroundColor = '#F5F8FF'; }}
              onMouseLeave={e => { if (!isActive) (e.currentTarget as HTMLElement).style.backgroundColor = 'transparent'; }}
            >
              <Icon size={15} />{t.label}
            </button>
          );
        })}
      </div>
    );
  }

  return (
    <div
      className="flex items-center gap-1 bg-white px-3 py-2 mb-6 overflow-x-auto"
      style={{ borderRadius: 16, border: '1px solid #E8EDF5', boxShadow: '0 1px 4px rgba(111,169,255,0.04)' }}
    >
      {GROUPS_EMPRESA.map((group, gi) => (
        <div key={gi} className="flex items-center gap-1 flex-shrink-0">
          {gi > 0 && <div className="w-px h-5 mx-1" style={{ background: '#E8EDF5' }} />}
          {group.tabs.map(t => {
            const Icon = t.icon;
            const isActive = activeTab === t.id;
            return (
              <button
                key={t.id}
                onClick={() => onTabChange(t.id)}
                className="font-medium transition-all flex items-center gap-2 whitespace-nowrap flex-shrink-0"
                style={{
                  borderRadius: 12, height: 40, fontSize: 13, padding: '0 14px',
                  background: isActive ? 'var(--color-button-gradient, var(--color-button, var(--color-primary)))' : 'transparent',
                  color: isActive ? '#fff' : '#94A3B8',
                  boxShadow: isActive ? '0 2px 8px rgba(111,169,255,0.25)' : 'none',
                }}
                onMouseEnter={e => { if (!isActive) (e.currentTarget as HTMLElement).style.backgroundColor = '#F5F8FF'; }}
                onMouseLeave={e => { if (!isActive) (e.currentTarget as HTMLElement).style.backgroundColor = 'transparent'; }}
              >
                <Icon size={15} />{t.label}
              </button>
            );
          })}
        </div>
      ))}
    </div>
  );
}
