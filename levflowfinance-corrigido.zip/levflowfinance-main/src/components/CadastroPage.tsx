import { useState } from 'react';
import { useEmpresa } from '@/hooks/useEmpresa';
import { useAuth } from '@/hooks/useAuth';
import { useSupabaseData } from '@/hooks/useSupabaseData';
import { supabase } from '@/integrations/supabase/client';
import { applyCurrencyMask, parseCurrencyInput, applyPhoneMask } from '@/lib/formatters';
import { TIPO_MAPEAMENTO, CATEGORIAS_DRE, CATEGORIAS_RECEITA } from '@/lib/constants';
import { CARD, INPUT, BTN_PRIMARY, SECTION_TITLE, LABEL, tabStyle as sharedTabStyle, TAB_CONTAINER, BANNER } from '@/lib/ui-styles';
import toast from 'react-hot-toast';
import { Building2, FileText, Landmark, CreditCard, BarChart3, Palette, Plus, Trash2, Save, Edit, Copy, Pause, TrendingUp, TrendingDown, Briefcase, ShieldAlert, ChevronDown, ChevronRight } from 'lucide-react';

export default function CadastroPage() {
  const { empresaAtual } = useEmpresa();
  const { planoContas, bancos, formasPagamento, refetch } = useSupabaseData();
  const [tab, setTab] = useState('empresas');

  if (!empresaAtual) return null;

  const tabs = [
    { id: 'empresas', label: 'Empresas', icon: Building2 },
    { id: 'plano', label: 'Plano de Contas', icon: FileText },
    { id: 'bancos', label: 'Contas Bancárias', icon: Landmark },
    { id: 'formas', label: 'Formas de Pagamento', icon: CreditCard },
    { id: 'cenarios', label: 'Cenários', icon: BarChart3 },
    { id: 'design', label: 'Design', icon: Palette },
    { id: 'pendencias', label: 'Regras de Pendência', icon: ShieldAlert },
  ];

  return (
    <div className="space-y-5">
      <div style={BANNER}>
        <h3 className="font-semibold text-base">Configurações e Cadastros</h3>
        <p className="text-xs opacity-80">Centralize aqui todas as configurações.</p>
      </div>

      <div className="flex gap-2 flex-wrap" style={TAB_CONTAINER}>
        {tabs.map(t => {
          const Icon = t.icon;
          return <button key={t.id} onClick={() => setTab(t.id)} style={sharedTabStyle(tab === t.id)} className="flex items-center gap-1.5"><Icon size={14} />{t.label}</button>;
        })}
      </div>

      {tab === 'empresas' && <EmpresasTab />}
      {tab === 'plano' && <PlanoContasTab />}
      {tab === 'bancos' && <BancosTab />}
      {tab === 'formas' && <FormasPagamentoTab />}
      {tab === 'cenarios' && <CenariosTab />}
      {tab === 'design' && <DesignTab />}
      {tab === 'pendencias' && <RegrasPendenciaTab />}
    </div>
  );
}

function EmpresasTab() {
  const { empresas, refreshEmpresas } = useEmpresa();
  const { user } = useAuth();
  const [nome, setNome] = useState('');
  const [cnpj, setCnpj] = useState('');
  const [obs, setObs] = useState('');
  const [selected, setSelected] = useState<Set<string>>(new Set());

  const handleAdd = async () => {
    if (!nome) { toast.error('Informe o nome'); return; }
    if (!user) { toast.error('Usuário não autenticado'); return; }
    const { data, error } = await supabase.from('empresas').insert({ nome, cnpj, obs }).select('id').single();
    if (error || !data) { toast.error(error?.message || 'Erro ao cadastrar'); return; }
    // Link empresa to current user
    await supabase.from('user_empresas').insert({ user_id: user.id, empresa_id: data.id });
    toast.success('Empresa cadastrada!'); setNome(''); setCnpj(''); setObs('');
    await refreshEmpresas();
  };

  const handleToggleAtivo = async () => {
    for (const id of Array.from(selected)) {
      const emp = empresas.find(e => e.id === id);
      if (emp) await supabase.from('empresas').update({ ativo: !emp.ativo }).eq('id', id);
    }
    toast.success('Atualizado!'); setSelected(new Set()); refreshEmpresas();
  };

  const cardStyle = CARD;
  const inputStyle = INPUT;

  return (
    <div className="space-y-4">
      <div style={cardStyle}>
        <h3 className="font-semibold mb-3" style={SECTION_TITLE}>Cadastrar Nova Empresa</h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div><label className="text-xs font-medium block mb-1">Razão Social / Nome da Empresa</label><input value={nome} onChange={e => setNome(e.target.value)} style={inputStyle} /></div>
          <div><label className="text-xs font-medium block mb-1">CNPJ</label><input value={cnpj} onChange={e => setCnpj(e.target.value)} style={inputStyle} /></div>
          <div><label className="text-xs font-medium block mb-1">Observação</label><input value={obs} onChange={e => setObs(e.target.value)} style={inputStyle} /></div>
        </div>
        <div className="mt-3 flex justify-end">
          <button onClick={handleAdd} className="text-white font-semibold flex items-center gap-2" style={{ height: 38, borderRadius: 14, fontSize: 12.5, padding: '0 24px', background: 'var(--color-button-gradient, var(--color-button, var(--color-primary)))' }}><Plus size={14} /> Cadastrar</button>
        </div>
      </div>
      <div style={cardStyle}>
        <h3 className="font-semibold mb-3" style={SECTION_TITLE}>Empresas Cadastradas</h3>
        {selected.size > 0 && (
          <div className="flex gap-2 mb-3">
            <button onClick={handleToggleAtivo} className="text-xs text-white font-semibold px-3 py-1.5 rounded-lg flex items-center gap-1" style={{ backgroundColor: '#DD6B20' }}><Pause size={12} /> Inativar / Ativar</button>
          </div>
        )}
        <div className="overflow-auto">
          <table className="w-full text-xs" style={{ minWidth: 600 }}>
            <thead><tr style={{ background: '#FAFBFE' }}><th className="px-2 py-2 text-left">Razão Social</th><th className="px-2 py-2 text-left">CNPJ</th><th className="px-2 py-2 text-left">Obs</th><th className="px-2 py-2">Status</th><th className="px-2 py-2"><input type="checkbox" checked={empresas.length > 0 && selected.size === empresas.length} onChange={e => { if (e.target.checked) setSelected(new Set(empresas.map(emp => emp.id))); else setSelected(new Set()); }} /> Todos</th></tr></thead>
            <tbody>{empresas.map(e => (
              <tr key={e.id} className="border-b">
                <td className="px-2 py-1.5">{e.nome}</td><td className="px-2 py-1.5">{e.cnpj}</td><td className="px-2 py-1.5">{e.obs}</td>
                <td className="px-2 py-1.5 text-center"><span className={`text-xs px-2 py-0.5 rounded-full ${e.ativo ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>{e.ativo ? 'Ativa' : 'Inativa'}</span></td>
                <td className="px-2 py-1.5 text-center"><input type="checkbox" checked={selected.has(e.id)} onChange={ev => { const n = new Set(selected); if (ev.target.checked) n.add(e.id); else n.delete(e.id); setSelected(n); }} /></td>
              </tr>
            ))}</tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function PlanoContasTab() {
  const { empresaAtual, empresas } = useEmpresa();
  const { planoContas, refetch } = useSupabaseData();
  const [subTab, setSubTab] = useState('add');
  const [nome, setNome] = useState('');
  const [grupo, setGrupo] = useState('');

  if (!empresaAtual) return null;
  const empContas = planoContas.filter(p => p.empresa_id === empresaAtual.id);

  const handleAdd = async () => {
    if (!nome || !grupo) { toast.error('Preencha todos os campos'); return; }
    const catValue = TIPO_MAPEAMENTO[grupo];
    const { error } = await supabase.from('plano_contas').insert({
      empresa_id: empresaAtual.id, nome_conta: nome, categoria_dre: catValue,
      exige_faturamento: CATEGORIAS_RECEITA.includes(catValue as any),
    });
    if (error) { toast.error(error.message); return; }
    toast.success('Conta adicionada!'); setNome(''); refetch();
  };

  const cardStyle = CARD;
  const inputStyle = INPUT;

  const grouped = CATEGORIAS_DRE.reduce((acc, cat) => {
    acc[cat.value] = empContas.filter(c => c.categoria_dre === cat.value);
    return acc;
  }, {} as Record<string, any[]>);

  return (
    <div className="space-y-4">
      <div className="flex gap-2 flex-wrap">
        <button onClick={() => setSubTab('add')} className="text-xs font-semibold px-3 py-1.5 rounded flex items-center gap-1" style={{ backgroundColor: subTab === 'add' ? 'var(--color-primary)' : '#F1F5F9', color: subTab === 'add' ? '#fff' : '#64748B' }}><Plus size={12} /> Adicionar</button>
        <button onClick={() => setSubTab('edit')} className="text-xs font-semibold px-3 py-1.5 rounded flex items-center gap-1" style={{ backgroundColor: subTab === 'edit' ? 'var(--color-primary)' : '#F1F5F9', color: subTab === 'edit' ? '#fff' : '#64748B' }}><Edit size={12} /> Editar / Remover</button>
        <button onClick={() => setSubTab('dup')} className="text-xs font-semibold px-3 py-1.5 rounded flex items-center gap-1" style={{ backgroundColor: subTab === 'dup' ? 'var(--color-primary)' : '#F1F5F9', color: subTab === 'dup' ? '#fff' : '#64748B' }}><Copy size={12} /> Duplicar Plano</button>
      </div>

      {subTab === 'add' && (
        <div style={cardStyle}>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 items-end">
            <div><label className="text-xs font-medium block mb-1">Nome da Subcategoria</label><input value={nome} onChange={e => setNome(e.target.value)} style={inputStyle} /></div>
            <div><label className="text-xs font-medium block mb-1">Grupo no DRE</label>
              <select value={grupo} onChange={e => setGrupo(e.target.value)} style={inputStyle}><option value="">Selecione...</option>{Object.keys(TIPO_MAPEAMENTO).map(k => <option key={k} value={k}>{k}</option>)}</select></div>
            <button onClick={handleAdd} className="text-white font-semibold flex items-center gap-2 justify-center" style={{ height: 38, borderRadius: 14, fontSize: 12.5, padding: '0 24px', background: 'var(--color-button-gradient, var(--color-button, var(--color-primary)))' }}><Plus size={14} /> Adicionar</button>
          </div>
        </div>
      )}

      {subTab === 'edit' && <PlanoEditSubTab empContas={empContas} refetch={refetch} empresaId={empresaAtual.id} />}
      {subTab === 'dup' && <PlanoDuplicarSubTab empresas={empresas} planoContas={planoContas} refetch={refetch} />}

      {subTab === 'add' && <PlanoContasAtivoAccordion grouped={grouped} />}
    </div>
  );
}

function PlanoContasAtivoAccordion({ grouped }: { grouped: Record<string, any[]> }) {
  const [expanded, setExpanded] = useState<Set<string>>(new Set());

  const toggle = (cat: string) => {
    const n = new Set(expanded);
    if (n.has(cat)) n.delete(cat); else n.add(cat);
    setExpanded(n);
  };

  return (
    <div style={CARD}>
      <h3 className="font-semibold mb-3" style={SECTION_TITLE}>Plano de Contas Ativo</h3>
      <div className="space-y-1">
        {CATEGORIAS_DRE.map(cat => {
          const contas = grouped[cat.value] || [];
          if (contas.length === 0) return null;
          const isReceita = CATEGORIAS_RECEITA.includes(cat.value as any);
          const isInvestimento = ['despesas_financeiras', 'distribuicao_lucro'].includes(cat.value);
          const Icon = isReceita ? TrendingUp : isInvestimento ? Briefcase : TrendingDown;
          const color = isReceita ? '#046C4E' : isInvestimento ? '#1A2B6D' : '#C53030';
          const bg = isReceita ? '#F0FDF4' : isInvestimento ? '#EFF6FF' : '#FEF2F2';
          const isOpen = expanded.has(cat.value);
          return (
            <div key={cat.value} style={{ borderRadius: 12, overflow: 'hidden', border: '1px solid #E8EDF5' }}>
              <button
                onClick={() => toggle(cat.value)}
                className="w-full flex items-center justify-between px-4 py-3 text-left transition-colors"
                style={{ background: bg, color }}
              >
                <div className="flex items-center gap-2">
                  <Icon size={14} />
                  <span className="text-xs font-semibold">{cat.label}</span>
                  <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full" style={{
                    background: isReceita ? '#DCFCE7' : '#FEE2E2',
                    color: isReceita ? '#046C4E' : '#C53030',
                  }}>
                    {isReceita ? 'Entrada' : 'Saída'}
                  </span>
                  <span className="text-[10px] opacity-60">({contas.length})</span>
                </div>
                {isOpen ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
              </button>
              {isOpen && (
                <div className="px-4 py-2 space-y-1" style={{ background: '#FAFBFE' }}>
                  {contas.map((c: any) => (
                    <div key={c.id} className="flex items-center gap-2 py-1.5 text-xs" style={{ borderBottom: '1px solid #F1F5F9', color: '#334155' }}>
                      <div className="w-1.5 h-1.5 rounded-full" style={{ background: color, opacity: 0.5 }} />
                      {c.nome_conta}
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function PlanoEditSubTab({ empContas, refetch, empresaId }: { empContas: any[]; refetch: () => void; empresaId: string }) {
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editNome, setEditNome] = useState('');
  const [editGrupo, setEditGrupo] = useState('');

  const grouped = CATEGORIAS_DRE.reduce((acc, cat) => {
    acc[cat.value] = empContas.filter(c => c.categoria_dre === cat.value);
    return acc;
  }, {} as Record<string, any[]>);

  const toggle = (cat: string) => {
    const n = new Set(expanded);
    if (n.has(cat)) n.delete(cat); else n.add(cat);
    setExpanded(n);
  };

  const toggleCatAll = (catValue: string, contas: any[]) => {
    const n = new Set(selected);
    const allSel = contas.every(c => n.has(c.id));
    if (allSel) contas.forEach(c => n.delete(c.id));
    else contas.forEach(c => n.add(c.id));
    setSelected(n);
  };

  const startEdit = (c: any) => {
    setEditingId(c.id);
    setEditNome(c.nome_conta);
    const grupoLabel = Object.entries(TIPO_MAPEAMENTO).find(([, v]) => v === c.categoria_dre)?.[0] || '';
    setEditGrupo(grupoLabel);
  };

  const handleSave = async (conta: any) => {
    if (!editNome) return;
    const catValue = TIPO_MAPEAMENTO[editGrupo] || conta.categoria_dre;
    await supabase.from('plano_contas').update({ nome_conta: editNome, categoria_dre: catValue }).eq('id', conta.id);
    if (conta.nome_conta !== editNome) {
      await supabase.from('orcamentos').update({ conta: editNome }).eq('conta', conta.nome_conta).eq('empresa_id', empresaId);
      await supabase.from('lancamentos_reais').update({ conta: editNome }).eq('conta', conta.nome_conta).eq('empresa_id', empresaId);
    }
    toast.success('Atualizado!');
    setEditingId(null);
    refetch();
  };

  const handleDeleteSelected = async () => {
    if (selected.size === 0) return;
    for (const id of Array.from(selected)) {
      await supabase.from('plano_contas').delete().eq('id', id);
    }
    toast.success(`${selected.size} conta(s) excluída(s)!`);
    setSelected(new Set());
    refetch();
  };

  return (
    <div style={CARD}>
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-semibold" style={SECTION_TITLE}>Editar / Remover Contas</h3>
        <div className="flex items-center gap-3">
          <label className="flex items-center gap-1.5 text-xs font-medium" style={{ color: '#64748B' }}>
            <input type="checkbox" checked={empContas.length > 0 && selected.size === empContas.length} onChange={e => { if (e.target.checked) setSelected(new Set(empContas.map(c => c.id))); else setSelected(new Set()); }} />
            Selecionar todos ({selected.size}/{empContas.length})
          </label>
        </div>
      </div>

      {selected.size > 0 && (
        <div className="flex gap-2 mb-3">
          <button onClick={handleDeleteSelected} className="text-white font-semibold flex items-center gap-1.5 text-xs px-4 py-2 rounded-xl" style={{ backgroundColor: '#C53030' }}>
            <Trash2 size={13} /> Excluir Selecionados ({selected.size})
          </button>
        </div>
      )}

      <div className="space-y-1">
        {CATEGORIAS_DRE.map(cat => {
          const contas = grouped[cat.value] || [];
          if (contas.length === 0) return null;
          const isReceita = CATEGORIAS_RECEITA.includes(cat.value as any);
          const isInvestimento = ['despesas_financeiras', 'distribuicao_lucro'].includes(cat.value);
          const Icon = isReceita ? TrendingUp : isInvestimento ? Briefcase : TrendingDown;
          const color = isReceita ? '#046C4E' : isInvestimento ? '#1A2B6D' : '#C53030';
          const bg = isReceita ? '#F0FDF4' : isInvestimento ? '#EFF6FF' : '#FEF2F2';
          const isOpen = expanded.has(cat.value);
          const allCatSelected = contas.every((c: any) => selected.has(c.id));
          return (
            <div key={cat.value} style={{ borderRadius: 12, overflow: 'hidden', border: '1px solid #E8EDF5' }}>
              <div className="w-full flex items-center justify-between px-4 py-3 transition-colors" style={{ background: bg, color }}>
                <button onClick={() => toggle(cat.value)} className="flex items-center gap-2 flex-1 text-left">
                  <Icon size={14} />
                  <span className="text-xs font-semibold">{cat.label}</span>
                  <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full" style={{ background: isReceita ? '#DCFCE7' : '#FEE2E2', color: isReceita ? '#046C4E' : '#C53030' }}>
                    {isReceita ? 'Entrada' : 'Saída'}
                  </span>
                  <span className="text-[10px] opacity-60">({contas.length})</span>
                </button>
                <div className="flex items-center gap-3">
                  <label className="flex items-center gap-1 text-[10px] font-medium cursor-pointer" style={{ color }} onClick={e => e.stopPropagation()}>
                    <input type="checkbox" checked={allCatSelected} onChange={() => toggleCatAll(cat.value, contas)} />
                    Todos
                  </label>
                  <button onClick={() => toggle(cat.value)}>{isOpen ? <ChevronDown size={14} /> : <ChevronRight size={14} />}</button>
                </div>
              </div>
              {isOpen && (
                <div className="px-4 py-2 space-y-1" style={{ background: '#FAFBFE' }}>
                  {contas.map((c: any) => (
                    <div key={c.id} className="flex items-center gap-2 py-1.5 text-xs" style={{ borderBottom: '1px solid #F1F5F9', color: '#334155' }}>
                      <input type="checkbox" checked={selected.has(c.id)} onChange={e => { const n = new Set(selected); if (e.target.checked) n.add(c.id); else n.delete(c.id); setSelected(n); }} />
                      <div className="w-1.5 h-1.5 rounded-full" style={{ background: color, opacity: 0.5 }} />
                      {editingId === c.id ? (
                        <div className="flex items-center gap-2 flex-1 flex-wrap">
                          <input value={editNome} onChange={e => setEditNome(e.target.value)} style={{ ...INPUT, flex: 1, minWidth: 120 }} />
                          <select value={editGrupo} onChange={e => setEditGrupo(e.target.value)} style={{ ...INPUT, width: 'auto', minWidth: 140 }}>
                            {Object.keys(TIPO_MAPEAMENTO).map(k => <option key={k} value={k}>{k}</option>)}
                          </select>
                          <button onClick={() => handleSave(c)} className="text-white font-semibold flex items-center gap-1 text-[11px] px-3 py-1.5 rounded-lg" style={{ background: 'var(--color-button-gradient, var(--color-button, var(--color-primary)))' }}>
                            <Save size={12} /> Salvar
                          </button>
                          <button onClick={() => setEditingId(null)} className="text-xs px-2 py-1.5 rounded-lg" style={{ color: '#64748B', background: '#F1F5F9' }}>Cancelar</button>
                        </div>
                      ) : (
                        <div className="flex items-center justify-between flex-1">
                          <span>{c.nome_conta}</span>
                          <button onClick={() => startEdit(c)} className="text-[10px] font-medium px-2 py-1 rounded-lg flex items-center gap-1 hover:bg-slate-100 transition-colors" style={{ color: 'var(--color-primary, #6FA9FF)' }}>
                            <Edit size={11} /> Editar
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function PlanoDuplicarSubTab({ empresas, planoContas, refetch }: { empresas: any[]; planoContas: any[]; refetch: () => void }) {
  const [modelo, setModelo] = useState('');
  const [destinos, setDestinos] = useState<Set<string>>(new Set());
  const [selContas, setSelContas] = useState<Set<string>>(new Set());
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const modeloContas = planoContas.filter(p => p.empresa_id === modelo);

  const grouped = CATEGORIAS_DRE.reduce((acc, cat) => {
    acc[cat.value] = modeloContas.filter(c => c.categoria_dre === cat.value);
    return acc;
  }, {} as Record<string, any[]>);

  const toggle = (cat: string) => {
    const n = new Set(expanded);
    if (n.has(cat)) n.delete(cat); else n.add(cat);
    setExpanded(n);
  };

  const toggleCatAll = (catValue: string, contas: any[]) => {
    const n = new Set(selContas);
    const allSelected = contas.every(c => n.has(c.id));
    if (allSelected) contas.forEach(c => n.delete(c.id));
    else contas.forEach(c => n.add(c.id));
    setSelContas(n);
  };

  const handleDuplicar = async () => {
    if (destinos.size === 0 || selContas.size === 0) { toast.error('Selecione contas e destinos'); return; }
    const contas = modeloContas.filter(c => selContas.has(c.id));
    for (const destId of Array.from(destinos)) {
      const existing = planoContas.filter(p => p.empresa_id === destId).map(p => p.nome_conta);
      const toInsert = contas.filter(c => !existing.includes(c.nome_conta)).map(c => ({
        empresa_id: destId, nome_conta: c.nome_conta, categoria_dre: c.categoria_dre, exige_faturamento: c.exige_faturamento,
      }));
      if (toInsert.length > 0) await supabase.from('plano_contas').insert(toInsert);
    }
    toast.success('Duplicado!'); refetch();
  };

  const destEmpresas = empresas.filter((e: any) => e.id !== modelo);

  return (
    <div className="space-y-4">
      <div style={CARD}>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-start">
          <div>
            <label className="text-xs font-medium block mb-1">Empresa Modelo</label>
            <select value={modelo} onChange={e => { setModelo(e.target.value); setSelContas(new Set()); setExpanded(new Set()); }} style={INPUT}>
              <option value="">Selecione...</option>{empresas.map((e: any) => <option key={e.id} value={e.id}>{e.nome}</option>)}</select>
          </div>
          <div>
            <label className="text-xs font-medium block mb-1">Empresas Destino</label>
            <label className="flex items-center gap-1 text-xs font-medium mb-1" style={{ color: '#64748B' }}>
              <input type="checkbox" checked={destEmpresas.length > 0 && destinos.size === destEmpresas.length} onChange={e => { if (e.target.checked) setDestinos(new Set(destEmpresas.map((emp: any) => emp.id))); else setDestinos(new Set()); }} />
              Selecionar todos
            </label>
            <div className="space-y-1 text-xs">
              {destEmpresas.map((e: any) => (
                <label key={e.id} className="flex items-center gap-1"><input type="checkbox" checked={destinos.has(e.id)} onChange={ev => { const n = new Set(destinos); if (ev.target.checked) n.add(e.id); else n.delete(e.id); setDestinos(n); }} />{e.nome}</label>
              ))}
            </div>
          </div>
        </div>
      </div>

      {modelo && (
        <div style={CARD}>
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold" style={SECTION_TITLE}>Plano de Contas — Selecionar para Duplicar</h3>
            <label className="flex items-center gap-1.5 text-xs font-medium" style={{ color: '#64748B' }}>
              <input type="checkbox" checked={modeloContas.length > 0 && selContas.size === modeloContas.length} onChange={e => { if (e.target.checked) setSelContas(new Set(modeloContas.map(c => c.id))); else setSelContas(new Set()); }} />
              Selecionar todos ({selContas.size}/{modeloContas.length})
            </label>
          </div>
          <div className="space-y-1">
            {CATEGORIAS_DRE.map(cat => {
              const contas = grouped[cat.value] || [];
              if (contas.length === 0) return null;
              const isReceita = CATEGORIAS_RECEITA.includes(cat.value as any);
              const isInvestimento = ['despesas_financeiras', 'distribuicao_lucro'].includes(cat.value);
              const Icon = isReceita ? TrendingUp : isInvestimento ? Briefcase : TrendingDown;
              const color = isReceita ? '#046C4E' : isInvestimento ? '#1A2B6D' : '#C53030';
              const bg = isReceita ? '#F0FDF4' : isInvestimento ? '#EFF6FF' : '#FEF2F2';
              const isOpen = expanded.has(cat.value);
              const allCatSelected = contas.every((c: any) => selContas.has(c.id));
              const someCatSelected = contas.some((c: any) => selContas.has(c.id));
              return (
                <div key={cat.value} style={{ borderRadius: 12, overflow: 'hidden', border: '1px solid #E8EDF5' }}>
                  <div className="w-full flex items-center justify-between px-4 py-3 transition-colors" style={{ background: bg, color }}>
                    <button onClick={() => toggle(cat.value)} className="flex items-center gap-2 flex-1 text-left">
                      <Icon size={14} />
                      <span className="text-xs font-semibold">{cat.label}</span>
                      <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full" style={{ background: isReceita ? '#DCFCE7' : '#FEE2E2', color: isReceita ? '#046C4E' : '#C53030' }}>
                        {isReceita ? 'Entrada' : 'Saída'}
                      </span>
                      <span className="text-[10px] opacity-60">({contas.length})</span>
                    </button>
                    <div className="flex items-center gap-3">
                      <label className="flex items-center gap-1 text-[10px] font-medium cursor-pointer" style={{ color }} onClick={e => e.stopPropagation()}>
                        <input type="checkbox" checked={allCatSelected} onChange={() => toggleCatAll(cat.value, contas)} />
                        Todos
                      </label>
                      <button onClick={() => toggle(cat.value)}>{isOpen ? <ChevronDown size={14} /> : <ChevronRight size={14} />}</button>
                    </div>
                  </div>
                  {isOpen && (
                    <div className="px-4 py-2 space-y-1" style={{ background: '#FAFBFE' }}>
                      {contas.map((c: any) => (
                        <label key={c.id} className="flex items-center gap-2 py-1.5 text-xs cursor-pointer" style={{ borderBottom: '1px solid #F1F5F9', color: '#334155' }}>
                          <input type="checkbox" checked={selContas.has(c.id)} onChange={e => { const n = new Set(selContas); if (e.target.checked) n.add(c.id); else n.delete(c.id); setSelContas(n); }} />
                          <div className="w-1.5 h-1.5 rounded-full" style={{ background: color, opacity: 0.5 }} />
                          {c.nome_conta}
                        </label>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
          <div className="mt-4 flex justify-end">
            <button onClick={handleDuplicar} disabled={selContas.size === 0 || destinos.size === 0} className="text-white font-semibold flex items-center gap-2" style={{ height: 38, borderRadius: 14, fontSize: 12.5, padding: '0 24px', background: 'var(--color-button-gradient, var(--color-button, var(--color-primary)))', opacity: selContas.size === 0 || destinos.size === 0 ? 0.5 : 1 }}>
              <Copy size={14} /> Duplicar {selContas.size > 0 ? `(${selContas.size} contas)` : ''}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function BancosTab() {
  const { empresaAtual, refreshEmpresas } = useEmpresa();
  const { bancos, refetch } = useSupabaseData();
  const [nome, setNome] = useState('');
  const [gerente, setGerente] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [agencia, setAgencia] = useState('');
  const [conta, setConta] = useState('');
  const [saldoInicial, setSaldoInicial] = useState('');

  if (!empresaAtual) return null;
  const empBancos = bancos.filter(b => b.empresa_id === empresaAtual.id);

  const handleAdd = async () => {
    if (!nome) { toast.error('Informe o nome'); return; }
    const { error } = await supabase.from('bancos').insert({ empresa_id: empresaAtual.id, nome, gerente, whatsapp, agencia, conta });
    if (error) { toast.error(error.message); return; }
    toast.success('Banco cadastrado!'); setNome(''); setGerente(''); setWhatsapp(''); setAgencia(''); setConta(''); refetch();
  };

  const handleSaveSaldoInicial = async () => {
    const val = parseCurrencyInput(saldoInicial);
    await supabase.from('empresas').update({ saldo_inicial: val }).eq('id', empresaAtual.id);
    toast.success('Saldo inicial salvo!');
    await refreshEmpresas();
  };

  const handleDeleteBanco = async (id: string) => {
    await supabase.from('bancos').delete().eq('id', id);
    toast.success('Excluído!'); refetch();
  };

  const cardStyle = CARD;
  const inputStyle = INPUT;

  return (
    <div className="space-y-4">
      <div style={cardStyle}>
        <h3 className="font-semibold mb-3" style={SECTION_TITLE}>Caixa Inicial</h3>
        <div className="flex flex-col sm:flex-row gap-3 items-end">
          <div className="flex-1 w-full"><label className="text-xs font-medium block mb-1">Saldo Inicial</label>
            <input value={saldoInicial || applyCurrencyMask(String(Math.round(empresaAtual.saldo_inicial * 100)))} onChange={e => setSaldoInicial(applyCurrencyMask(e.target.value))} style={inputStyle} /></div>
          <button onClick={handleSaveSaldoInicial} className="text-white font-semibold flex items-center gap-2" style={{ height: 38, borderRadius: 14, fontSize: 12.5, padding: '0 24px', background: 'var(--color-button-gradient, var(--color-button, var(--color-primary)))' }}><Save size={14} /> Salvar</button>
        </div>
      </div>
      <div style={cardStyle}>
        <h3 className="font-semibold mb-3" style={SECTION_TITLE}>Novo Banco</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          <div><label className="text-xs font-medium block mb-1">Banco</label><input value={nome} onChange={e => setNome(e.target.value)} style={inputStyle} /></div>
          <div><label className="text-xs font-medium block mb-1">Gerente</label><input value={gerente} onChange={e => setGerente(e.target.value)} style={inputStyle} /></div>
          <div><label className="text-xs font-medium block mb-1">WhatsApp</label><input value={whatsapp} onChange={e => setWhatsapp(applyPhoneMask(e.target.value))} style={inputStyle} /></div>
          <div><label className="text-xs font-medium block mb-1">Agência</label><input value={agencia} onChange={e => setAgencia(e.target.value)} style={inputStyle} /></div>
          <div><label className="text-xs font-medium block mb-1">Conta</label><input value={conta} onChange={e => setConta(e.target.value)} style={inputStyle} /></div>
        </div>
        <div className="mt-3 flex justify-end">
          <button onClick={handleAdd} className="text-white font-semibold flex items-center gap-2" style={{ height: 38, borderRadius: 14, fontSize: 12.5, padding: '0 24px', background: 'var(--color-button-gradient, var(--color-button, var(--color-primary)))' }}><Plus size={14} /> Cadastrar</button>
        </div>
      </div>
      <div style={cardStyle}>
        <h3 className="font-semibold mb-3" style={SECTION_TITLE}>Bancos Cadastrados</h3>
        {empBancos.map(b => (
          <details key={b.id} className="mb-2 p-2 border rounded-lg" style={{ borderColor: '#E8EDF5' }}>
            <summary className="cursor-pointer text-sm font-medium flex items-center gap-1.5"><Landmark size={14} className="text-[#94A3B8]" /> {b.nome} — Saldo: {applyCurrencyMask(String(Math.round(Number(b.saldo || 0) * 100)))}</summary>
            <div className="mt-2 text-xs text-[#94A3B8] space-y-1">
              <div>Gerente: {b.gerente} | WhatsApp: {b.whatsapp}</div>
              <div>Agência: {b.agencia} | Conta: {b.conta}</div>
              <button onClick={() => handleDeleteBanco(b.id)} className="text-red-500 text-xs mt-1 flex items-center gap-1"><Trash2 size={12} /> Excluir</button>
            </div>
          </details>
        ))}
      </div>
    </div>
  );
}

function FormasPagamentoTab() {
  const { empresaAtual } = useEmpresa();
  const { formasPagamento, refetch } = useSupabaseData();
  const [nome, setNome] = useState('');

  if (!empresaAtual) return null;
  const empFormas = formasPagamento.filter(f => f.empresa_id === empresaAtual.id);

  const handleAdd = async () => {
    if (!nome) return;
    await supabase.from('formas_pagamento').insert({ empresa_id: empresaAtual.id, nome });
    toast.success('Adicionado!'); setNome(''); refetch();
  };

  const handleDelete = async (id: string) => {
    await supabase.from('formas_pagamento').delete().eq('id', id);
    toast.success('Excluído!'); refetch();
  };

  const cardStyle = CARD;

  return (
    <div style={cardStyle}>
      <div className="flex gap-3 mb-4">
        <input value={nome} onChange={e => setNome(e.target.value)} placeholder="Nova forma de pagamento" className="flex-1" style={{ height: 38, borderRadius: 14, border: '1px solid #E8EDF5', fontSize: 13, padding: '0 8px' }} />
        <button onClick={handleAdd} className="text-white font-semibold flex items-center gap-2" style={{ height: 38, borderRadius: 14, fontSize: 12.5, padding: '0 24px', background: 'var(--color-button-gradient, var(--color-button, var(--color-primary)))' }}><Plus size={14} /> Adicionar</button>
      </div>
      <div className="space-y-2">
        {empFormas.map(f => (
          <div key={f.id} className="flex items-center justify-between p-2 rounded" style={{ border: '1px solid #E8EDF5' }}>
            <span className="text-sm">{f.nome}</span>
            <button onClick={() => handleDelete(f.id)} className="text-red-500"><Trash2 size={14} /></button>
          </div>
        ))}
      </div>
    </div>
  );
}

function CenariosTab() {
  const { empresaAtual, refreshEmpresas } = useEmpresa();
  const [c2, setC2] = useState(String(empresaAtual?.cenario_c2 || 30));
  const [c3, setC3] = useState(String(empresaAtual?.cenario_c3 || 70));

  if (!empresaAtual) return null;

  const handleSave = async () => {
    await supabase.from('empresas').update({ cenario_c2: parseFloat(c2), cenario_c3: parseFloat(c3) }).eq('id', empresaAtual.id);
    toast.success('Cenários salvos!'); refreshEmpresas();
  };

  const cardStyle = CARD;
  const inputStyle: React.CSSProperties = { height: 38, borderRadius: 14, border: '1px solid #E8EDF5', fontSize: 13, padding: '0 8px', width: 120 };

  return (
    <div style={cardStyle}>
      <div className="text-sm text-[#94A3B8] mb-4">Porcentagens aplicadas APENAS nas contas de Receita</div>
      <div className="flex flex-wrap gap-4 items-end">
        <div><label className="text-xs font-medium block mb-1">Cenário 2 (%)</label><input value={c2} onChange={e => setC2(e.target.value)} style={inputStyle} /></div>
        <div><label className="text-xs font-medium block mb-1">Cenário 3 (%)</label><input value={c3} onChange={e => setC3(e.target.value)} style={inputStyle} /></div>
        <button onClick={handleSave} className="text-white font-semibold flex items-center gap-2" style={{ height: 38, borderRadius: 14, fontSize: 12.5, padding: '0 24px', background: 'var(--color-button-gradient, var(--color-button, var(--color-primary)))' }}><Save size={14} /> Salvar</button>
      </div>
    </div>
  );
}
function RegrasPendenciaTab() {
  const { empresaAtual, refreshEmpresas } = useEmpresa();
  const [tipo, setTipo] = useState(empresaAtual?.regras_pendencia_tipo || 'Quantidade');
  const [limite, setLimite] = useState(String(empresaAtual?.regras_pendencia_limite || 5));

  if (!empresaAtual) return null;

  const handleSave = async () => {
    await supabase.from('empresas').update({
      regras_pendencia_tipo: tipo,
      regras_pendencia_limite: parseInt(limite) || 5,
    }).eq('id', empresaAtual.id);
    toast.success('Regras de pendência salvas!');
    refreshEmpresas();
  };

  const cardStyle = CARD;
  const inputStyle: React.CSSProperties = { height: 38, borderRadius: 14, border: '1px solid #E8EDF5', fontSize: 13, padding: '0 8px', width: 120 };

  return (
    <div style={cardStyle}>
      <h3 className="font-semibold mb-2" style={SECTION_TITLE}>Regras de Pendência</h3>
      <p className="text-xs text-[#94A3B8] mb-4">
        Defina como o sistema alerta sobre pendências não conciliadas. Escolha entre monitorar por <strong>dias sem conciliar</strong> ou por <strong>quantidade de pendências</strong> acumuladas.
      </p>

      <div className="flex flex-wrap gap-6 items-end mb-4">
        <div>
          <label className="text-xs font-medium block mb-1">Tipo de Regra</label>
          <select
            value={tipo}
            onChange={e => setTipo(e.target.value)}
            style={{ height: 38, borderRadius: 14, border: '1px solid #E8EDF5', fontSize: 13, padding: '0 8px', minWidth: 180 }}
          >
            <option value="Quantidade">Quantidade de Pendências</option>
            <option value="Dias">Dias sem Conciliar</option>
          </select>
        </div>
        <div>
          <label className="text-xs font-medium block mb-1">
            {tipo === 'Dias' ? 'Limite de Dias' : 'Limite de Pendências'}
          </label>
          <input
            type="number"
            min={1}
            value={limite}
            onChange={e => setLimite(e.target.value)}
            style={inputStyle}
          />
        </div>
        <button onClick={handleSave} className="text-white font-semibold flex items-center gap-2" style={{ height: 38, borderRadius: 14, fontSize: 12.5, padding: '0 24px', background: 'var(--color-button-gradient, var(--color-button, var(--color-primary)))' }}>
          <Save size={14} /> Salvar
        </button>
      </div>

      <div className="p-3 rounded-xl text-xs" style={{ background: '#F0FDF4', border: '1px solid #BBF7D0' }}>
        <strong className="text-[#046C4E]">Como funciona:</strong>
        {tipo === 'Dias' ? (
          <p className="mt-1 text-[#334155]">
            Se houver pendências com mais de <strong>{limite} {parseInt(limite) === 1 ? 'dia' : 'dias'}</strong> sem conciliar, o Dashboard exibirá alerta em <span className="text-red-600 font-semibold">vermelho</span>. Dentro do prazo, ficará em <span className="text-green-600 font-semibold">verde</span>.
          </p>
        ) : (
          <p className="mt-1 text-[#334155]">
            Se a quantidade de pendências ultrapassar <strong>{limite}</strong>, o Dashboard exibirá alerta em <span className="text-red-600 font-semibold">vermelho</span>. Abaixo do limite, ficará em <span className="text-green-600 font-semibold">verde</span>.
          </p>
        )}
      </div>
    </div>
  );
}

function DesignTab() {
  const { empresaAtual, refreshEmpresas } = useEmpresa();
  const [primary, setPrimary] = useState(empresaAtual?.color_primary || '#6FA9FF');
  const [primaryEnd, setPrimaryEnd] = useState(empresaAtual?.color_primary_end || '');
  const [gradientAngle, setGradientAngle] = useState(empresaAtual?.color_gradient_angle || 135);
  const [useGradient, setUseGradient] = useState(!!empresaAtual?.color_primary_end);
  const [bg, setBg] = useState(empresaAtual?.color_bg || '#F4F5F8');
  const [text, setText] = useState(empresaAtual?.color_text || '#334155');
  const [btnColor, setBtnColor] = useState(empresaAtual?.color_button || '');
  const [btnColorEnd, setBtnColorEnd] = useState(empresaAtual?.color_button_end || '');
  const [useBtnGradient, setUseBtnGradient] = useState(!!empresaAtual?.color_button_end);

  if (!empresaAtual) return null;

  const previewBg = useGradient && primaryEnd
    ? `linear-gradient(${gradientAngle}deg, ${primary}, ${primaryEnd})`
    : primary;

  const btnPreview = useBtnGradient && btnColorEnd
    ? `linear-gradient(${gradientAngle}deg, ${btnColor || primary}, ${btnColorEnd})`
    : (btnColor || primary);

  const handleSave = async () => {
    const updates: any = {
      color_primary: primary,
      color_primary_end: useGradient && primaryEnd ? primaryEnd : null,
      color_gradient_angle: gradientAngle,
      color_bg: bg,
      color_text: text,
      color_button: btnColor || null,
      color_button_end: useBtnGradient && btnColorEnd ? btnColorEnd : null,
    };
    await supabase.from('empresas').update(updates).eq('id', empresaAtual.id);
    document.documentElement.style.setProperty('--color-primary', primary);
    document.documentElement.style.setProperty('--color-bg', bg);
    document.documentElement.style.setProperty('--color-text', text);
    const gradientCSS = useGradient && primaryEnd
      ? `linear-gradient(${gradientAngle}deg, ${primary}, ${primaryEnd})`
      : primary;
    document.documentElement.style.setProperty('--color-primary-gradient', gradientCSS);
    const bColor = btnColor || primary;
    document.documentElement.style.setProperty('--color-button', bColor);
    const bGradient = useBtnGradient && btnColorEnd
      ? `linear-gradient(${gradientAngle}deg, ${bColor}, ${btnColorEnd})`
      : bColor;
    document.documentElement.style.setProperty('--color-button-gradient', bGradient);
    toast.success('Design salvo!');
    refreshEmpresas();
  };

  const handleLogo = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      const b64 = (reader.result as string).split(',')[1];
      await supabase.from('empresas').update({ logo_b64: b64 }).eq('id', empresaAtual.id);
      toast.success('Logo salvo!'); refreshEmpresas();
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="space-y-5">
      {/* Preview banner */}
      <div style={{
        borderRadius: 20,
        padding: '20px 28px',
        background: previewBg,
        color: '#fff',
        boxShadow: '0 4px 20px rgba(0,0,0,0.08)',
      }}>
        <div className="font-semibold text-base mb-1">Pré-visualização</div>
        <p className="text-xs opacity-70">Essa é a aparência que seus elementos terão com as cores selecionadas.</p>
        <div className="flex gap-2 mt-3">
          <span className="px-3 py-1.5 rounded-lg text-xs font-semibold" style={{ background: 'rgba(255,255,255,0.2)' }}>Botão</span>
          <span className="px-3 py-1.5 rounded-lg text-xs font-semibold" style={{ background: 'rgba(255,255,255,0.1)', border: '1px solid rgba(255,255,255,0.2)' }}>Outline</span>
        </div>
      </div>

      <div style={CARD}>
        <h4 className="font-semibold text-sm mb-4" style={{ color: '#334155' }}>Cores da Marca</h4>

        {/* Gradient toggle */}
        <div className="flex items-center gap-3 mb-5">
          <label className="text-xs font-medium" style={{ color: '#64748B' }}>Modo:</label>
          <button
            onClick={() => setUseGradient(false)}
            className="text-xs font-semibold px-4 py-2 rounded-xl transition-all"
            style={{
              background: !useGradient ? primary : '#F1F5F9',
              color: !useGradient ? '#fff' : '#64748B',
              boxShadow: !useGradient ? '0 2px 8px rgba(111,169,255,0.25)' : 'none',
            }}
          >
            Cor Sólida
          </button>
          <button
            onClick={() => { setUseGradient(true); if (!primaryEnd) setPrimaryEnd('#7DFFFB'); }}
            className="text-xs font-semibold px-4 py-2 rounded-xl transition-all"
            style={{
              background: useGradient ? `linear-gradient(90deg, ${primary}, ${primaryEnd || '#7DFFFB'})` : '#F1F5F9',
              color: useGradient ? '#fff' : '#64748B',
              boxShadow: useGradient ? '0 2px 8px rgba(111,169,255,0.25)' : 'none',
            }}
          >
            Degradê
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-5">
          <div>
            <label className="text-xs font-medium block mb-1.5" style={{ color: '#94A3B8' }}>Cor Primária</label>
            <div className="flex items-center gap-2">
              <input type="color" value={primary} onChange={e => setPrimary(e.target.value)} className="w-10 h-10 rounded-lg cursor-pointer border-0" />
              <input value={primary} onChange={e => setPrimary(e.target.value)} className="text-xs font-mono flex-1 px-2" style={{ height: 36, borderRadius: 10, border: '1px solid #E8EDF5' }} />
            </div>
          </div>

          {useGradient && (
            <>
              <div>
                <label className="text-xs font-medium block mb-1.5" style={{ color: '#94A3B8' }}>Cor Final (Degradê)</label>
                <div className="flex items-center gap-2">
                  <input type="color" value={primaryEnd} onChange={e => setPrimaryEnd(e.target.value)} className="w-10 h-10 rounded-lg cursor-pointer border-0" />
                  <input value={primaryEnd} onChange={e => setPrimaryEnd(e.target.value)} className="text-xs font-mono flex-1 px-2" style={{ height: 36, borderRadius: 10, border: '1px solid #E8EDF5' }} />
                </div>
              </div>
              <div>
                <label className="text-xs font-medium block mb-1.5" style={{ color: '#94A3B8' }}>Ângulo ({gradientAngle}°)</label>
                <input type="range" min={0} max={360} value={gradientAngle} onChange={e => setGradientAngle(Number(e.target.value))} className="w-full mt-2" />
              </div>
            </>
          )}

          <div>
            <label className="text-xs font-medium block mb-1.5" style={{ color: '#94A3B8' }}>Cor de Fundo</label>
            <div className="flex items-center gap-2">
              <input type="color" value={bg} onChange={e => setBg(e.target.value)} className="w-10 h-10 rounded-lg cursor-pointer border-0" />
              <input value={bg} onChange={e => setBg(e.target.value)} className="text-xs font-mono flex-1 px-2" style={{ height: 36, borderRadius: 10, border: '1px solid #E8EDF5' }} />
            </div>
          </div>

          <div>
            <label className="text-xs font-medium block mb-1.5" style={{ color: '#94A3B8' }}>Cor do Texto</label>
            <div className="flex items-center gap-2">
              <input type="color" value={text} onChange={e => setText(e.target.value)} className="w-10 h-10 rounded-lg cursor-pointer border-0" />
              <input value={text} onChange={e => setText(e.target.value)} className="text-xs font-mono flex-1 px-2" style={{ height: 36, borderRadius: 10, border: '1px solid #E8EDF5' }} />
            </div>
          </div>
        </div>

        {/* Button color section */}
        <h4 className="font-semibold text-sm mb-3 mt-6" style={{ color: '#334155' }}>Cor dos Botões</h4>
        <div className="flex items-center gap-3 mb-4">
          <label className="text-xs font-medium" style={{ color: '#64748B' }}>Modo:</label>
          <button
            onClick={() => { setUseBtnGradient(false); setBtnColorEnd(''); }}
            className="text-xs font-semibold px-4 py-2 rounded-xl transition-all"
            style={{
              background: !useBtnGradient ? (btnColor || primary) : '#F1F5F9',
              color: !useBtnGradient ? '#fff' : '#64748B',
            }}
          >
            Cor Sólida
          </button>
          <button
            onClick={() => { setUseBtnGradient(true); if (!btnColorEnd) setBtnColorEnd('#7DFFFB'); }}
            className="text-xs font-semibold px-4 py-2 rounded-xl transition-all"
            style={{
              background: useBtnGradient ? `linear-gradient(90deg, ${btnColor || primary}, ${btnColorEnd || '#7DFFFB'})` : '#F1F5F9',
              color: useBtnGradient ? '#fff' : '#64748B',
            }}
          >
            Degradê
          </button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-5">
          <div>
            <label className="text-xs font-medium block mb-1.5" style={{ color: '#94A3B8' }}>Cor do Botão</label>
            <div className="flex items-center gap-2">
              <input type="color" value={btnColor || primary} onChange={e => setBtnColor(e.target.value)} className="w-10 h-10 rounded-lg cursor-pointer border-0" />
              <input value={btnColor || primary} onChange={e => setBtnColor(e.target.value)} className="text-xs font-mono flex-1 px-2" style={{ height: 36, borderRadius: 10, border: '1px solid #E8EDF5' }} />
            </div>
          </div>
          {useBtnGradient && (
            <div>
              <label className="text-xs font-medium block mb-1.5" style={{ color: '#94A3B8' }}>Cor Final (Degradê)</label>
              <div className="flex items-center gap-2">
                <input type="color" value={btnColorEnd} onChange={e => setBtnColorEnd(e.target.value)} className="w-10 h-10 rounded-lg cursor-pointer border-0" />
                <input value={btnColorEnd} onChange={e => setBtnColorEnd(e.target.value)} className="text-xs font-mono flex-1 px-2" style={{ height: 36, borderRadius: 10, border: '1px solid #E8EDF5' }} />
              </div>
            </div>
          )}
          <div className="flex items-end">
            <span className="px-5 py-2 rounded-xl text-xs font-semibold text-white" style={{ background: btnPreview }}>Botão Exemplo</span>
          </div>
        </div>

        <h4 className="font-semibold text-sm mb-3 mt-6" style={{ color: '#334155' }}>Logo da Empresa</h4>
        <div className="flex items-center gap-4 mb-5">
          {empresaAtual.logo_b64 && (
            <img src={`data:image/png;base64,${empresaAtual.logo_b64}`} alt="Logo atual" style={{ maxHeight: 40, borderRadius: 8 }} />
          )}
          <label className="cursor-pointer px-4 py-2 text-xs font-semibold rounded-xl" style={{ background: '#F1F5F9', color: '#64748B', border: '1px solid #E8EDF5' }}>
            Escolher arquivo
            <input type="file" accept="image/*" onChange={handleLogo} className="hidden" />
          </label>
        </div>

        <button onClick={handleSave} className="text-white font-semibold flex items-center gap-2 transition-all" style={{
          height: 44,
          borderRadius: 14,
          fontSize: 13,
          padding: '0 28px',
          background: previewBg,
          boxShadow: '0 4px 16px rgba(111,169,255,0.2)',
        }}>
          <Save size={14} /> Salvar Design
        </button>
      </div>
    </div>
  );
}
