import { useState, useMemo } from 'react';
import CurrencyInput from '@/components/CurrencyInput';
import { useEmpresa } from '@/hooks/useEmpresa';
import { useSupabaseData } from '@/hooks/useSupabaseData';
import { supabase } from '@/integrations/supabase/client';
import { formatCurrency, parseCurrencyInput, applyCurrencyMask, formatDate } from '@/lib/formatters';
import { CATEGORIAS_DRE, CATEGORIAS_RECEITA, CATEGORIAS_DESPESA } from '@/lib/constants';
import { CARD, INPUT, BTN_PRIMARY, SECTION_TITLE, LABEL, tabStyle, TAB_CONTAINER } from '@/lib/ui-styles';
import toast from 'react-hot-toast';
import { PenLine, Zap, Save, Trash2, RotateCcw, AlertTriangle, Search, ChevronDown } from 'lucide-react';

export default function RealizadoPage() {
  const { empresaAtual } = useEmpresa();
  const { planoContas, orcamentos, lancamentos, refetch, formasPagamento, loading } = useSupabaseData();
  const [modo, setModo] = useState<'manual' | 'lote'>('manual');
  const [dateStart, setDateStart] = useState(new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().slice(0, 10));
  const [dateEnd, setDateEnd] = useState(new Date().toISOString().slice(0, 10));
  const [showLixeira, setShowLixeira] = useState(false);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [showFilters, setShowFilters] = useState(false);
  const [filtCat, setFiltCat] = useState('');
  const [filtSearch, setFiltSearch] = useState('');

  // Manual form
  const [mData, setMData] = useState(new Date().toISOString().slice(0, 10));
  const [mCat, setMCat] = useState('');
  const [mSubconta, setMSubconta] = useState('');
  const [mValor, setMValor] = useState('');
  const [mFaturado, setMFaturado] = useState('');
  const [mDesc, setMDesc] = useState('');
  const [mForma, setMForma] = useState('');

  // Lote
  const [loteDate, setLoteDate] = useState(new Date().toISOString().slice(0, 10));
  const [loteSel, setLoteSel] = useState<Set<string>>(new Set());
  const [loteValues, setLoteValues] = useState<Record<string, string>>({});

  if (!empresaAtual) return null;

  const isReceita = CATEGORIAS_RECEITA.includes(mCat as any);
  const subcontas = planoContas.filter(pc => pc.categoria_dre === mCat && pc.empresa_id === empresaAtual.id);

  // Auditoria KPIs
  const orcsPeriodo = orcamentos.filter(o => o.empresa_id === empresaAtual.id && o.data_ref >= dateStart && o.data_ref <= dateEnd);
  const lancsPeriodo = lancamentos.filter(l => l.empresa_id === empresaAtual.id && l.data_real >= dateStart && l.data_real <= dateEnd && l.ativo);
  const contaToCat: Record<string, string> = {};
  planoContas.forEach(p => { contaToCat[p.nome_conta] = p.categoria_dre; });

  const saidaProj = orcsPeriodo.filter(o => CATEGORIAS_DESPESA.includes(contaToCat[o.conta])).reduce((s, o) => s + Number(o.p1), 0);
  const saidaReal = lancsPeriodo.filter(l => CATEGORIAS_DESPESA.includes(contaToCat[l.conta])).reduce((s, l) => s + Number(l.valor), 0);
  const entradaProj = orcsPeriodo.filter(o => CATEGORIAS_RECEITA.includes(contaToCat[o.conta])).reduce((s, o) => s + Number(o.p1), 0);
  const entradaReal = lancsPeriodo.filter(l => CATEGORIAS_RECEITA.includes(contaToCat[l.conta])).reduce((s, l) => s + Number(l.valor), 0);

  const handleManualSave = async () => {
    if (!mSubconta || !mData) { toast.error('Preencha os campos obrigatórios'); return; }
    const val = parseCurrencyInput(mValor);
    const { error } = await supabase.from('lancamentos_reais').insert({
      empresa_id: empresaAtual.id, conta: mSubconta, valor: val,
      faturado: isReceita ? parseCurrencyInput(mFaturado) : 0,
      data_real: mData, descricao: mDesc, forma_pagamento: mForma, nao_previsto: true,
    });
    if (error) { toast.error(error.message); return; }
    toast.success('Lançamento salvo!');
    setMValor(''); setMFaturado(''); setMDesc('');
    refetch();
  };

  const loteOrcs = orcamentos.filter(o =>
    o.empresa_id === empresaAtual.id && !o.efetivado &&
    CATEGORIAS_DESPESA.includes(contaToCat[o.conta]) &&
    o.data_ref >= dateStart && o.data_ref <= dateEnd
  );

  const handleLoteConfirm = async () => {
    const ids = Array.from(loteSel);
    if (ids.length === 0) return;
    for (const id of ids) {
      const orc = loteOrcs.find(o => o.id === id);
      if (!orc) continue;
      const realVal = loteValues[id] ? parseCurrencyInput(loteValues[id]) : Number(orc.p1);
      await supabase.from('orcamentos').update({ efetivado: true }).eq('id', id);
      await supabase.from('lancamentos_reais').insert({
        empresa_id: empresaAtual.id, conta: orc.conta, valor: realVal,
        data_real: loteDate, descricao: orc.descricao, orcamento_id: id,
      });
    }
    toast.success(`${ids.length} lançamento(s) efetivado(s)!`);
    setLoteSel(new Set());
    refetch();
  };

  const alertas = useMemo(() => {
    const contaTotais: Record<string, { real: number; proj: number }> = {};
    lancsPeriodo.forEach(l => {
      if (!CATEGORIAS_DESPESA.includes(contaToCat[l.conta])) return;
      if (!contaTotais[l.conta]) contaTotais[l.conta] = { real: 0, proj: 0 };
      contaTotais[l.conta].real += Number(l.valor);
    });
    orcsPeriodo.forEach(o => {
      if (!CATEGORIAS_DESPESA.includes(contaToCat[o.conta])) return;
      if (!contaTotais[o.conta]) contaTotais[o.conta] = { real: 0, proj: 0 };
      contaTotais[o.conta].proj += Number(o.p1);
    });
    return Object.entries(contaTotais)
      .filter(([, v]) => v.proj > 0 && v.real >= v.proj * 0.8)
      .map(([nome, v]) => ({ nome, ...v, pct: (v.real / v.proj) * 100 }))
      .sort((a, b) => b.pct - a.pct);
  }, [lancsPeriodo, orcsPeriodo, contaToCat]);

  let extrato = lancamentos
    .filter(l => l.empresa_id === empresaAtual.id && l.ativo !== showLixeira && l.data_real >= dateStart && l.data_real <= dateEnd)
    .sort((a, b) => b.data_real.localeCompare(a.data_real));
  if (filtCat) extrato = extrato.filter(l => contaToCat[l.conta] === filtCat);
  if (filtSearch) extrato = extrato.filter(l => (l.descricao || '').toLowerCase().includes(filtSearch.toLowerCase()) || l.conta.toLowerCase().includes(filtSearch.toLowerCase()));

  const handleExtratoEdit = async (id: string, field: string, value: any) => {
    const { error } = await supabase.from('lancamentos_reais').update({ [field]: value }).eq('id', id);
    if (error) toast.error(error.message); else refetch();
  };

  const handleMoverLixeira = async () => {
    if (selected.size === 0) return;
    const { error } = await supabase.from('lancamentos_reais').update({ ativo: false }).in('id', Array.from(selected));
    if (error) toast.error(error.message);
    else { toast.success('Movido para lixeira!'); setSelected(new Set()); refetch(); }
  };

  const handleRestaurar = async () => {
    if (selected.size === 0) return;
    for (const id of Array.from(selected)) {
      const lanc = lancamentos.find(l => l.id === id);
      await supabase.from('lancamentos_reais').update({ ativo: true }).eq('id', id);
      if (lanc?.orcamento_id) await supabase.from('orcamentos').update({ efetivado: false }).eq('id', lanc.orcamento_id);
    }
    toast.success('Restaurado!'); setSelected(new Set()); refetch();
  };

  return (
    <div className="space-y-6">
      <h3 className="font-medium text-sm flex items-center gap-2" style={{ color: '#64748B' }}>Resumo do Período</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div style={{ ...CARD, background: '#FAFBFE' }}><div className="text-xs font-medium" style={{ color: '#94A3B8' }}>Saída Projetada</div><div className="font-bold text-lg mt-1" style={{ color: '#334155' }}>{formatCurrency(saidaProj)}</div></div>
        <div style={{ ...CARD, borderColor: '#FEB2B2', background: '#FFF5F5' }}><div className="text-xs font-medium" style={{ color: '#C53030' }}>Saída Realizada</div><div className="font-bold text-lg mt-1" style={{ color: '#C53030' }}>{formatCurrency(saidaReal)}</div></div>
        <div style={{ ...CARD, background: '#F0F9FF' }}><div className="text-xs font-medium" style={{ color: '#94A3B8' }}>Entrada Projetada</div><div className="font-bold text-lg mt-1" style={{ color: '#334155' }}>{formatCurrency(entradaProj)}</div></div>
        <div style={{ ...CARD, borderColor: '#9AE6B4', background: '#F0FDF4' }}><div className="text-xs font-medium" style={{ color: '#046C4E' }}>Entrada Realizada</div><div className="font-bold text-lg mt-1" style={{ color: '#046C4E' }}>{formatCurrency(entradaReal)}</div></div>
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <button onClick={() => setModo('manual')} className="font-semibold text-xs px-4 flex items-center gap-1.5" style={tabStyle(modo === 'manual')}><PenLine size={14} /> Manual</button>
        <button onClick={() => setModo('lote')} className="font-semibold text-xs px-4 flex items-center gap-1.5" style={tabStyle(modo === 'lote')}><Zap size={14} /> Lote</button>
        <div className="flex items-center gap-1 text-xs" style={{ color: '#94A3B8' }}><span>Início</span><input type="date" value={dateStart} onChange={e => setDateStart(e.target.value)} style={{ ...INPUT, width: 'auto' }} /></div>
        <div className="flex items-center gap-1 text-xs" style={{ color: '#94A3B8' }}><span>Fim</span><input type="date" value={dateEnd} onChange={e => setDateEnd(e.target.value)} style={{ ...INPUT, width: 'auto' }} /></div>
      </div>

      {modo === 'manual' ? (
        <div style={CARD}>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div><label className={LABEL} style={{ color: '#94A3B8' }}>Data</label><input type="date" value={mData} onChange={e => setMData(e.target.value)} style={INPUT} /></div>
            <div><label className={LABEL} style={{ color: '#94A3B8' }}>Categoria</label><select value={mCat} onChange={e => { setMCat(e.target.value); setMSubconta(''); }} style={INPUT}><option value="">Selecione...</option>{CATEGORIAS_DRE.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}</select></div>
            <div><label className={LABEL} style={{ color: '#94A3B8' }}>Origem</label><select value={mSubconta} onChange={e => setMSubconta(e.target.value)} style={INPUT}><option value="">Selecione...</option>{subcontas.map(s => <option key={s.id} value={s.nome_conta}>{s.nome_conta}</option>)}</select></div>
            {isReceita && <div><label className={LABEL} style={{ color: '#94A3B8' }}>Faturado</label><input value={mFaturado} onChange={e => setMFaturado(applyCurrencyMask(e.target.value))} placeholder="R$ 0,00" style={INPUT} /><div className="mt-1 text-[10px]" style={{ color: '#94A3B8' }}>Valor total faturado</div></div>}
            <div><label className={LABEL} style={{ color: '#94A3B8' }}>Liquidez</label>
              <input value={mValor} onChange={e => setMValor(applyCurrencyMask(e.target.value))} placeholder="R$ 0,00" style={INPUT} />
              {isReceita && <div className="mt-1 text-[10px]" style={{ color: '#046C4E' }}>Valor que entrou no caixa (DRE)</div>}
              {mValor && <div className="mt-1 font-semibold text-xs" style={{ color: isReceita ? '#046C4E' : '#C53030' }}>{isReceita ? '+' : '-'} {mValor}</div>}
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
            <div><label className={LABEL} style={{ color: '#94A3B8' }}>Observação</label><input value={mDesc} onChange={e => setMDesc(e.target.value)} style={INPUT} /></div>
            <div><label className={LABEL} style={{ color: '#94A3B8' }}>Forma de Pagamento</label><select value={mForma} onChange={e => setMForma(e.target.value)} style={INPUT}><option value="">-</option>{formasPagamento.filter(f => f.empresa_id === empresaAtual.id).map(f => <option key={f.id} value={f.nome}>{f.nome}</option>)}</select></div>
          </div>
          <div className="mt-5 flex justify-end">
            <button onClick={handleManualSave} className="flex items-center gap-2" style={BTN_PRIMARY}><Save size={14} /> Salvar</button>
          </div>
        </div>
      ) : (
        <div style={CARD}>
          <h3 style={SECTION_TITLE} className="mb-4">Efetivação em Lote</h3>
          <div className="flex flex-wrap items-center gap-3 mb-4">
            <label className={LABEL} style={{ color: '#94A3B8', marginBottom: 0 }}>Data Efetivação:</label>
            <input type="date" value={loteDate} onChange={e => setLoteDate(e.target.value)} style={{ ...INPUT, width: 'auto', height: 32, fontSize: 12 }} />
            <label className="flex items-center gap-1 text-xs"><input type="checkbox" onChange={e => { if (e.target.checked) setLoteSel(new Set(loteOrcs.map(o => o.id))); else setLoteSel(new Set()); }} /> Selecionar todos</label>
          </div>
          <div className="overflow-auto">
            <table className="w-full text-xs" style={{ minWidth: 700 }}>
              <thead><tr style={{ background: '#FAFBFE' }}><th className="px-2 py-2.5 text-left" style={{ color: '#94A3B8' }}>Baixar?</th><th className="px-2 py-2.5 text-left" style={{ color: '#94A3B8' }}>Vencimento</th><th className="px-2 py-2.5 text-left" style={{ color: '#94A3B8' }}>Categoria</th><th className="px-2 py-2.5 text-left" style={{ color: '#94A3B8' }}>Origem</th><th className="px-2 py-2.5 text-right" style={{ color: '#94A3B8' }}>Planejado</th><th className="px-2 py-2.5 text-right" style={{ color: '#94A3B8' }}>Realizado</th></tr></thead>
              <tbody>{loteOrcs.map(o => (
                <tr key={o.id} className="border-b" style={{ borderColor: '#E8EDF5' }}>
                  <td className="px-2 py-2"><input type="checkbox" checked={loteSel.has(o.id)} onChange={e => { const n = new Set(loteSel); if (e.target.checked) n.add(o.id); else n.delete(o.id); setLoteSel(n); }} /></td>
                  <td className="px-2 py-2">{formatDate(o.data_ref)}</td><td className="px-2 py-2">{contaToCat[o.conta]}</td><td className="px-2 py-2">{o.conta}</td>
                  <td className="px-2 py-2 text-right">{formatCurrency(Number(o.p1))}</td>
                  <td className="px-2 py-2 text-right"><CurrencyInput style={{ ...INPUT, width: 100, height: 28, fontSize: 11, textAlign: 'right' as const }} defaultValue={Number(o.p1)} onCommit={v => setLoteValues({ ...loteValues, [o.id]: String(v) })} /></td>
                </tr>
              ))}</tbody>
            </table>
          </div>
          <div className="mt-4 flex justify-end">
            <button onClick={handleLoteConfirm} className="flex items-center gap-2" style={BTN_PRIMARY}><Zap size={14} /> Confirmar Efetivação</button>
          </div>
        </div>
      )}

      {/* Alertas */}
      <div style={CARD}>
        <h3 className="font-medium mb-3 flex items-center gap-2" style={{ fontSize: 14, color: '#64748B' }}><AlertTriangle size={16} style={{ color: '#DD6B20' }} /> Alertas de orçamento (Atingiu 80%+)</h3>
        {alertas.length === 0 ? (
          <div className="text-sm italic text-center" style={{ color: '#94A3B8' }}>Nenhuma conta atingiu 80% do orçamento. Tudo em dia!</div>
        ) : (
          <div className="space-y-2">{alertas.map(a => (
            <div key={a.nome} className="flex items-center gap-3">
              <span className="text-xs font-medium flex-1">{a.nome}: {formatCurrency(a.real)}/{formatCurrency(a.proj)} ({a.pct.toFixed(0)}%)</span>
              <div className="w-32 h-2 rounded-full overflow-hidden" style={{ background: '#FAFBFE' }}><div className="h-full rounded-full" style={{ width: `${Math.min(a.pct, 100)}%`, backgroundColor: a.pct >= 100 ? '#C53030' : '#DD6B20' }} /></div>
            </div>
          ))}</div>
        )}
      </div>

      {/* Extrato */}
      <div style={CARD}>
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-4 gap-2">
          <h3 style={SECTION_TITLE}>Extrato de Realizado</h3>
          <div className="flex items-center gap-3 flex-wrap">
            <button onClick={() => setShowFilters(!showFilters)} className="flex items-center gap-1 text-xs" style={{ color: '#94A3B8' }}><ChevronDown size={14} className={showFilters ? 'rotate-180 transition-transform' : 'transition-transform'} /> Filtros</button>
            <label className="flex items-center gap-1 text-xs"><input type="checkbox" checked={showLixeira} onChange={e => setShowLixeira(e.target.checked)} /> <Trash2 size={12} /> Lixeira</label>
            {selected.size > 0 && !showLixeira && <button onClick={handleMoverLixeira} className="text-xs text-white px-3 py-1 flex items-center gap-1" style={{ backgroundColor: '#C53030', borderRadius: 10 }}><Trash2 size={12} /> Mover para Lixeira</button>}
            {selected.size > 0 && showLixeira && <button onClick={handleRestaurar} className="text-xs text-white px-3 py-1 flex items-center gap-1" style={{ backgroundColor: '#046C4E', borderRadius: 10 }}><RotateCcw size={12} /> Restaurar</button>}
          </div>
        </div>
        {showFilters && (
          <div className="flex flex-wrap gap-2 mb-4">
            <select value={filtCat} onChange={e => setFiltCat(e.target.value)} className="text-xs" style={{ ...INPUT, width: 'auto', height: 32, fontSize: 12 }}>
              <option value="">Todas categorias</option>
              {CATEGORIAS_DRE.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
            </select>
            <input value={filtSearch} onChange={e => setFiltSearch(e.target.value)} placeholder="Buscar..." className="text-xs" style={{ ...INPUT, height: 32, fontSize: 12, flex: 1, minWidth: 120 }} />
          </div>
        )}
        {extrato.length === 0 ? (
          <div className="text-sm italic" style={{ color: '#DD6B20' }}>Nenhum dado encontrado.</div>
        ) : (
          <div className="overflow-auto">
            <table className="w-full text-xs" style={{ minWidth: 800 }}>
              <thead><tr style={{ background: '#FAFBFE' }}><th className="px-2 py-2.5" style={{ color: '#94A3B8' }}>Sel.</th><th className="px-2 py-2.5 text-left" style={{ color: '#94A3B8' }}>Data</th><th className="px-2 py-2.5 text-left" style={{ color: '#94A3B8' }}>Categoria</th><th className="px-2 py-2.5 text-left" style={{ color: '#94A3B8' }}>Origem</th><th className="px-2 py-2.5 text-left" style={{ color: '#94A3B8' }}>Observação</th><th className="px-2 py-2.5 text-left" style={{ color: '#94A3B8' }}>Forma Pagamento</th><th className="px-2 py-2.5 text-right" style={{ color: '#94A3B8' }}>Faturado</th><th className="px-2 py-2.5 text-right" style={{ color: '#94A3B8' }}>Liquidez</th></tr></thead>
              <tbody>{extrato.slice(0, 50).map(l => (
                <tr key={l.id} className="border-b" style={{ borderColor: '#E8EDF5' }}>
                  <td className="px-2 py-2 text-center"><input type="checkbox" checked={selected.has(l.id)} onChange={e => { const n = new Set(selected); if (e.target.checked) n.add(l.id); else n.delete(l.id); setSelected(n); }} /></td>
                  <td className="px-2 py-2"><input type="date" value={l.data_real} onChange={e => handleExtratoEdit(l.id, 'data_real', e.target.value)} style={{ ...INPUT, width: 'auto', height: 28, fontSize: 11 }} /></td>
                  <td className="px-2 py-2">{contaToCat[l.conta] || '-'}</td>
                  <td className="px-2 py-2">{l.nao_previsto && <AlertTriangle size={10} className="inline mr-1" style={{ color: '#DD6B20' }} />}{l.conta}</td>
                  <td className="px-2 py-2"><input style={{ ...INPUT, width: 112, height: 28, fontSize: 11 }} defaultValue={l.descricao || ''} onBlur={e => handleExtratoEdit(l.id, 'descricao', e.target.value)} /></td>
                  <td className="px-2 py-2">{l.forma_pagamento || '-'}</td>
                  <td className="px-2 py-2 text-right"><CurrencyInput style={{ ...INPUT, width: 100, height: 28, fontSize: 11, textAlign: 'right' as const }} defaultValue={Number(l.faturado || 0)} onCommit={v => handleExtratoEdit(l.id, 'faturado', v)} /></td>
                  <td className="px-2 py-2 text-right"><CurrencyInput style={{ ...INPUT, width: 100, height: 28, fontSize: 11, textAlign: 'right' as const }} defaultValue={Number(l.valor)} onCommit={v => handleExtratoEdit(l.id, 'valor', v)} /></td>
                </tr>
              ))}</tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
