import { useEffect, useRef } from 'react';

interface WaterfallItem {
  name: string;
  value: number;
  isTotal?: boolean;
}

export default function EChartsWaterfall({ data }: { data: WaterfallItem[] }) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!ref.current || !window.echarts) return;
    const chart = window.echarts.init(ref.current);

    // Build waterfall
    const base: number[] = [];
    const positive: (number | '-')[] = [];
    const negative: (number | '-')[] = [];
    let running = 0;

    data.forEach(d => {
      if (d.isTotal) {
        base.push(0);
        if (d.value >= 0) { positive.push(d.value); negative.push('-'); }
        else { positive.push('-'); negative.push(Math.abs(d.value)); }
      } else {
        if (d.value >= 0) {
          base.push(running);
          positive.push(d.value);
          negative.push('-');
          running += d.value;
        } else {
          running += d.value;
          base.push(running);
          positive.push('-');
          negative.push(Math.abs(d.value));
        }
      }
    });

    chart.setOption({
      tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
      xAxis: { type: 'category', data: data.map(d => d.name), axisLabel: { fontSize: 10, rotate: 30 } },
      yAxis: { type: 'value', axisLabel: { fontSize: 10 } },
      series: [
        { type: 'bar', stack: 'w', data: base, itemStyle: { color: 'transparent' }, emphasis: { itemStyle: { color: 'transparent' } } },
        { type: 'bar', stack: 'w', data: positive, itemStyle: { color: '#38A169' }, label: { show: true, position: 'top', fontSize: 9 } },
        { type: 'bar', stack: 'w', data: negative, itemStyle: { color: '#E53E3E' }, label: { show: true, position: 'bottom', fontSize: 9 } },
      ],
    });
    const ro = new ResizeObserver(() => chart.resize());
    ro.observe(ref.current);
    return () => { chart.dispose(); ro.disconnect(); };
  }, [data]);

  return <div ref={ref} style={{ width: '100%', height: 340 }} />;
}
