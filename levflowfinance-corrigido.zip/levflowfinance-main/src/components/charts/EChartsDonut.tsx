import { useEffect, useRef } from 'react';
import { formatCurrency } from '@/lib/formatters';

declare global { interface Window { echarts: any } }

interface Props {
  data: { name: string; value: number; color: string }[];
}

export default function EChartsDonut({ data }: Props) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!ref.current || !window.echarts) return;
    const chart = window.echarts.init(ref.current);
    const total = data.reduce((s, d) => s + d.value, 0);
    chart.setOption({
      tooltip: { trigger: 'item', formatter: (p: any) => `${p.name}: ${formatCurrency(p.value)} (${p.percent.toFixed(1)}%)` },
      series: [{
        type: 'pie',
        radius: ['40%', '70%'],
        avoidLabelOverlap: true,
        label: {
          show: true,
          fontSize: 11,
          formatter: (p: any) => `${p.name}\n${(total > 0 ? (p.value / total) * 100 : 0).toFixed(1)}%`,
        },
        data: data.map(d => ({ name: d.name, value: d.value, itemStyle: { color: d.color } })),
      }],
    });
    const ro = new ResizeObserver(() => chart.resize());
    ro.observe(ref.current);
    return () => { chart.dispose(); ro.disconnect(); };
  }, [data]);

  return <div ref={ref} style={{ width: '100%', height: 300 }} />;
}
