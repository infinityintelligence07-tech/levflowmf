import { useEffect, useRef } from 'react';
import { formatCurrency } from '@/lib/formatters';

interface FundoCaixaData {
  label: string;
  previsto: number;
  realizado: number | null; // null = future weeks (no actual data)
}

interface Props {
  data: FundoCaixaData[];
  minPrevisto: { label: string; value: number };
  minRealizado: { label: string; value: number };
}

export default function EChartsFundoCaixa({ data, minPrevisto, minRealizado }: Props) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!ref.current || !window.echarts || data.length === 0) return;
    const chart = window.echarts.init(ref.current);

    const labels = data.map(d => d.label);
    const previstoSeries = data.map(d => d.previsto);
    const realizadoSeries = data.map(d => d.realizado);

    chart.setOption({
      tooltip: {
        trigger: 'axis',
        formatter: (params: any) => {
          let html = `<div style="font-weight:600;margin-bottom:4px">${params[0]?.axisValue}</div>`;
          params.forEach((p: any) => {
            if (p.value != null) {
              html += `<div style="display:flex;align-items:center;gap:6px"><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:${p.color}"></span>${p.seriesName}: <b>${formatCurrency(p.value)}</b></div>`;
            }
          });
          return html;
        },
      },
      legend: {
        data: ['Previsto', 'Realizado + Previsto'],
        bottom: 0,
        textStyle: { fontSize: 11, color: '#94A3B8' },
      },
      grid: { left: 10, right: 20, top: 20, bottom: 40, containLabel: true },
      xAxis: {
        type: 'category',
        data: labels,
        axisLabel: { fontSize: 9, color: '#94A3B8', rotate: 45 },
        axisLine: { lineStyle: { color: '#E8EDF5' } },
      },
      yAxis: {
        type: 'value',
        axisLabel: {
          fontSize: 10,
          color: '#94A3B8',
          formatter: (v: number) => {
            if (Math.abs(v) >= 1000) return `${(v / 1000).toFixed(0)}k`;
            return v.toString();
          },
        },
        splitLine: { lineStyle: { color: '#F1F5F9' } },
      },
      series: [
        {
          name: 'Previsto',
          type: 'line',
          data: previstoSeries,
          smooth: true,
          lineStyle: { color: '#6FA9FF', width: 2 },
          itemStyle: { color: '#6FA9FF' },
          areaStyle: {
            color: {
              type: 'linear', x: 0, y: 0, x2: 0, y2: 1,
              colorStops: [
                { offset: 0, color: 'rgba(111,169,255,0.15)' },
                { offset: 1, color: 'rgba(111,169,255,0.01)' },
              ],
            },
          },
          markPoint: {
            data: [
              {
                name: 'Fundo Previsto',
                coord: [minPrevisto.label, minPrevisto.value],
                symbol: 'circle',
                symbolSize: 10,
                itemStyle: { color: '#DD6B20' },
                label: {
                  show: true,
                  formatter: formatCurrency(minPrevisto.value),
                  fontSize: 10,
                  fontWeight: 'bold',
                  color: '#DD6B20',
                  position: 'bottom',
                },
              },
            ],
          },
        },
        {
          name: 'Realizado + Previsto',
          type: 'line',
          data: realizadoSeries,
          smooth: true,
          lineStyle: { color: '#046C4E', width: 2.5 },
          itemStyle: { color: '#046C4E' },
          areaStyle: {
            color: {
              type: 'linear', x: 0, y: 0, x2: 0, y2: 1,
              colorStops: [
                { offset: 0, color: 'rgba(4,108,78,0.12)' },
                { offset: 1, color: 'rgba(4,108,78,0.01)' },
              ],
            },
          },
          markPoint: {
            data: [
              {
                name: 'Fundo Realizado',
                coord: [minRealizado.label, minRealizado.value],
                symbol: 'circle',
                symbolSize: 10,
                itemStyle: { color: '#C53030' },
                label: {
                  show: true,
                  formatter: formatCurrency(minRealizado.value),
                  fontSize: 10,
                  fontWeight: 'bold',
                  color: '#C53030',
                  position: 'bottom',
                },
              },
            ],
          },
        },
      ],
    });

    const ro = new ResizeObserver(() => chart.resize());
    ro.observe(ref.current);
    return () => { chart.dispose(); ro.disconnect(); };
  }, [data, minPrevisto, minRealizado]);

  return <div ref={ref} style={{ width: '100%', height: 360 }} />;
}
