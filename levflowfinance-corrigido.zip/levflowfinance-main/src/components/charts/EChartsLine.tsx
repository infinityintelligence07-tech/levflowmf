import { useEffect, useRef } from 'react';
import { formatCurrency } from '@/lib/formatters';

interface Props {
  data: { date: string; saldo: number }[];
}

export default function EChartsLine({ data }: Props) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!ref.current || !window.echarts || data.length === 0) return;
    const chart = window.echarts.init(ref.current);

    // Show labels only at key points to avoid clutter
    const step = Math.max(1, Math.floor(data.length / 6));

    chart.setOption({
      tooltip: {
        trigger: 'axis',
        formatter: (params: any) => {
          const p = params[0];
          return `${p.axisValue}<br/><b>${formatCurrency(p.value)}</b>`;
        },
      },
      grid: { left: 10, right: 20, top: 30, bottom: 10, containLabel: true },
      xAxis: {
        type: 'category',
        data: data.map(d => { const dt = new Date(d.date); return `${String(dt.getDate()).padStart(2,'0')}/${String(dt.getMonth()+1).padStart(2,'0')}`; }),
        axisLabel: { fontSize: 10 },
      },
      yAxis: {
        type: 'value',
        axisLabel: {
          fontSize: 10,
          formatter: (v: number) => {
            if (Math.abs(v) >= 1000) return `${(v / 1000).toFixed(0)}k`;
            return v.toFixed(0);
          },
        },
      },
      series: [{
        type: 'line',
        data: data.map(d => d.saldo),
        smooth: true,
        lineStyle: { color: '#3182CE', width: 2 },
        itemStyle: { color: '#3182CE' },
        label: {
          show: true,
          formatter: (p: any) => p.dataIndex % step === 0 || p.dataIndex === data.length - 1 ? formatCurrency(p.value) : '',
          fontSize: 9,
          color: '#334155',
          position: 'top',
        },
        areaStyle: {
          color: {
            type: 'linear', x: 0, y: 0, x2: 0, y2: 1,
            colorStops: [
              { offset: 0, color: 'rgba(49,130,206,0.4)' },
              { offset: 1, color: 'rgba(49,130,206,0.02)' },
            ],
          },
        },
        markPoint: {
          data: [
            { type: 'max', name: 'Máximo', label: { formatter: (p: any) => formatCurrency(p.value), fontSize: 10 } },
            { type: 'min', name: 'Mínimo', label: { formatter: (p: any) => formatCurrency(p.value), fontSize: 10 } },
          ],
          symbolSize: 40,
        },
      }],
    });
    const ro = new ResizeObserver(() => chart.resize());
    ro.observe(ref.current);
    return () => { chart.dispose(); ro.disconnect(); };
  }, [data]);

  return <div ref={ref} style={{ width: '100%', height: 340 }} />;
}
