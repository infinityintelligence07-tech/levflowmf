import { useState, useCallback } from 'react';
import { applyCurrencyMask, parseCurrencyInput, formatCurrency } from '@/lib/formatters';

interface CurrencyInputProps {
  defaultValue: number;
  onCommit: (value: number) => void;
  style?: React.CSSProperties;
}

export default function CurrencyInput({ defaultValue, onCommit, style }: CurrencyInputProps) {
  const [display, setDisplay] = useState(() => formatCurrency(defaultValue));

  const handleChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    setDisplay(applyCurrencyMask(e.target.value));
  }, []);

  const handleBlur = useCallback(() => {
    const num = parseCurrencyInput(display);
    setDisplay(formatCurrency(num));
    onCommit(num);
  }, [display, onCommit]);

  return (
    <input
      value={display}
      onChange={handleChange}
      onBlur={handleBlur}
      style={style}
    />
  );
}
