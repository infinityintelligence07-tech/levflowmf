import { formatCurrency } from '@/lib/formatters';
import type { DREWithDetails } from '@/lib/dre-engine';
import { TrendingUp, TrendingDown, ArrowUpRight, ArrowDownRight, Scale } from 'lucide-react';

interface PeriodData {
  label: string;
  dre: DREWithDetails;
}

interface Props {
  periods: PeriodData[];
}

function sumEntradas(dre: DREWithDetails): { prev: number; real: number } {
  return {
    prev: dre.receita_bruta.p1 + dre.outras_receitas.p1,
    real: dre.receita_bruta.real + dre.outras_receitas.real,
  };
}

function sumSaidas(dre: DREWithDetails): { prev: number; real: number } {
  return {
    prev: Math.abs(dre.deducoes.p1) + Math.abs(dre.custos_variaveis.p1) + Math.abs(dre.despesas_operacionais.p1) + Math.abs(dre.despesas_financeiras.p1) + Math.abs(dre.distribuicao_lucro.p1),
    real: Math.abs(dre.deducoes.real) + Math.abs(dre.custos_variaveis.real) + Math.abs(dre.despesas_operacionais.real) + Math.abs(dre.despesas_financeiras.real) + Math.abs(dre.distribuicao_lucro.real),
  };
}

export default function DRESummaryCards({ periods }: Props) {
  // Totals across all periods
  let totalEntPrev = 0, totalEntReal = 0, totalSaiPrev = 0, totalSaiReal = 0;
  periods.forEach(p => {
    const e = sumEntradas(p.dre);
    const s = sumSaidas(p.dre);
    totalEntPrev += e.prev;
    totalEntReal += e.real;
    totalSaiPrev += s.prev;
    totalSaiReal += s.real;
  });
  const saldoPrev = totalEntPrev - totalSaiPrev;
  const saldoReal = totalEntReal - totalSaiReal;

  return (
    <div className="mt-6 space-y-5">
      {/* Per-period cards */}
      <div className="grid gap-4" style={{ gridTemplateColumns: `repeat(${Math.min(periods.length, 6)}, 1fr)` }}>
        {periods.map((period) => {
          const ent = sumEntradas(period.dre);
          const sai = sumSaidas(period.dre);
          const diffEnt = ent.real - ent.prev;
          const diffSai = sai.real - sai.prev;

          return (
            <div key={period.label} style={{ borderRadius: 20, overflow: 'hidden', border: '1px solid var(--color-card-border, #E8EDF5)', boxShadow: '0 2px 12px var(--color-card-shadow, rgba(26,43,109,0.06))' }}>
              {/* Header */}
              <div style={{ background: 'var(--color-primary-gradient, var(--color-primary, #1A2B6D))', padding: '12px 16px' }}>
                <span className="text-xs font-bold tracking-wide uppercase" style={{ color: '#fff' }}>{period.label}</span>
              </div>

              {/* Entradas */}
              <div style={{ padding: '14px 16px 10px', background: '#fff', borderBottom: '1px solid var(--color-card-border, #EDF1F7)' }}>
                <div className="flex items-center gap-1.5 mb-2.5">
                  <div className="flex items-center justify-center" style={{ width: 22, height: 22, borderRadius: 6, background: '#ECFDF5' }}>
                    <TrendingUp size={12} style={{ color: '#046C4E' }} />
                  </div>
                  <span className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: 'var(--color-muted, #64748B)' }}>Entradas</span>
                </div>
                <div className="space-y-1.5">
                  <Row label="Previsto" value={ent.prev} />
                  <Row label="Realizado" value={ent.real} bold />
                  <DiffRow value={diffEnt} positiveIsGood />
                </div>
              </div>

              {/* Saídas */}
              <div style={{ padding: '14px 16px', background: 'var(--color-surface, #FAFBFE)' }}>
                <div className="flex items-center gap-1.5 mb-2.5">
                  <div className="flex items-center justify-center" style={{ width: 22, height: 22, borderRadius: 6, background: '#FEF2F2' }}>
                    <TrendingDown size={12} style={{ color: '#C53030' }} />
                  </div>
                  <span className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: 'var(--color-muted, #64748B)' }}>Saídas</span>
                </div>
                <div className="space-y-1.5">
                  <Row label="Previsto" value={sai.prev} />
                  <Row label="Realizado" value={sai.real} bold />
                  <DiffRow value={diffSai} positiveIsGood={false} />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Consolidated totals */}
      <div
        className="grid gap-4"
        style={{ gridTemplateColumns: 'repeat(3, 1fr)' }}
      >
        {/* Previsto */}
        <TotalCard
          title="Previsto"
          icon={<Scale size={14} style={{ color: '#fff' }} />}
          rows={[
            { label: 'Entradas', value: totalEntPrev, color: '#046C4E' },
            { label: 'Saídas', value: totalSaiPrev, color: '#C53030' },
            { label: 'Saldo', value: saldoPrev, highlight: true },
          ]}
        />
        {/* Realizado */}
        <TotalCard
          title="Realizado"
          icon={<TrendingUp size={14} style={{ color: '#fff' }} />}
          rows={[
            { label: 'Entradas', value: totalEntReal, color: '#046C4E' },
            { label: 'Saídas', value: totalSaiReal, color: '#C53030' },
            { label: 'Saldo', value: saldoReal, highlight: true },
          ]}
        />
        {/* Diferença */}
        <TotalCard
          title="Diferença"
          icon={<ArrowUpRight size={14} style={{ color: '#fff' }} />}
          rows={[
            { label: 'Entradas', value: totalEntReal - totalEntPrev, dynamic: true, positiveIsGood: true },
            { label: 'Saídas', value: totalSaiReal - totalSaiPrev, dynamic: true, positiveIsGood: false },
            { label: 'Saldo', value: saldoReal - saldoPrev, dynamic: true, positiveIsGood: true, highlight: true },
          ]}
        />
      </div>
    </div>
  );
}

/* ── Small helper components ── */

function Row({ label, value, bold }: { label: string; value: number; bold?: boolean }) {
  return (
    <div className="flex justify-between items-center">
      <span className="text-[10px]" style={{ color: 'var(--color-muted, #94A3B8)' }}>{label}</span>
      <span className={`text-xs ${bold ? 'font-bold' : 'font-semibold'}`} style={{ color: bold ? 'var(--color-primary, #1A2B6D)' : 'var(--color-text, #334155)' }}>
        {formatCurrency(value)}
      </span>
    </div>
  );
}

function DiffRow({ value, positiveIsGood }: { value: number; positiveIsGood: boolean }) {
  const isGood = positiveIsGood ? value > 0 : value < 0;
  const isBad = positiveIsGood ? value < 0 : value > 0;
  const color = value === 0 ? 'var(--color-muted, #94A3B8)' : isGood ? '#046C4E' : '#C53030';
  return (
    <div className="flex justify-between items-center" style={{ paddingTop: 4, borderTop: '1px dashed var(--color-card-border, #E8EDF5)' }}>
      <span className="text-[10px] font-medium" style={{ color: 'var(--color-muted, #94A3B8)' }}>Diferença</span>
      <div className="flex items-center gap-1">
        {value !== 0 && (isGood
          ? <ArrowUpRight size={10} style={{ color: '#046C4E' }} />
          : <ArrowDownRight size={10} style={{ color: '#C53030' }} />
        )}
        <span className="text-xs font-bold" style={{ color }}>{formatCurrency(value)}</span>
      </div>
    </div>
  );
}

interface TotalRow {
  label: string;
  value: number;
  color?: string;
  highlight?: boolean;
  dynamic?: boolean;
  positiveIsGood?: boolean;
}

function TotalCard({ title, icon, rows }: { title: string; icon: React.ReactNode; rows: TotalRow[] }) {
  return (
    <div style={{
      borderRadius: 20,
      overflow: 'hidden',
      border: '1px solid var(--color-card-border, #E8EDF5)',
      boxShadow: '0 2px 12px var(--color-card-shadow, rgba(26,43,109,0.06))',
    }}>
      <div className="flex items-center gap-2" style={{ background: 'var(--color-primary-gradient, var(--color-primary, #1A2B6D))', padding: '10px 16px' }}>
        <div className="flex items-center justify-center" style={{ width: 24, height: 24, borderRadius: 8, background: 'rgba(255,255,255,0.15)' }}>
          {icon}
        </div>
        <span className="text-xs font-bold tracking-wide uppercase" style={{ color: '#fff' }}>{title}</span>
      </div>
      <div style={{ padding: '16px 20px', background: '#fff' }}>
        <div className="space-y-3">
          {rows.map(r => {
            let valueColor = r.color || 'var(--color-text, #334155)';
            if (r.dynamic) {
              valueColor = r.value === 0
                ? 'var(--color-muted, #94A3B8)'
                : (r.positiveIsGood ? r.value > 0 : r.value < 0) ? '#046C4E' : '#C53030';
            }
            if (r.highlight && !r.dynamic) {
              valueColor = r.value >= 0 ? '#046C4E' : '#C53030';
            }
            return (
              <div
                key={r.label}
                className="flex justify-between items-center"
                style={r.highlight ? { paddingTop: 8, borderTop: '1px solid var(--color-card-border, #E8EDF5)' } : undefined}
              >
                <span className="text-[11px] font-medium" style={{ color: 'var(--color-muted, #64748B)' }}>{r.label}</span>
                <span className={`text-sm ${r.highlight ? 'font-extrabold' : 'font-semibold'}`} style={{ color: valueColor }}>
                  {formatCurrency(r.value)}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
