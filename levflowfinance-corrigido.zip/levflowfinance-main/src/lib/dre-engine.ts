/**
 * dre-engine.ts
 * 100% fiel ao oficial.py — mesmas 9 categorias, mesma hierarquia,
 * mesma lógica de Ação CFO, mesmas pendências, mesmos cálculos.
 */

import { CATEGORIAS_RECEITA, CATEGORIAS_DESPESA } from './constants';

// ─── Tipos ────────────────────────────────────────────────────────────────────

export interface DREValues {
  p1: number;
  p2: number;
  p3: number;
  real: number;
}

/** Espelho exato das 14 linhas do Python calcular_dre() */
export interface DREResult {
  receita_bruta:         DREValues;
  deducoes:              DREValues;
  receita_liquida:       DREValues;
  custos_variaveis:      DREValues;
  margem_contribuicao:   DREValues;
  despesas_operacionais: DREValues;
  ebitda:                DREValues;
  outras_receitas:       DREValues;
  outras_despesas:       DREValues;
  investimentos:         DREValues;
  emprestimos:           DREValues;
  resultado_bruto:       DREValues;
  distribuicao_lucro:    DREValues;
  resultado_liquido:     DREValues;
}

export interface ContaDetail {
  nome: string;
  p1: number; p2: number; p3: number; real: number;
}

export interface DREWithDetails extends DREResult {
  details: Record<string, ContaDetail[]>;
  [key: string]: DREValues | Record<string, ContaDetail[]>;
}

export interface AggregatedData {
  byCategoria: Record<string, DREValues>;
  byConta: Record<string, { categoria: string; p1: number; p2: number; p3: number; real: number }>;
  faturadoByCategoria?: Record<string, DREValues>;
  faturadoByConta?: Record<string, { p1: number; p2: number; p3: number; real: number }>;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function zero(): DREValues { return { p1: 0, p2: 0, p3: 0, real: 0 }; }

function sub(a: DREValues, b: DREValues): DREValues {
  return { p1: a.p1 - b.p1, p2: a.p2 - b.p2, p3: a.p3 - b.p3, real: a.real - b.real };
}

function add4(a: DREValues, b: DREValues): DREValues {
  return { p1: a.p1 + b.p1, p2: a.p2 + b.p2, p3: a.p3 + b.p3, real: a.real + b.real };
}

// ─── calcular_dre — fiel ao Python ────────────────────────────────────────────

/**
 * Recebe o dict consolidado (byCategoria) e produz o DRE completo.
 * Fórmulas idênticas ao Python:
 *   resultado_bruto = ebitda + outras_receitas - outras_despesas - investimentos - emprestimos
 *   resultado_liquido = resultado_bruto - distribuicao_lucro
 */
export function calcularDRE(data: AggregatedData): DREWithDetails {
  const get = (cat: string): DREValues => data.byCategoria[cat] || zero();

  const receita_bruta         = get('receita');
  const deducoes              = get('deducao');
  const receita_liquida       = sub(receita_bruta, deducoes);
  const custos_variaveis      = get('custo_variavel');
  const margem_contribuicao   = sub(receita_liquida, custos_variaveis);
  const despesas_operacionais = get('despesa_operacional');
  const ebitda                = sub(margem_contribuicao, despesas_operacionais);
  const outras_receitas       = get('outras_receitas');
  const outras_despesas       = get('outras_despesas');
  const investimentos         = get('investimento');
  const emprestimos           = get('emprestimo');

  // Python: resultado_bruto = ebitda + outras_receitas - outras_despesas - investimentos - emprestimos
  const resultado_bruto: DREValues = {
    p1:   ebitda.p1   + outras_receitas.p1   - outras_despesas.p1   - investimentos.p1   - emprestimos.p1,
    p2:   ebitda.p2   + outras_receitas.p2   - outras_despesas.p2   - investimentos.p2   - emprestimos.p2,
    p3:   ebitda.p3   + outras_receitas.p3   - outras_despesas.p3   - investimentos.p3   - emprestimos.p3,
    real: ebitda.real + outras_receitas.real - outras_despesas.real - investimentos.real - emprestimos.real,
  };

  const distribuicao_lucro = get('distribuicao_lucro');
  const resultado_liquido  = sub(resultado_bruto, distribuicao_lucro);

  // Detalhes por conta para expandir nas tabelas
  const details: Record<string, ContaDetail[]> = {};
  for (const [contaNome, contaData] of Object.entries(data.byConta)) {
    const cat = contaData.categoria;
    if (!details[cat]) details[cat] = [];
    details[cat].push({ nome: contaNome, p1: contaData.p1, p2: contaData.p2, p3: contaData.p3, real: contaData.real });
  }

  // Faturado como referência informativa (não entra no DRE)
  if (data.faturadoByConta) {
    details['receita_faturado'] = [];
    for (const [contaNome, contaData] of Object.entries(data.faturadoByConta)) {
      details['receita_faturado'].push({ nome: contaNome + ' (Faturado)', ...contaData });
    }
  }

  return {
    receita_bruta, deducoes, receita_liquida,
    custos_variaveis, margem_contribuicao,
    despesas_operacionais, ebitda,
    outras_receitas, outras_despesas, investimentos, emprestimos,
    resultado_bruto, distribuicao_lucro, resultado_liquido,
    details,
  };
}

// ─── applyScenarios — fiel ao Python ──────────────────────────────────────────

/**
 * Python: P2 e P3 são salvos nos orçamentos com o multiplicador já aplicado.
 * Aqui replicamos: só receita_bruta escala, despesas mantêm P1.
 * Os subtotais são recalculados em cascata.
 */
export function applyScenarios(dre: DREWithDetails, pctC2: number, pctC3: number): DREWithDetails {
  const multC2 = 1 + pctC2 / 100;
  const multC3 = 1 + pctC3 / 100;

  const rb = dre.receita_bruta;
  const receita_bruta: DREValues = { p1: rb.p1, p2: rb.p1 * multC2, p3: rb.p1 * multC3, real: rb.real };

  // Despesas mantêm P1 em P2 e P3 (fiel ao Python)
  const fix = (v: DREValues): DREValues => ({ p1: v.p1, p2: v.p1, p3: v.p1, real: v.real });

  const deducoes              = fix(dre.deducoes);
  const receita_liquida       = sub(receita_bruta, deducoes);
  const custos_variaveis      = fix(dre.custos_variaveis);
  const margem_contribuicao   = sub(receita_liquida, custos_variaveis);
  const despesas_operacionais = fix(dre.despesas_operacionais);
  const ebitda                = sub(margem_contribuicao, despesas_operacionais);
  const outras_receitas       = fix(dre.outras_receitas);
  const outras_despesas       = fix(dre.outras_despesas);
  const investimentos         = fix(dre.investimentos);
  const emprestimos           = fix(dre.emprestimos);

  const resultado_bruto: DREValues = {
    p1:   ebitda.p1   + outras_receitas.p1   - outras_despesas.p1   - investimentos.p1   - emprestimos.p1,
    p2:   ebitda.p2   + outras_receitas.p2   - outras_despesas.p2   - investimentos.p2   - emprestimos.p2,
    p3:   ebitda.p3   + outras_receitas.p3   - outras_despesas.p3   - investimentos.p3   - emprestimos.p3,
    real: ebitda.real + outras_receitas.real - outras_despesas.real - investimentos.real - emprestimos.real,
  };

  const distribuicao_lucro = fix(dre.distribuicao_lucro);
  const resultado_liquido  = sub(resultado_bruto, distribuicao_lucro);

  return {
    receita_bruta, deducoes, receita_liquida,
    custos_variaveis, margem_contribuicao,
    despesas_operacionais, ebitda,
    outras_receitas, outras_despesas, investimentos, emprestimos,
    resultado_bruto, distribuicao_lucro, resultado_liquido,
    details: dre.details,
  };
}

// ─── aggregateData — fiel ao Python consolidar_dados_periodo ──────────────────

/**
 * Equivalente ao Python consolidar_dados_periodo().
 *
 * AÇÃO CFO: aplica multiplicador em TODAS as categorias (não só receita),
 * usando a estrutura { entradas: { cat: { conta: {pct, data} } }, saidas: {...} }
 * exatamente como o Python.
 *
 * PENDÊNCIAS sem conta: entrada → "📥 Entradas Pendentes" (receita)
 *                        saída  → "📤 Saídas Pendentes"  (despesa_operacional)
 * Fiel ao Python — NÃO vai para outras_receitas/despesas_financeiras.
 */
export function aggregateData(
  orcamentos:    any[],
  lancamentos:   any[],
  pendencias:    any[],
  planoContas:   any[],
  acaoCfo:       any[],
  empresa:       any | null,
  dateStart:     string,
  dateEnd:       string,
  aplicarCfo:    boolean = true,
): AggregatedData {
  const contaToCategoria: Record<string, string> = {};
  planoContas.forEach(pc => { contaToCategoria[pc.nome_conta] = pc.categoria_dre; });

  const byCategoria:       Record<string, DREValues> = {};
  const byConta:           Record<string, { categoria: string; p1: number; p2: number; p3: number; real: number }> = {};
  const faturadoByCategoria: Record<string, DREValues> = {};
  const faturadoByConta:   Record<string, { p1: number; p2: number; p3: number; real: number }> = {};

  // Adiciona conta pendente virtual se não existir
  const ensurePendente = (label: string, cat: string) => {
    if (!byConta[label]) byConta[label] = { categoria: cat, p1: 0, p2: 0, p3: 0, real: 0 };
  };

  const addToConta = (
    conta: string, cat: string,
    vals: { p1?: number; p2?: number; p3?: number; real?: number },
  ) => {
    if (!byConta[conta]) byConta[conta] = { categoria: cat, p1: 0, p2: 0, p3: 0, real: 0 };
    byConta[conta].p1   += vals.p1   || 0;
    byConta[conta].p2   += vals.p2   || 0;
    byConta[conta].p3   += vals.p3   || 0;
    byConta[conta].real += vals.real || 0;
  };

  const addToFaturado = (
    conta: string, cat: string,
    vals: { p1?: number; p2?: number; p3?: number; real?: number },
  ) => {
    if (!faturadoByCategoria[cat]) faturadoByCategoria[cat] = zero();
    faturadoByCategoria[cat].p1   += vals.p1   || 0;
    faturadoByCategoria[cat].p2   += vals.p2   || 0;
    faturadoByCategoria[cat].p3   += vals.p3   || 0;
    faturadoByCategoria[cat].real += vals.real || 0;

    if (!faturadoByConta[conta]) faturadoByConta[conta] = { p1: 0, p2: 0, p3: 0, real: 0 };
    faturadoByConta[conta].p1   += vals.p1   || 0;
    faturadoByConta[conta].p2   += vals.p2   || 0;
    faturadoByConta[conta].p3   += vals.p3   || 0;
    faturadoByConta[conta].real += vals.real || 0;
  };

  /**
   * get_multiplicador — fiel ao Python.
   * acaoCfo é o array da tabela acao_cfo do Supabase.
   * Estrutura de cada registro: { categoria, conta_nome, pct, data_inicio, tipo_macro }
   */
  const getMultiplicador = (cat: string, conta: string, dataRef: string): number => {
    if (!aplicarCfo || !empresa || acaoCfo.length === 0) return 1.0;

    // Python usa estrutura aninhada entradas/saidas > categoria > conta
    // No Supabase os registros estão flat — filtramos igual ao Python
    const tipoMacro = (CATEGORIAS_RECEITA as readonly string[]).includes(cat) ? 'entradas' : 'saidas';

    const rules = acaoCfo.filter(r =>
      r.tipo_macro === tipoMacro &&
      r.categoria  === cat &&
      (r.conta_nome === 'todas' || r.conta_nome === conta) &&
      r.data_inicio <= dataRef,
    );

    if (rules.length === 0) return 1.0;
    // Python pega a última regra encontrada
    const rule = rules[rules.length - 1];
    return 1 + (Number(rule.pct) / 100);
  };

  // ── Orçamentos ──────────────────────────────────────────────────────────────
  orcamentos.forEach(orc => {
    if (orc.data_ref < dateStart || orc.data_ref > dateEnd) return;
    const cat = contaToCategoria[orc.conta];
    if (!cat) return;

    const mult = getMultiplicador(cat, orc.conta, orc.data_ref);
    const p1 = Number(orc.p1 || 0) * mult;
    const p2 = Number(orc.p2 || 0) * mult;
    const p3 = Number(orc.p3 || 0) * mult;

    addToConta(orc.conta, cat, { p1, p2, p3 });

    // Faturado — só receita, apenas referência
    const fat = Number(orc.faturado || 0) * mult;
    if ((CATEGORIAS_RECEITA as readonly string[]).includes(cat) && fat > 0) {
      addToFaturado(orc.conta, cat, { p1: fat, p2: fat, p3: fat });
    }
  });

  // ── Lançamentos reais ────────────────────────────────────────────────────────
  lancamentos.forEach(lr => {
    if (!lr.ativo) return;
    if (lr.data_real < dateStart || lr.data_real > dateEnd) return;
    const cat = contaToCategoria[lr.conta];
    if (!cat) return;

    addToConta(lr.conta, cat, { real: Number(lr.valor || 0) });

    const fat = Number(lr.faturado || 0);
    if ((CATEGORIAS_RECEITA as readonly string[]).includes(cat) && fat > 0) {
      addToFaturado(lr.conta, cat, { real: fat });
    }
  });

  // ── Pendências — fiel ao Python ──────────────────────────────────────────────
  // Com conta → soma no real daquela conta
  // Sem conta → "📥 Entradas Pendentes" (receita) ou "📤 Saídas Pendentes" (despesa_operacional)
  ensurePendente('📥 Entradas Pendentes', 'receita');
  ensurePendente('📤 Saídas Pendentes',   'despesa_operacional');

  pendencias.forEach(p => {
    if (p.data < dateStart || p.data > dateEnd) return;
    const valor = Number(p.valor || 0);

    if (p.conta && contaToCategoria[p.conta]) {
      const cat = contaToCategoria[p.conta];
      addToConta(p.conta, cat, { real: valor });
    } else {
      // Fiel ao Python: entrada → receita, saída → despesa_operacional
      if (p.tipo === 'entrada') {
        addToConta('📥 Entradas Pendentes', 'receita', { real: valor });
      } else if (p.tipo === 'saida') {
        addToConta('📤 Saídas Pendentes', 'despesa_operacional', { real: valor });
      }
    }
  });

  // ── Reconstruir byCategoria a partir de byConta ──────────────────────────────
  for (const contaData of Object.values(byConta)) {
    const cat = contaData.categoria;
    if (!byCategoria[cat]) byCategoria[cat] = zero();
    byCategoria[cat].p1   += contaData.p1;
    byCategoria[cat].p2   += contaData.p2;
    byCategoria[cat].p3   += contaData.p3;
    byCategoria[cat].real += contaData.real;
  }

  return { byCategoria, byConta, faturadoByCategoria, faturadoByConta };
}

// ─── calcularResultadoAllTime — fiel ao Python ────────────────────────────────

/**
 * Python usa exatamente estas categorias como despesa:
 * deducao, custo_variavel, despesa_operacional, outras_despesas,
 * investimento, emprestimo, distribuicao_lucro
 */
export function calcularResultadoAllTime(
  lancamentos: any[],
  pendencias:  any[],
  planoContas: any[],
  saldoInicial: number,
): number {
  const contaToCategoria: Record<string, string> = {};
  planoContas.forEach(pc => { contaToCategoria[pc.nome_conta] = pc.categoria_dre; });

  let total = saldoInicial;

  lancamentos.forEach(lr => {
    if (!lr.ativo) return;
    const cat = contaToCategoria[lr.conta];
    if (!cat) return;
    const val = Number(lr.valor || 0);
    if ((CATEGORIAS_RECEITA as readonly string[]).includes(cat)) total += val;
    else if ((CATEGORIAS_DESPESA as readonly string[]).includes(cat)) total -= val;
  });

  pendencias.forEach(p => {
    const val = Number(p.valor || 0);
    if (p.tipo === 'entrada') total += val;
    else if (p.tipo === 'saida') total -= val;
  });

  return total;
}

// ─── calcularSaldoHistoricoAte — fiel ao Python ───────────────────────────────

export function calcularSaldoHistoricoAte(
  lancamentos:  any[],
  pendencias:   any[],
  planoContas:  any[],
  saldoInicial: number,
  dataLimite:   string,
): number {
  const contaToCategoria: Record<string, string> = {};
  planoContas.forEach(pc => { contaToCategoria[pc.nome_conta] = pc.categoria_dre; });

  let total = saldoInicial;

  lancamentos.forEach(lr => {
    if (!lr.ativo || lr.data_real >= dataLimite) return;
    const cat = contaToCategoria[lr.conta];
    if (!cat) return;
    const val = Number(lr.valor || 0);
    if ((CATEGORIAS_RECEITA as readonly string[]).includes(cat)) total += val;
    else if ((CATEGORIAS_DESPESA as readonly string[]).includes(cat)) total -= val;
  });

  pendencias.forEach(p => {
    if (p.data >= dataLimite) return;
    const val = Number(p.valor || 0);
    if (p.tipo === 'entrada') total += val;
    else if (p.tipo === 'saida') total -= val;
  });

  return total;
}
