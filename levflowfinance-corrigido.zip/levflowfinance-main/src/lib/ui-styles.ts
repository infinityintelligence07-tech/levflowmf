/** Shared UI style tokens — single source of truth for all pages */

export const CARD: React.CSSProperties = {
  background: '#fff',
  border: '1px solid #E8EDF5',
  borderRadius: 24,
  boxShadow: '0 1px 4px rgba(111,169,255,0.04)',
  padding: 28,
};

export const INPUT: React.CSSProperties = {
  height: 38,
  borderRadius: 12,
  border: '1px solid #E8EDF5',
  width: '100%',
  fontSize: 13,
  padding: '0 12px',
  background: '#fff',
};

export const TABLE_HEADER_BG = '#FAFBFE';

export const TAB_CONTAINER: React.CSSProperties = {
  background: '#FAFBFE',
  padding: 6,
  borderRadius: 14,
  border: '1px solid #E8EDF5',
};

export const tabStyle = (active: boolean): React.CSSProperties => ({
  height: 36,
  borderRadius: 10,
  fontSize: 13,
  padding: '0 16px',
  background: active ? 'var(--color-button-gradient, var(--color-button, var(--color-primary)))' : 'transparent',
  color: active ? '#fff' : '#94A3B8',
  fontWeight: 600,
  border: 'none',
  cursor: 'pointer',
  transition: 'all 0.15s ease',
});

export const SECTION_TITLE: React.CSSProperties = {
  fontSize: 15,
  fontWeight: 700,
  color: '#334155',
  letterSpacing: '-0.02em',
};

export const LABEL: string = 'text-xs font-medium block mb-1.5';
export const LABEL_COLOR = '#94A3B8';

/** DRE table unified tokens */
export const DRE_TABLE = {
  wrapper: {
    background: '#fff',
    borderRadius: 24,
    border: '1px solid #E8EDF5',
    overflow: 'auto' as const,
    maxHeight: 700,
    boxShadow: '0 2px 12px rgba(26,43,109,0.06)',
    overscrollBehaviorX: 'contain' as const,
    WebkitOverflowScrolling: 'touch' as const,
  },
  headerBg: '#F0F4FA',
  subHeaderBg: '#F0F4FA',
  subtotalBg: '#E8F0FE',
  subtotalColor: 'var(--color-primary, #1A2B6D)',
  saldoInicialBg: '#F0F4FA',
  saldoFinalBg: '#E2EAF5',
  acumuladoBg: '#E8EEF6',
  cellFont: { fontFamily: 'Inter', fontSize: 11 } as React.CSSProperties,
  positiveColor: '#046C4E',
  negativeColor: '#C53030',
  neutralColor: '#94A3B8',
  borderColor: '#DAE2F0',
};

export const BANNER: React.CSSProperties = {
  background: 'var(--color-primary-gradient, var(--color-primary))',
  borderRadius: 20,
  padding: '16px 24px',
  color: '#fff',
};

export const BTN_PRIMARY: React.CSSProperties = {
  height: 38,
  borderRadius: 10,
  fontSize: 13,
  padding: '0 24px',
  background: 'var(--color-button-gradient, var(--color-button, var(--color-primary)))',
  color: '#fff',
  fontWeight: 600,
  border: 'none',
  cursor: 'pointer',
};

export const BTN_DANGER: React.CSSProperties = {
  ...BTN_PRIMARY,
  backgroundColor: '#C53030',
};
