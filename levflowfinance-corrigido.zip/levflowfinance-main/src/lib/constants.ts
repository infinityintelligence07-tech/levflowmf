// ─── 9 categorias fiéis ao Python ───────────────────────────────────────────
export const CATEGORIAS_DRE = [
  { value: 'receita',              label: 'Receita Bruta',        tipo: 'entrada' },
  { value: 'deducao',              label: 'Deduções',             tipo: 'saida'   },
  { value: 'custo_variavel',       label: 'Custos Variáveis',     tipo: 'saida'   },
  { value: 'despesa_operacional',  label: 'Despesas Operacionais',tipo: 'saida'   },
  { value: 'outras_receitas',      label: 'Outras Receitas',      tipo: 'entrada' },
  { value: 'outras_despesas',      label: 'Outras Despesas',      tipo: 'saida'   },
  { value: 'investimento',         label: 'Investimentos',        tipo: 'saida'   },
  { value: 'emprestimo',           label: 'Empréstimos',          tipo: 'saida'   },
  { value: 'distribuicao_lucro',   label: 'Distribuição de Lucro',tipo: 'saida'   },
] as const;

// Labels exatos do Python (TIPO_MAPEAMENTO)
export const TIPO_MAPEAMENTO: Record<string, string> = {
  'Receita Bruta':          'receita',
  'Deduções':               'deducao',
  'Custos Variáveis':       'custo_variavel',
  'Despesas Operacionais':  'despesa_operacional',
  'Outras Receitas':        'outras_receitas',
  'Outras Despesas':        'outras_despesas',
  'Investimentos':          'investimento',
  'Empréstimos':            'emprestimo',
  'Distribuição de Lucro':  'distribuicao_lucro',
};

// Fiel ao Python: receitas e despesas para cálculo all-time
export const CATEGORIAS_RECEITA  = ['receita', 'outras_receitas'] as const;
export const CATEGORIAS_DESPESA  = [
  'deducao', 'custo_variavel', 'despesa_operacional',
  'outras_despesas', 'investimento', 'emprestimo', 'distribuicao_lucro',
] as const;

// Linhas do DRE — mesma hierarquia do Python
export const DRE_LINES = [
  { key: 'receita_bruta',         label: '(+) Receita Bruta',           categoria: 'receita' as string | null,             isSubtotal: false, componentes: null as string[] | null },
  { key: 'deducoes',              label: '(-) Deduções',                 categoria: 'deducao' as string | null,             isSubtotal: false, componentes: null as string[] | null },
  { key: 'receita_liquida',       label: '(=) Receita Líquida',          categoria: null,                                   isSubtotal: true,  componentes: ['receita','deducao'] as string[] | null },
  { key: 'custos_variaveis',      label: '(-) Custos Variáveis',         categoria: 'custo_variavel' as string | null,      isSubtotal: false, componentes: null as string[] | null },
  { key: 'margem_contribuicao',   label: '(=) Margem de Contribuição',   categoria: null,                                   isSubtotal: true,  componentes: ['receita','deducao','custo_variavel'] as string[] | null },
  { key: 'despesas_operacionais', label: '(-) Despesas Operacionais',    categoria: 'despesa_operacional' as string | null, isSubtotal: false, componentes: null as string[] | null },
  { key: 'ebitda',                label: '(=) EBITDA',                   categoria: null,                                   isSubtotal: true,  componentes: ['receita','deducao','custo_variavel','despesa_operacional'] as string[] | null },
  { key: 'outras_receitas',       label: '(+) Outras Receitas',          categoria: 'outras_receitas' as string | null,     isSubtotal: false, componentes: null as string[] | null },
  { key: 'outras_despesas',       label: '(-) Outras Despesas',          categoria: 'outras_despesas' as string | null,     isSubtotal: false, componentes: null as string[] | null },
  { key: 'investimentos',         label: '(-) Investimentos',            categoria: 'investimento' as string | null,        isSubtotal: false, componentes: null as string[] | null },
  { key: 'emprestimos',           label: '(-) Empréstimos',              categoria: 'emprestimo' as string | null,          isSubtotal: false, componentes: null as string[] | null },
  { key: 'resultado_bruto',       label: '(=) Resultado Bruto',          categoria: null,                                   isSubtotal: true,  componentes: ['receita','deducao','custo_variavel','despesa_operacional','outras_receitas','outras_despesas','investimento','emprestimo'] as string[] | null },
  { key: 'distribuicao_lucro',    label: '(-) Distribuição de Lucro',    categoria: 'distribuicao_lucro' as string | null,  isSubtotal: false, componentes: null as string[] | null },
  { key: 'resultado_liquido',     label: '(=) Resultado Líquido',        categoria: null,                                   isSubtotal: true,  componentes: ['receita','deducao','custo_variavel','despesa_operacional','outras_receitas','outras_despesas','investimento','emprestimo','distribuicao_lucro'] as string[] | null },
];

export const DONUT_COLORS: Record<string, string> = {
  deducao:             '#E53E3E',
  custo_variavel:      '#DD6B20',
  despesa_operacional: '#3182CE',
  outras_despesas:     '#805AD5',
  investimento:        '#319795',
  emprestimo:          '#718096',
  distribuicao_lucro:  '#D69E2E',
  lucro_retido:        '#38A169',
};
