export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.4"
  }
  public: {
    Tables: {
      acao_cfo: {
        Row: {
          categoria: string
          conta_nome: string | null
          created_at: string | null
          data_inicio: string
          empresa_id: string
          id: string
          pct: number
          tipo_macro: Database["public"]["Enums"]["acao_cfo_tipo_macro"]
        }
        Insert: {
          categoria: string
          conta_nome?: string | null
          created_at?: string | null
          data_inicio: string
          empresa_id: string
          id?: string
          pct?: number
          tipo_macro: Database["public"]["Enums"]["acao_cfo_tipo_macro"]
        }
        Update: {
          categoria?: string
          conta_nome?: string | null
          created_at?: string | null
          data_inicio?: string
          empresa_id?: string
          id?: string
          pct?: number
          tipo_macro?: Database["public"]["Enums"]["acao_cfo_tipo_macro"]
        }
        Relationships: [
          {
            foreignKeyName: "acao_cfo_empresa_id_fkey"
            columns: ["empresa_id"]
            isOneToOne: false
            referencedRelation: "empresas"
            referencedColumns: ["id"]
          },
        ]
      }
      bancos: {
        Row: {
          agencia: string | null
          conta: string | null
          created_at: string | null
          empresa_id: string
          gerente: string | null
          id: string
          nome: string
          saldo: number | null
          ultima_atualizacao: string | null
          whatsapp: string | null
        }
        Insert: {
          agencia?: string | null
          conta?: string | null
          created_at?: string | null
          empresa_id: string
          gerente?: string | null
          id?: string
          nome: string
          saldo?: number | null
          ultima_atualizacao?: string | null
          whatsapp?: string | null
        }
        Update: {
          agencia?: string | null
          conta?: string | null
          created_at?: string | null
          empresa_id?: string
          gerente?: string | null
          id?: string
          nome?: string
          saldo?: number | null
          ultima_atualizacao?: string | null
          whatsapp?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "bancos_empresa_id_fkey"
            columns: ["empresa_id"]
            isOneToOne: false
            referencedRelation: "empresas"
            referencedColumns: ["id"]
          },
        ]
      }
      empresas: {
        Row: {
          ativo: boolean | null
          cenario_c2: number | null
          cenario_c3: number | null
          cnpj: string | null
          color_bg: string | null
          color_button: string | null
          color_button_end: string | null
          color_gradient_angle: number | null
          color_primary: string | null
          color_primary_end: string | null
          color_text: string | null
          created_at: string | null
          id: string
          logo_b64: string | null
          nome: string
          obs: string | null
          regras_pendencia_limite: number | null
          regras_pendencia_tipo: string | null
          saldo_inicial: number | null
        }
        Insert: {
          ativo?: boolean | null
          cenario_c2?: number | null
          cenario_c3?: number | null
          cnpj?: string | null
          color_bg?: string | null
          color_button?: string | null
          color_button_end?: string | null
          color_gradient_angle?: number | null
          color_primary?: string | null
          color_primary_end?: string | null
          color_text?: string | null
          created_at?: string | null
          id?: string
          logo_b64?: string | null
          nome: string
          obs?: string | null
          regras_pendencia_limite?: number | null
          regras_pendencia_tipo?: string | null
          saldo_inicial?: number | null
        }
        Update: {
          ativo?: boolean | null
          cenario_c2?: number | null
          cenario_c3?: number | null
          cnpj?: string | null
          color_bg?: string | null
          color_button?: string | null
          color_button_end?: string | null
          color_gradient_angle?: number | null
          color_primary?: string | null
          color_primary_end?: string | null
          color_text?: string | null
          created_at?: string | null
          id?: string
          logo_b64?: string | null
          nome?: string
          obs?: string | null
          regras_pendencia_limite?: number | null
          regras_pendencia_tipo?: string | null
          saldo_inicial?: number | null
        }
        Relationships: []
      }
      formas_pagamento: {
        Row: {
          created_at: string | null
          empresa_id: string
          id: string
          nome: string
        }
        Insert: {
          created_at?: string | null
          empresa_id: string
          id?: string
          nome: string
        }
        Update: {
          created_at?: string | null
          empresa_id?: string
          id?: string
          nome?: string
        }
        Relationships: [
          {
            foreignKeyName: "formas_pagamento_empresa_id_fkey"
            columns: ["empresa_id"]
            isOneToOne: false
            referencedRelation: "empresas"
            referencedColumns: ["id"]
          },
        ]
      }
      lancamentos_reais: {
        Row: {
          ativo: boolean | null
          banco: string | null
          conta: string
          created_at: string | null
          data_real: string
          descricao: string | null
          empresa_id: string
          faturado: number | null
          forma_pagamento: string | null
          id: string
          nao_previsto: boolean | null
          orcamento_id: string | null
          transacao_id: string | null
          valor: number
        }
        Insert: {
          ativo?: boolean | null
          banco?: string | null
          conta: string
          created_at?: string | null
          data_real: string
          descricao?: string | null
          empresa_id: string
          faturado?: number | null
          forma_pagamento?: string | null
          id?: string
          nao_previsto?: boolean | null
          orcamento_id?: string | null
          transacao_id?: string | null
          valor: number
        }
        Update: {
          ativo?: boolean | null
          banco?: string | null
          conta?: string
          created_at?: string | null
          data_real?: string
          descricao?: string | null
          empresa_id?: string
          faturado?: number | null
          forma_pagamento?: string | null
          id?: string
          nao_previsto?: boolean | null
          orcamento_id?: string | null
          transacao_id?: string | null
          valor?: number
        }
        Relationships: [
          {
            foreignKeyName: "lancamentos_reais_empresa_id_fkey"
            columns: ["empresa_id"]
            isOneToOne: false
            referencedRelation: "empresas"
            referencedColumns: ["id"]
          },
        ]
      }
      orcamentos: {
        Row: {
          conta: string
          created_at: string | null
          data_lancamento: string | null
          data_ref: string
          descricao: string | null
          efetivado: boolean | null
          empresa_id: string
          faturado: number | null
          id: string
          p1: number | null
          p2: number | null
          p3: number | null
        }
        Insert: {
          conta: string
          created_at?: string | null
          data_lancamento?: string | null
          data_ref: string
          descricao?: string | null
          efetivado?: boolean | null
          empresa_id: string
          faturado?: number | null
          id?: string
          p1?: number | null
          p2?: number | null
          p3?: number | null
        }
        Update: {
          conta?: string
          created_at?: string | null
          data_lancamento?: string | null
          data_ref?: string
          descricao?: string | null
          efetivado?: boolean | null
          empresa_id?: string
          faturado?: number | null
          id?: string
          p1?: number | null
          p2?: number | null
          p3?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "orcamentos_empresa_id_fkey"
            columns: ["empresa_id"]
            isOneToOne: false
            referencedRelation: "empresas"
            referencedColumns: ["id"]
          },
        ]
      }
      pendencias: {
        Row: {
          banco: string | null
          conta: string | null
          created_at: string | null
          data: string
          descricao: string | null
          empresa_id: string
          forma_pagamento: string | null
          id: string
          observacao: string | null
          tipo: Database["public"]["Enums"]["pendencia_tipo"]
          valor: number
        }
        Insert: {
          banco?: string | null
          conta?: string | null
          created_at?: string | null
          data: string
          descricao?: string | null
          empresa_id: string
          forma_pagamento?: string | null
          id?: string
          observacao?: string | null
          tipo: Database["public"]["Enums"]["pendencia_tipo"]
          valor: number
        }
        Update: {
          banco?: string | null
          conta?: string | null
          created_at?: string | null
          data?: string
          descricao?: string | null
          empresa_id?: string
          forma_pagamento?: string | null
          id?: string
          observacao?: string | null
          tipo?: Database["public"]["Enums"]["pendencia_tipo"]
          valor?: number
        }
        Relationships: [
          {
            foreignKeyName: "pendencias_empresa_id_fkey"
            columns: ["empresa_id"]
            isOneToOne: false
            referencedRelation: "empresas"
            referencedColumns: ["id"]
          },
        ]
      }
      plano_contas: {
        Row: {
          categoria_dre: string
          created_at: string | null
          empresa_id: string
          exige_faturamento: boolean | null
          id: string
          nome_conta: string
        }
        Insert: {
          categoria_dre: string
          created_at?: string | null
          empresa_id: string
          exige_faturamento?: boolean | null
          id?: string
          nome_conta: string
        }
        Update: {
          categoria_dre?: string
          created_at?: string | null
          empresa_id?: string
          exige_faturamento?: boolean | null
          id?: string
          nome_conta?: string
        }
        Relationships: [
          {
            foreignKeyName: "plano_contas_empresa_id_fkey"
            columns: ["empresa_id"]
            isOneToOne: false
            referencedRelation: "empresas"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          created_at: string | null
          full_name: string
          id: string
          plan: Database["public"]["Enums"]["user_plan"]
        }
        Insert: {
          created_at?: string | null
          full_name?: string
          id: string
          plan?: Database["public"]["Enums"]["user_plan"]
        }
        Update: {
          created_at?: string | null
          full_name?: string
          id?: string
          plan?: Database["public"]["Enums"]["user_plan"]
        }
        Relationships: []
      }
      user_empresas: {
        Row: {
          created_at: string | null
          empresa_id: string
          id: string
          user_id: string
        }
        Insert: {
          created_at?: string | null
          empresa_id: string
          id?: string
          user_id: string
        }
        Update: {
          created_at?: string | null
          empresa_id?: string
          id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_empresas_empresa_id_fkey"
            columns: ["empresa_id"]
            isOneToOne: false
            referencedRelation: "empresas"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      acao_cfo_tipo_macro: "entradas" | "saidas"
      pendencia_tipo: "entrada" | "saida"
      user_plan: "finance" | "finance_eco"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      acao_cfo_tipo_macro: ["entradas", "saidas"],
      pendencia_tipo: ["entrada", "saida"],
      user_plan: ["finance", "finance_eco"],
    },
  },
} as const
