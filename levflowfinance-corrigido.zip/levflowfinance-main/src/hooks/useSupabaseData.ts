import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useEmpresa } from './useEmpresa';

async function fetchAllRows(table: string, activeIds: string[]) {
  const PAGE_SIZE = 1000;
  let allData: any[] = [];
  let from = 0;
  while (true) {
    const query = (supabase as any).from(table).select('*').in('empresa_id', activeIds).range(from, from + PAGE_SIZE - 1);
    const { data, error } = await query;
    if (error) throw error;
    if (!data || data.length === 0) break;
    allData = allData.concat(data);
    if (data.length < PAGE_SIZE) break;
    from += PAGE_SIZE;
  }
  return allData;
}

export function useSupabaseData() {
  const { empresaId, isAllMode, empresas } = useEmpresa();
  const [planoContas, setPlanoContas] = useState<any[]>([]);
  const [orcamentos, setOrcamentos] = useState<any[]>([]);
  const [lancamentos, setLancamentos] = useState<any[]>([]);
  const [bancos, setBancos] = useState<any[]>([]);
  const [pendencias, setPendencias] = useState<any[]>([]);
  const [formasPagamento, setFormasPagamento] = useState<any[]>([]);
  const [acaoCfo, setAcaoCfo] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const activeIds = isAllMode
    ? empresas.filter(e => e.ativo).map(e => e.id)
    : empresaId ? [empresaId] : [];

  const fetchAll = useCallback(async () => {
    if (activeIds.length === 0) { setLoading(false); return; }
    setLoading(true);
    try {
      const [pc, orc, lr, b, pen, fp, cfo] = await Promise.all([
        fetchAllRows('plano_contas', activeIds),
        fetchAllRows('orcamentos', activeIds),
        fetchAllRows('lancamentos_reais', activeIds),
        fetchAllRows('bancos', activeIds),
        fetchAllRows('pendencias', activeIds),
        fetchAllRows('formas_pagamento', activeIds),
        fetchAllRows('acao_cfo', activeIds),
      ]);
      setPlanoContas(pc);
      setOrcamentos(orc);
      setLancamentos(lr);
      setBancos(b);
      setPendencias(pen);
      setFormasPagamento(fp);
      setAcaoCfo(cfo);
    } catch (err) {
      console.error(err);
    }
    setLoading(false);
  }, [activeIds.join(',')]);

  useEffect(() => { fetchAll(); }, [fetchAll]);

  return {
    planoContas, orcamentos, lancamentos, bancos, pendencias, formasPagamento, acaoCfo,
    loading, refetch: fetchAll,
  };
}
