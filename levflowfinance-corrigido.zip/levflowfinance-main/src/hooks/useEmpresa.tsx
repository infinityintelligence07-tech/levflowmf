import { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import toast from 'react-hot-toast';

export interface Empresa {
  id: string;
  nome: string;
  cnpj: string | null;
  obs: string | null;
  ativo: boolean;
  color_primary: string;
  color_primary_end: string | null;
  color_gradient_angle: number;
  color_bg: string;
  color_text: string;
  color_button: string | null;
  color_button_end: string | null;
  logo_b64: string | null;
  cenario_c2: number;
  cenario_c3: number;
  saldo_inicial: number;
  regras_pendencia_tipo: string;
  regras_pendencia_limite: number;
}

/** Returns CSS value for the primary color — solid or gradient */
export function getPrimaryCSS(e: Empresa | null): string {
  const fallback = '#6FA9FF';
  if (!e) return fallback;
  if (e.color_primary_end) {
    return `linear-gradient(${e.color_gradient_angle}deg, ${e.color_primary}, ${e.color_primary_end})`;
  }
  return e.color_primary || fallback;
}

/** Returns a flat color for contexts that need a single color (borders, text) */
export function getPrimaryFlat(e: Empresa | null): string {
  return e?.color_primary || '#6FA9FF';
}

interface EmpresaContextType {
  empresas: Empresa[];
  empresaAtual: Empresa | null;
  empresaId: string | null;
  setEmpresaId: (id: string | null) => void;
  refreshEmpresas: () => Promise<void>;
  isAllMode: boolean;
}

const EmpresaContext = createContext<EmpresaContextType | null>(null);

export function EmpresaProvider({ children }: { children: ReactNode }) {
  const [empresas, setEmpresas] = useState<Empresa[]>([]);
  const [empresaId, setEmpresaId] = useState<string | null>(null);
  const { user } = useAuth();

  const refreshEmpresas = useCallback(async () => {
    if (!user) { setEmpresas([]); return; }

    // Get only empresas linked to this user
    const { data: links, error: linkErr } = await supabase
      .from('user_empresas')
      .select('empresa_id')
      .eq('user_id', user.id);
    if (linkErr) { toast.error(linkErr.message); return; }

    const ids = (links || []).map(l => l.empresa_id);
    if (ids.length === 0) { setEmpresas([]); return; }

    const { data, error } = await supabase
      .from('empresas')
      .select('*')
      .in('id', ids)
      .order('nome');
    if (error) { toast.error(error.message); return; }
    const mapped = (data || []).map(e => ({
      ...e,
      ativo: e.ativo ?? true,
      color_primary: e.color_primary || '#6FA9FF',
      color_primary_end: (e as any).color_primary_end || null,
      color_gradient_angle: Number((e as any).color_gradient_angle ?? 135),
      color_bg: e.color_bg || '#F4F5F8',
      color_text: e.color_text || '#334155',
      color_button: (e as any).color_button || null,
      color_button_end: (e as any).color_button_end || null,
      cenario_c2: Number(e.cenario_c2 ?? 30),
      cenario_c3: Number(e.cenario_c3 ?? 70),
      saldo_inicial: Number(e.saldo_inicial ?? 0),
      regras_pendencia_tipo: e.regras_pendencia_tipo || 'Quantidade',
      regras_pendencia_limite: e.regras_pendencia_limite ?? 5,
    })) as Empresa[];
    setEmpresas(mapped);
    if (mapped.length > 0 && !empresaId) {
      setEmpresaId(mapped[0].id);
    }
  }, [empresaId, user]);

  useEffect(() => { refreshEmpresas(); }, [user]);

  const empresaAtual = empresaId ? empresas.find(e => e.id === empresaId) || null : null;

  // Apply white label
  useEffect(() => {
    const primary = empresaAtual?.color_primary || '#6FA9FF';
    const bg = empresaAtual?.color_bg || '#F4F5F8';
    const text = empresaAtual?.color_text || '#334155';
    document.documentElement.style.setProperty('--color-primary', primary);
    document.documentElement.style.setProperty('--color-bg', bg);
    document.documentElement.style.setProperty('--color-text', text);

    // Set gradient CSS var
    const gradientCSS = empresaAtual ? getPrimaryCSS(empresaAtual) : '#6FA9FF';
    document.documentElement.style.setProperty('--color-primary-gradient', gradientCSS);

    // Button color vars
    const btnColor = empresaAtual?.color_button || primary;
    document.documentElement.style.setProperty('--color-button', btnColor);
    const btnGradient = empresaAtual?.color_button_end
      ? `linear-gradient(${empresaAtual.color_gradient_angle}deg, ${btnColor}, ${empresaAtual.color_button_end})`
      : btnColor;
    document.documentElement.style.setProperty('--color-button-gradient', btnGradient);
  }, [empresaAtual]);

  return (
    <EmpresaContext.Provider value={{
      empresas, empresaAtual, empresaId, setEmpresaId, refreshEmpresas,
      isAllMode: empresaId === null,
    }}>
      {children}
    </EmpresaContext.Provider>
  );
}

export function useEmpresa() {
  const ctx = useContext(EmpresaContext);
  if (!ctx) throw new Error('useEmpresa must be used within EmpresaProvider');
  return ctx;
}
