import { useState, useEffect } from 'react';
import { Toaster } from 'react-hot-toast';
import { EmpresaProvider, useEmpresa } from '@/hooks/useEmpresa';
import AppHeader from '@/components/AppHeader';
import AppNav from '@/components/AppNav';
import DashboardPage from '@/components/DashboardPage';
import DRE4SemanasPage from '@/components/DRE4SemanasPage';
import DREAnualPage from '@/components/DREAnualPage';
import PlanejamentoPage from '@/components/PlanejamentoPage';
import RealizadoPage from '@/components/RealizadoPage';
import ConciliacaoPage from '@/components/ConciliacaoPage';
import AcaoCFOPage from '@/components/AcaoCFOPage';
import CadastroPage from '@/components/CadastroPage';
import TransferenciaEntreEmpresasPage from '@/components/TransferenciaEntreEmpresasPage';

const EMPRESA_TABS = ['dash', 'dre4', 'dreanual', 'planejamento', 'realizado', 'conciliacao', 'acaocfo', 'cadastro'];
const ALL_TABS = ['dash', 'dre4', 'dreanual', 'transferencia'];

function AppContent() {
  const [activeTab, setActiveTab] = useState('dash');
  const { isAllMode, empresaId } = useEmpresa();

  // Reset tab when switching modes if current tab is invalid
  useEffect(() => {
    const validTabs = isAllMode ? ALL_TABS : EMPRESA_TABS;
    if (!validTabs.includes(activeTab)) {
      setActiveTab('dash');
    }
  }, [empresaId, isAllMode]);

  const goHome = () => setActiveTab('dash');

  return (
    <div className="min-h-screen" style={{ backgroundColor: 'var(--color-bg)', fontFamily: "'Inter', -apple-system, sans-serif" }}>
      <Toaster position="top-center" />
      <div className="max-w-[1440px] mx-auto px-5 py-4">
        <AppHeader onLogoClick={goHome} />
        <AppNav activeTab={activeTab} onTabChange={setActiveTab} />
        {activeTab === 'dash' && <DashboardPage onNavigate={setActiveTab} />}
        {activeTab === 'dre4' && <DRE4SemanasPage />}
        {activeTab === 'dreanual' && <DREAnualPage />}
        {activeTab === 'planejamento' && <PlanejamentoPage />}
        {activeTab === 'realizado' && <RealizadoPage />}
        {activeTab === 'conciliacao' && <ConciliacaoPage />}
        {activeTab === 'acaocfo' && <AcaoCFOPage />}
        {activeTab === 'cadastro' && <CadastroPage />}
        {activeTab === 'transferencia' && <TransferenciaEntreEmpresasPage />}
      </div>
    </div>
  );
}

export default function Index() {
  return (
    <EmpresaProvider>
      <AppContent />
    </EmpresaProvider>
  );
}
