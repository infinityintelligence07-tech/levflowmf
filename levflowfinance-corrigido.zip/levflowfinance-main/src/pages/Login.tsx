import { useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { LogIn, UserPlus, Eye, EyeOff, KeyRound } from 'lucide-react';
import toast from 'react-hot-toast';
import logoLevflow from '@/assets/logo-levflow.png';

export default function LoginPage() {
  const { signIn, signUp } = useAuth();
  const [mode, setMode] = useState<'login' | 'signup' | 'forgot'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [busy, setBusy] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    if (mode === 'signup') {
      const err = await signUp(email, password, fullName, 'finance');
      if (err) toast.error(err);
      else toast.success('Conta criada com sucesso!');
    } else if (mode === 'forgot') {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: window.location.origin,
      });
      if (error) toast.error(error.message);
      else toast.success('E-mail de recuperação enviado! Verifique sua caixa de entrada.');
      setBusy(false);
      return;
    } else {
      const err = await signIn(email, password);
      if (err) toast.error(err);
    }
    setBusy(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #EBF2FF 0%, #F0FFFE 50%, #FAFBFE 100%)' }}>
      <div className="w-full max-w-md mx-4">
        <div className="text-center mb-8">
          <img src={logoLevflow} alt="LevFlow Finance" className="mx-auto" style={{ maxHeight: 56 }} />
        </div>

        <div style={{
          background: '#fff',
          borderRadius: 24,
          border: '1px solid #E8EDF5',
          boxShadow: '0 8px 40px rgba(111,169,255,0.1)',
          padding: 32,
        }}>
          <h2 className="text-lg font-semibold mb-6" style={{ color: '#334155' }}>
            {mode === 'signup' ? 'Criar conta' : mode === 'forgot' ? 'Recuperar senha' : 'Entrar na plataforma'}
          </h2>

          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === 'signup' && (
              <div>
                <label className="text-xs font-medium block mb-1.5" style={{ color: '#94A3B8' }}>Nome completo</label>
                <input
                  value={fullName} onChange={e => setFullName(e.target.value)}
                  placeholder="Seu nome"
                  className="w-full px-4 text-sm"
                  style={{ height: 44, borderRadius: 14, border: '1px solid #E8EDF5', background: '#FAFBFE' }}
                  required
                />
              </div>
            )}

            <div>
              <label className="text-xs font-medium block mb-1.5" style={{ color: '#94A3B8' }}>E-mail</label>
              <input
                type="email" value={email} onChange={e => setEmail(e.target.value)}
                placeholder="seu@email.com"
                className="w-full px-4 text-sm"
                style={{ height: 44, borderRadius: 14, border: '1px solid #E8EDF5', background: '#FAFBFE' }}
                required
              />
            </div>

            {mode !== 'forgot' && (
              <div>
                <label className="text-xs font-medium block mb-1.5" style={{ color: '#94A3B8' }}>Senha</label>
                <div className="relative">
                  <input
                    type={showPw ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full px-4 pr-10 text-sm"
                    style={{ height: 44, borderRadius: 14, border: '1px solid #E8EDF5', background: '#FAFBFE' }}
                    required minLength={6}
                  />
                  <button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-3 top-1/2 -translate-y-1/2" style={{ color: '#94A3B8' }}>
                    {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              </div>
            )}

            <button
              type="submit" disabled={busy}
              className="w-full text-white font-semibold flex items-center justify-center gap-2 transition-all"
              style={{
                height: 48,
                borderRadius: 14,
                background: 'var(--color-button-gradient, var(--color-button, var(--color-primary, #6FA9FF)))',
                boxShadow: '0 4px 16px rgba(111,169,255,0.3)',
                fontSize: 14,
                opacity: busy ? 0.7 : 1,
              }}
            >
              {mode === 'forgot' ? <KeyRound size={16} /> : mode === 'signup' ? <UserPlus size={16} /> : <LogIn size={16} />}
              {busy ? 'Aguarde...' : mode === 'forgot' ? 'Enviar e-mail de recuperação' : mode === 'signup' ? 'Criar conta' : 'Entrar'}
            </button>
          </form>

          <div className="mt-5 space-y-2 text-center">
            {mode === 'login' && (
              <button onClick={() => setMode('forgot')} className="text-xs block mx-auto" style={{ color: '#94A3B8' }}>
                Esqueci minha senha
              </button>
            )}
            <button
              onClick={() => setMode(mode === 'signup' ? 'login' : mode === 'forgot' ? 'login' : 'signup')}
              className="text-sm font-medium"
              style={{ color: 'var(--color-primary, #6FA9FF)' }}
            >
              {mode === 'signup' ? 'Já tenho conta — Entrar' : mode === 'forgot' ? 'Voltar para login' : 'Não tenho conta — Criar'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
