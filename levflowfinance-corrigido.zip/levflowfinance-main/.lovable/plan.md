

## Problema

1. **Header bugado**: Quando o usuário escolhe uma cor escura (ex: `#000000`), o header aplica essa cor com transparência (`dd`, `aa`) mas mantém texto branco, criando contraste ruim. A lógica de construção do gradiente no header não respeita bem cores muito escuras ou muito claras.

2. **Falta opção de cor separada para botões**: Atualmente só existe "Cor Primária", "Cor de Fundo" e "Cor do Texto". Os botões usam a mesma cor primária. O usuário quer controlar a cor dos botões separadamente.

## Plano

### 1. Corrigir o header para usar o gradiente/cor definido pelo usuário diretamente

**Arquivo**: `src/components/AppHeader.tsx`

- Parar de fabricar um gradiente artificial com opacidade (`${color}dd`, `${color}aa`, `rgba(125,255,251,0.35)`).
- Usar diretamente `getPrimaryCSS(empresaAtual)` como background do header (que já retorna gradient ou cor sólida conforme configurado).
- Para cor sólida, usar a cor pura sem misturar transparências inventadas.
- Manter o blur e os efeitos decorativos (círculos radiais) mas sem alterar a cor base.

### 2. Adicionar campo "Cor dos Botões" na tabela `empresas`

**Migração SQL**: Adicionar coluna `color_button` (text, default null) na tabela `empresas`.

### 3. Atualizar o hook `useEmpresa`

**Arquivo**: `src/hooks/useEmpresa.tsx`

- Adicionar `color_button` à interface `Empresa`.
- Setar CSS var `--color-button` no efeito de white-label (fallback para `--color-primary`).

### 4. Atualizar a aba Design com campo separado para cor dos botões

**Arquivo**: `src/components/CadastroPage.tsx` (DesignTab)

- Adicionar color picker para "Cor dos Botões" ao lado dos existentes.
- Salvar `color_button` no banco ao clicar "Salvar Design".

### 5. Atualizar `ui-styles.ts` e todos os botões para usar `--color-button`

**Arquivo**: `src/lib/ui-styles.ts`

- `BTN_PRIMARY` usar `var(--color-button, var(--color-primary))` como background.
- Todos os botões inline que usam `var(--color-primary-gradient, var(--color-primary))` passam a usar `var(--color-button, var(--color-primary))`.

**Arquivos afetados**: `CadastroPage.tsx`, `DashboardPage.tsx`, `DRE4SemanasPage.tsx`, `DREAnualPage.tsx`, `PlanejamentoPage.tsx`, `RealizadoPage.tsx`, `ConciliacaoPage.tsx`, `AcaoCFOPage.tsx`, `AppNav.tsx` (tabs ativas).

### Resumo das mudanças

| Onde | O que muda |
|------|-----------|
| Header | Usa cor/gradiente direto sem fabricar opacidades |
| DB | Nova coluna `color_button` |
| Design tab | Novo picker "Cor dos Botões" |
| Botões globais | Usam `--color-button` com fallback para `--color-primary` |
| Tabs ativas (AppNav) | Usam `--color-button` |

Nenhuma lógica de negócio será alterada.

