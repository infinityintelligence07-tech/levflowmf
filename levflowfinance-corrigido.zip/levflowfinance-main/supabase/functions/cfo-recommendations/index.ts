import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { tipo, valorMeta, resumoFinanceiro } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const tipoLabel = tipo === "entradas" ? "aumentar receitas" : "reduzir despesas";

    const systemPrompt = `Você é um consultor financeiro (CFO) especialista em pequenas e médias empresas brasileiras. 
Analise os dados financeiros fornecidos e sugira ações CONCRETAS e PRÁTICAS para ${tipoLabel}.

REGRAS:
- Retorne exatamente 3 a 5 sugestões
- Cada sugestão deve ser específica, com base nos dados reais da empresa
- Inclua estimativa de impacto percentual realista
- Foque nas categorias e contas com maior potencial de impacto
- Use linguagem direta e profissional em português brasileiro
- NÃO sugira ações genéricas — baseie-se nos números fornecidos`;

    const userPrompt = `Dados financeiros da empresa:
${resumoFinanceiro}

Meta: ${tipo === "entradas" ? "aumentar receita" : "reduzir despesas"} em ${new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(valorMeta)}.

Sugira ações concretas para atingir essa meta.`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        tools: [
          {
            type: "function",
            function: {
              name: "sugerir_acoes",
              description: "Retorna sugestões de ações financeiras para o CFO",
              parameters: {
                type: "object",
                properties: {
                  sugestoes: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        titulo: { type: "string", description: "Título curto da ação (max 60 chars)" },
                        descricao: { type: "string", description: "Explicação detalhada da ação a tomar" },
                        categoria: { type: "string", description: "Categoria DRE afetada" },
                        conta: { type: "string", description: "Conta específica se aplicável, ou 'geral'" },
                        impacto_pct: { type: "number", description: "Estimativa de impacto percentual (positivo para aumento, negativo para redução)" },
                        impacto_valor: { type: "number", description: "Estimativa de impacto em reais" },
                        prioridade: { type: "string", enum: ["alta", "media", "baixa"] },
                      },
                      required: ["titulo", "descricao", "categoria", "impacto_pct", "impacto_valor", "prioridade"],
                    },
                  },
                },
                required: ["sugestoes"],
                additionalProperties: false,
              },
            },
          },
        ],
        tool_choice: { type: "function", function: { name: "sugerir_acoes" } },
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Limite de requisições excedido. Tente novamente em alguns segundos." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "Créditos insuficientes. Adicione créditos na sua conta." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const t = await response.text();
      console.error("AI gateway error:", response.status, t);
      return new Response(JSON.stringify({ error: "Erro ao gerar recomendações" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const data = await response.json();
    const toolCall = data.choices?.[0]?.message?.tool_calls?.[0];
    if (!toolCall) {
      return new Response(JSON.stringify({ error: "Resposta inesperada da IA" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const sugestoes = JSON.parse(toolCall.function.arguments);
    return new Response(JSON.stringify(sugestoes), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("cfo-recommendations error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Erro desconhecido" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
