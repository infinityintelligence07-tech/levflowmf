
-- Remove parent orcamentos that are sums of their children (Prosperity empresa)
-- Parents confirmed: VARIÁVEIS, PREST. SERVIÇO, TRAFEGO, COMISSÕES, FOLHA ADM, ESTRUTURA, INVESTIMENTOS, DES. FINANCEIRAS, MENTORIAS

DELETE FROM orcamentos
WHERE empresa_id = '413b0972-1293-4c75-a720-f633e9681c4e'
AND conta IN (
  'VARIÁVEIS',
  'PREST. SERVIÇO',
  'TRAFEGO',
  'COMISSÕES',
  'FOLHA ADM',
  'ESTRUTURA',
  'INVESTIMENTOS',
  'DES. FINANCEIRAS',
  'MENTORIAS'
);

-- Remove parent plano_contas entries (children already exist)
DELETE FROM plano_contas
WHERE empresa_id = '413b0972-1293-4c75-a720-f633e9681c4e'
AND nome_conta IN (
  'VARIÁVEIS',
  'PREST. SERVIÇO',
  'TRAFEGO',
  'COMISSÕES',
  'FOLHA ADM',
  'ESTRUTURA',
  'INVESTIMENTOS',
  'DES. FINANCEIRAS',
  'MENTORIAS'
);
