ALTER TABLE public.empresas ADD COLUMN color_button text DEFAULT NULL;
ALTER TABLE public.empresas ADD COLUMN color_button_end text DEFAULT NULL;