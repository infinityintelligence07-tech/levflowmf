
-- Create enum for pendencia tipo
CREATE TYPE public.pendencia_tipo AS ENUM ('entrada','saida');

-- Create enum for acao_cfo tipo_macro
CREATE TYPE public.acao_cfo_tipo_macro AS ENUM ('entradas','saidas');

-- TABLE: empresas
CREATE TABLE public.empresas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nome text NOT NULL,
  cnpj text,
  obs text,
  ativo boolean DEFAULT true,
  color_primary text DEFAULT '#0A1D56',
  color_bg text DEFAULT '#F4F5F8',
  color_text text DEFAULT '#1A202C',
  logo_b64 text,
  cenario_c2 numeric DEFAULT 30.0,
  cenario_c3 numeric DEFAULT 70.0,
  saldo_inicial numeric DEFAULT 0.0,
  regras_pendencia_tipo text DEFAULT 'Quantidade',
  regras_pendencia_limite integer DEFAULT 5,
  created_at timestamptz DEFAULT now()
);

-- TABLE: plano_contas
CREATE TABLE public.plano_contas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  empresa_id uuid REFERENCES public.empresas(id) ON DELETE CASCADE NOT NULL,
  nome_conta text NOT NULL,
  categoria_dre text NOT NULL,
  exige_faturamento boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- TABLE: orcamentos
CREATE TABLE public.orcamentos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  empresa_id uuid REFERENCES public.empresas(id) ON DELETE CASCADE NOT NULL,
  conta text NOT NULL,
  data_lancamento date,
  data_ref date NOT NULL,
  p1 numeric DEFAULT 0.0,
  p2 numeric DEFAULT 0.0,
  p3 numeric DEFAULT 0.0,
  faturado numeric DEFAULT 0.0,
  efetivado boolean DEFAULT false,
  descricao text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

-- TABLE: lancamentos_reais
CREATE TABLE public.lancamentos_reais (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  empresa_id uuid REFERENCES public.empresas(id) ON DELETE CASCADE NOT NULL,
  conta text NOT NULL,
  valor numeric NOT NULL,
  faturado numeric DEFAULT 0.0,
  data_real date NOT NULL,
  descricao text DEFAULT '',
  forma_pagamento text,
  banco text,
  ativo boolean DEFAULT true,
  nao_previsto boolean DEFAULT false,
  transacao_id uuid DEFAULT gen_random_uuid(),
  orcamento_id uuid,
  created_at timestamptz DEFAULT now()
);

-- TABLE: bancos
CREATE TABLE public.bancos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  empresa_id uuid REFERENCES public.empresas(id) ON DELETE CASCADE NOT NULL,
  nome text NOT NULL,
  gerente text DEFAULT '',
  whatsapp text DEFAULT '',
  agencia text DEFAULT '',
  conta text DEFAULT '',
  saldo numeric DEFAULT 0.0,
  ultima_atualizacao text DEFAULT '-',
  created_at timestamptz DEFAULT now()
);

-- TABLE: pendencias
CREATE TABLE public.pendencias (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  empresa_id uuid REFERENCES public.empresas(id) ON DELETE CASCADE NOT NULL,
  tipo pendencia_tipo NOT NULL,
  descricao text DEFAULT '',
  observacao text DEFAULT '',
  valor numeric NOT NULL,
  data date NOT NULL,
  banco text,
  conta text,
  forma_pagamento text,
  created_at timestamptz DEFAULT now()
);

-- TABLE: formas_pagamento
CREATE TABLE public.formas_pagamento (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  empresa_id uuid REFERENCES public.empresas(id) ON DELETE CASCADE NOT NULL,
  nome text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- TABLE: acao_cfo
CREATE TABLE public.acao_cfo (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  empresa_id uuid REFERENCES public.empresas(id) ON DELETE CASCADE NOT NULL,
  tipo_macro acao_cfo_tipo_macro NOT NULL,
  categoria text NOT NULL,
  conta_nome text DEFAULT 'todas',
  pct numeric NOT NULL DEFAULT 0.0,
  data_inicio date NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.empresas ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.plano_contas ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orcamentos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lancamentos_reais ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bancos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pendencias ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.formas_pagamento ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.acao_cfo ENABLE ROW LEVEL SECURITY;

-- RLS Policies: Allow all access (public app, no auth required initially)
CREATE POLICY "Allow all access to empresas" ON public.empresas FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all access to plano_contas" ON public.plano_contas FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all access to orcamentos" ON public.orcamentos FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all access to lancamentos_reais" ON public.lancamentos_reais FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all access to bancos" ON public.bancos FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all access to pendencias" ON public.pendencias FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all access to formas_pagamento" ON public.formas_pagamento FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all access to acao_cfo" ON public.acao_cfo FOR ALL USING (true) WITH CHECK (true);

-- Create indexes
CREATE INDEX idx_plano_contas_empresa ON public.plano_contas(empresa_id);
CREATE INDEX idx_orcamentos_empresa ON public.orcamentos(empresa_id);
CREATE INDEX idx_orcamentos_data_ref ON public.orcamentos(data_ref);
CREATE INDEX idx_lancamentos_empresa ON public.lancamentos_reais(empresa_id);
CREATE INDEX idx_lancamentos_data ON public.lancamentos_reais(data_real);
CREATE INDEX idx_bancos_empresa ON public.bancos(empresa_id);
CREATE INDEX idx_pendencias_empresa ON public.pendencias(empresa_id);
CREATE INDEX idx_formas_pagamento_empresa ON public.formas_pagamento(empresa_id);
CREATE INDEX idx_acao_cfo_empresa ON public.acao_cfo(empresa_id);
