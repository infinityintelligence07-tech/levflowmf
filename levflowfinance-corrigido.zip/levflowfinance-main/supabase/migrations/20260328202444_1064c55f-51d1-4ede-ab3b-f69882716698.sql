-- Create plan enum
CREATE TYPE public.user_plan AS ENUM ('finance', 'finance_eco');

-- Create profiles table
CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL DEFAULT '',
  plan user_plan NOT NULL DEFAULT 'finance',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own profile" ON public.profiles
  FOR SELECT TO authenticated USING (auth.uid() = id);

CREATE POLICY "Users can update own profile" ON public.profiles
  FOR UPDATE TO authenticated USING (auth.uid() = id);

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, plan)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', ''),
    COALESCE((NEW.raw_user_meta_data->>'plan')::user_plan, 'finance')
  );
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Add gradient columns to empresas
ALTER TABLE public.empresas
  ADD COLUMN IF NOT EXISTS color_primary_end text DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS color_gradient_angle integer DEFAULT 135;

-- Update default for color_primary
ALTER TABLE public.empresas ALTER COLUMN color_primary SET DEFAULT '#6FA9FF';