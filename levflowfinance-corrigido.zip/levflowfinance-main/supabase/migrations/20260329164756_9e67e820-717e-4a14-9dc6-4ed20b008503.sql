-- Remove duplicate orcamentos (keep the one with min id cast to text)
DELETE FROM orcamentos
WHERE id NOT IN (
  SELECT (MIN(id::text))::uuid
  FROM orcamentos
  GROUP BY empresa_id, conta, data_ref, p1, p2, p3, faturado, descricao
);

-- Remove duplicate plano_contas
DELETE FROM plano_contas
WHERE id NOT IN (
  SELECT (MIN(id::text))::uuid
  FROM plano_contas
  GROUP BY empresa_id, nome_conta, categoria_dre
);